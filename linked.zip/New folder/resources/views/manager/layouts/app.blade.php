<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>@yield('title') | {{env('app_name')}}</title>
        <link rel="apple-touch-icon" sizes="114x114" href="{{url('public/admin-manager-assets/images/favi-icon/apple-touch-icon.png')}}">
        <link rel="apple-touch-icon" sizes="76x76" href="{{url('public/images/favicon/apple-touch-icon.png')}}">
		<link rel="icon" type="image/png" sizes="32x32" href="{{url('public/images/favicon/favicon-32x32.png')}}">
		<link rel="icon" type="image/png" sizes="16x16" href="{{url('public/images/favicon/favicon-16x16.png')}}">
		<link rel="manifest" href="{{url('public/images/favicon/site.webmanifest')}}">
		<link rel="mask-icon" href="{{url('public/images/favicon/safari-pinned-tab.svg')}}" color="#00c7ff">
		<meta name="msapplication-TileColor" content="#2d89ef">
		<meta name="theme-color" content="#0ab1ff">

        <!--css files-->
        <link href="{{url('public/admin-manager-assets/css/bootstrap-select.min.css')}}" rel="stylesheet" type="text/css">
        <link href="{{url('public/admin-manager-assets/css/jquery.mCustomScrollbar.css')}}" rel="stylesheet" type="text/css">
        <!--<link href="{{url('public/admin-manager-assets/css/jquery.dataTables.min.css')}}" rel="stylesheet" type="text/css">-->
        <link href="{{url('public/admin-manager-assets/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css">
        <link href="{{url('public/admin-manager-assets/css/fontawesome.min.all.css')}}" rel="stylesheet" type="text/css">
        <link href="{{url('public/admin-manager-assets/css/daterangepicker.css')}}" rel="stylesheet" type="text/css">
        <!--<link href="{{url('public/admin-manager-assets/css/custom.min.css')}}" rel="stylesheet" type="text/css">-->
        <link href="{{url('public/admin-manager-assets/css/admin.min.css')}}" rel="stylesheet" type="text/css">
        <link href="{{url('public/admin-manager-assets/css/toastr.min.css')}}" rel="stylesheet" type="text/css">
        <link href="{{url('public/admin-manager-assets/css/rich-text-editor.min.css')}}" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="{{url('public/admin-manager-assets/css/cropper.min.css')}}">
        <link rel="stylesheet" href="{{url('public/admin-manager-assets/css/dataTables.bootstrap4.min.css')}}">
        <link rel="stylesheet" href="{{url('public/admin-manager-assets/css/tempusdominus-bootstrap-4.min.css')}}">

        <!--js files-->
        <script src="{{url('public/admin-manager-assets/js/jquery.min.js')}}"></script>
        <script src="{{url('public/admin-manager-assets/js/tinymce/tinymce.min.js')}}"></script>
        <script src="{{url('public/admin-manager-assets/js/jquery.raty.min.js')}}"></script>
        <script src="{{url('public/admin-manager-assets/js/jquery.form.js')}}"></script>
        <script src="{{url('public/admin-manager-assets/js/rich-text-editor.min.js')}}"></script>
        <script src="{{url('public/admin-manager-assets/js/bootbox.min.js')}}"></script>
        <script src="{{url('public/admin-manager-assets/js/toastr.js')}}"></script>
        <script src="{{url('public/admin-manager-assets/js/jsvalidation.min.js')}}"></script>
        <script src="{{asset('public/admin-manager-assets/js/cropper.min.js')}}"></script>        
        <script src="{{url('public/admin-manager-assets/js/popper.min.js')}}"></script>
        <script src="{{url('public/admin-manager-assets/js/bootstrap.min.js')}}"></script>
        <script src="{{url('public/admin-manager-assets/js/jquery.mCustomScrollbar.concat.min.js')}}"></script>
        <script src="{{url('public/admin-manager-assets/js/moment.js')}}"></script>
        <script src="{{url('public/admin-manager-assets/js/daterangepicker.js')}}"></script>
        <script src="{{url('public/admin-manager-assets/js/jquery.dataTables.min.js')}}"></script>
        <script src="{{url('public/admin-manager-assets/js/dataTables.bootstrap4.min.js')}}"></script>
        <script src="{{url('public/admin-manager-assets/js/bootstrap-select.min.js')}}"></script>
        <script src="{{url('public/admin-manager-assets/js/chart.js')}}"></script>  
        <script src="{{url('public/admin-manager-assets/js/tempusdominus-bootstrap-4.min.js')}}"></script>  

    </head>
    @if (Auth()->guard('manager')->check() && (Auth::guard('manager')->user()->status == 'active'))
    <body class="sidemenu-open">
        @include('manager.layouts.side-menu')    
        @include('manager.layouts.header')
        @endif    
        @yield('content')
        <!--</div>-->
        @include('manager.layouts.footer')
        @if(session()->has('success'))
        <script type="text/javascript">
$(document).ready(function ()
{
    toastr.remove();
    toastr.options.closeButton = true;
    toastr.success("{!! session('success') !!}", 'Success', {timeOut: 3000});
});
        </script>
        @endif
        @if(session()->has('error'))
        <script type="text/javascript">

            $(document).ready(function ()
            {
                toastr.remove();
                toastr.options.closeButton = true;
                toastr.error("{!! session('error') !!}", 'Error', {timeOut: 3000});
            });

        </script>
        @endif
        <script type="text/javascript">

            $('.login-field .input-group .form-control').focus(function ()
            {
                $(this).parent().addClass('isfocused');
            }).blur(function ()
            {
                $(this).parent().removeClass('isfocused');
            });
            var rotate = 1;

            function hide_preloader()
            {
                rotate = 0;
                $("#preloader").fadeOut('slow');
            }

            $(document).ready(function ()
            {
                $('.form-control').on('keyup', function ()
                {
                    if ($(this).val() != '')
                    {
                        $(this).addClass('i-focused');
                    }
                    else
                    {
                        $(this).removeClass('i-focused');
                    }
                });
            });
        </script>
    </body>
</html>
