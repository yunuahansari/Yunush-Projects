@if(count($users) >0)
<table class="table admin-table" id="data_table">
    <thead>
        <tr>           
            <th>Merchant Number</th>
            <th>Business Name</th>
            <th>Contact Name</th>
            <th>Phone Number</th>
            <th>Machine Model</th>
            <th>City/State</th>
            <th class="th_action no-sort">Action</th>
        </tr>
    </thead>
    <tbody>          
        @foreach($users as $user)            
        <tr id="{{'merchant_'.$user->id}}">
            <td>{{!empty($user->merchant_number) ? $user->merchant_number : '-'}}</td>
            <td>{{$user->bussiness_name}}</td>
            <td>{{!empty($user->contact_name) ? ucfirst($user->contact_name) : '-'}}</td>
            <td>{{!empty($user->phone_number) ? $user->phone_number : '-'}}</td>
            <td>{{!empty($user->machine_model) ? $user->machine_model : '-'}}</td>
            <td>
                @php
                $string = $user->city.','.$user->state;
                $string  = trim($string, ',');
                @endphp
                {{!empty($user->city || $user->state) ? $string : '-'}}
            </td>
            <td class="action">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-ellipsis-h"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="{{url('manager/linked-support',$user->user_id)}}">View</a>
                        <a class="dropdown-item" href="{{url('manager/merchant-linked-executive',$user->user_id)}}">Linked Support</a>
                        <a class="dropdown-item" href="{{url('manager/edit-merchant',$user->user_id)}}">Edit</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick='changeStatus("{{$user->user_id}}" , "deleted")'>Delete</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick="changePassword('{{$user->user_id}}');">Change Password</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick="sendDetail('{{$user->user_id}}')">Send Detail</a>
                    </div>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif
@if(count($users) >0)
<script>
    $(document).ready(function(){
    $('#merhantCsv').show();
    });
</script>
@endif
