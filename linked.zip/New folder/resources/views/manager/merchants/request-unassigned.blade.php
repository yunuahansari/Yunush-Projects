@extends('manager.layouts.app')
@section('title','Request Unsigned')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">request unassigned(SE)  List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="javascript:void(0);" class="nav-link">
                            <i class="fas fa-cloud-download-alt"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link">
                            <i class="fa fa-search"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <div class="filter_section collapse show" id="searchFilter">
                    <form>
                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                <div class="form-group">
                                    <input type="text" class="form-control">
                                    <label class="control-label">Name</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                <div class="form-group">
                                    <label>Genrate Date</label>
                                    <div class="dateicon">
                                        <input type="text" readonly id="SelectDate03" class="form-control datetimepicker-input" data-target="#SelectDate03" data-toggle="datetimepicker">
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                <div class="form-group">
                                    <input type="text" class="form-control">
                                    <label class="control-label">SE Assigned</label>
                                </div>
                            </div>
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-">
                                <div class="form-group">
                                    <select title="Category" class="form-control selectpicker" data-size="5">
                                        <option value="">Technical Support</option>
                                        <option value="">Product Upgrade</option>
                                        <option value="">Account Changes</option>
                                        <option value="">Request Supplies</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <button type="button" class="btn btn-primary ripple-effect-dark mr-2">Search</button>
                                    <button type="button" class="btn btn-warning ripple-effect-dark">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="table-responsive" id="getRequestUnassigned">
                </div>
            </div>
        </div>
    </div>
</main>
<script>
    $(document).ready(function () {
        getRequestUnassigned();
    });
    function getRequestUnassigned() {
        $("#getRequestUnassigned").html('<div class="listloader text-center pb-4"><i class="fa-2x fa-spin fas fa-spinner"></i></div>');
        var url = "{{url('manager/unassigned-request-list')}}";
        $.ajax({type: "GET", url: url,
            success: function (response) {
                setTimeout(function () {
                    $("#getRequestUnassigned").html("");
                    $("#getRequestUnassigned").hide().html(response.html).fadeIn('2000');
                    $("#data_table").DataTable({
                        searching: false,
                        "columnDefs": [{
                                "targets": 'no-sort',
                                "orderable": false,
                            }]
                    });
                }, 2000);
            }
        });
    }
</script>
@endsection