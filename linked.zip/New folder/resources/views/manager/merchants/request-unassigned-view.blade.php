@extends('manager.layouts.app')
@section('title','Request Unsigned')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">request unassigned  view</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="javascript:void(0);" class="nav-link">
                            <i class="fas fa-cloud-download-alt"></i>
                        </a>
                    </li>
                    <li class="list-inline-item">
                        <a href="{{url('manager/unassigned-request')}}" class="nav-link">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body view_info">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="profile-img">
                            <img src="micah.jpg" alt="user-img" class="rounded-circle img-fluid">
                        </div>
                        <ul class="list-unstyled info_list mb-0">
                            <li>
                                <label>Name </label>
                                <span>Micah Chan</span>
                            </li>
                            <li>
                                <label>Merchant Processor</label>
                                <span>Callisto</span>
                            </li>
                            <li>
                                <label>Request generate date</label>
                                <span>23 Aug 2018</span>
                            </li>
                            <li>
                                <label>Request Status</label>
                                <span class="status pending">Pending</span>
                            </li>

                            <li>
                                <label>SE Assigned </label>
                                <select class="form-control selectpicker" title="Select Customer Executive" data-size="5">
                                    <option value="micah chan">Micah Chan</option>
                                    <option value="kendall campos">Kendall Campos</option>
                                    <option value="elmo pratt">Elmo Pratt</option>
                                    <option value="steven bray">Steven Bray</option>
                                    <option value="dalton hoove">Dalton Hoover</option>
                                    <option value="marry sampson">Marry Sampson</option>
                                </select>
                            </li>
                            <li>
                                <label>Rating</label>
                                <span class="rating">
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                </span>
                            </li>
                            <li>
                                <label>Request Category</label>
                                <span>Technical Support</span>
                            </li>
                            <li>
                                <label>Total time of Call</label>
                                <span><i class="far fa-clock"></i> 15 mins</span>
                            </li>
                            <li>
                                <label class="notes_label">Notes</label>
                                <p class="mb-0">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar sic tempor. Sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus pronin sapien nunc accuan eget.</p>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- pagination end -->
            </div>
        </div>
    </div>
</main>
@endsection