@if($notifications->count()>0)
@foreach($notifications as $data)
<li>
    <span class="notification-text">
        {{$data->message}}
    </span>
    <span class="ml-auto date_tym">{{date('d/m/Y',strtotime($data->created_at))}}</span>
</li>
@endforeach
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif
{{$notifications->links()}}
<script>
    $(".pagination li a").on('click', function (e) {
        e.preventDefault();
        pageDivLoader('show', 'notificationlist');
        var $this = $(this);
        var pageLink = $this.attr('href');
        $.ajax({
            type: 'GET',
            url: pageLink,
            async: false,
            success: function (response) {
                $('.pagination:first').remove();
                $("#notificationlist").html(response.html);
            }
        });
    });
</script>