@if($notifications->count()>0)
<ul class="list-unstyled notifi-list"  data-mcs-theme="minimal-dark">   
@foreach($notifications as $data)
<li>
    <a href="javascript:void(0);">
        {{$data->message}}
    </a>
</li>
@endforeach
</ul>
<div class="noti_footer text-center">
    <a href="{{url('manager/notifications')}}" class="d-block">View All</a>
</div>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif