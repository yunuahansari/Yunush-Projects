@extends('manager.layouts.app')
@section('title', 'Notifications')
@section('content')
<main class="main-content innerpages notifications-page" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Notifications List</h4>
            </div>
            <div class="card-body">
                <ul class="notification_list list-unstyled" id="notificationlist">
                </ul>
            </div>
        </div>
    </div>
</main>
<script>
    $(document).ready(function () {
        getNotificationList();
    });
    function getNotificationList() {
        pageDivLoader('show', 'notificationlist');
        var url = "{{url('manager/notification-list')}}";
        $.ajax({type: "GET", url: url,
            success: function (response) {
                if (response.success) {
                    $("#notificationlist").html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>
@endsection