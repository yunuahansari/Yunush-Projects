@extends('manager.layouts.app')
@section('title', 'Change Password')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">change password</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('manager/dashboard')}}" class="nav-link"><i class="fas fa-long-arrow-alt-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <form class="f-field" id="changePasswordForm" action="{{url('manager/update-password')}}" method="post" autocomplete="off">
                    {{ csrf_field() }}
                    <div class="row justify-content-center">
                        <div class="col-sm-6 col-lg-5">
                            <div class="form-group">
                                <label>Enter Current Password</label>
                                <input type="password" name="current_password" class="form-control" placeholder="">
                            </div>

                            <div class="form-group">
                                <label>New Password</label>
                                <input type="password" name="password" class="form-control" placeholder="">
                            </div>

                            <div class="form-group">
                                <label>Confirm New Password</label>
                                <input type="password"  name="password_confirmation" class="form-control" placeholder="">
                            </div>

                            <div class="form-group text-center">
                                <button type="submit" id="btnChangePassword" class="btn btn-primary ripple-effect-dark">Save
                                    <i id="btnChangePasswordLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                    
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Http\Requests\ChangePasswordRequest','#changePasswordForm') !!}
            </div>
        </div>
    </div>
</main>
<script>
    $(document).on('submit', '#changePasswordForm', function (e) {
        e.preventDefault();
        if ($('#changePasswordForm').valid()) {
            $('#btnChangePassword').prop('disabled', true);
            $('#btnChangePasswordLoader').show();
            $.ajax({
                url: "{{url('manager/update-password')}}",
                data: $('#changePasswordForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "{{url('/manager')}}";
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnChangePassword').prop('disabled', false);
                    }
                    $('#btnChangePasswordLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        $('#btnChangePasswordLoader').hide();
                        $('#btnChangePassword').prop('disabled', false);
                        toastrAlertMessage('error', obj[x]);
                    }
                }
            });
        }
    });
</script>
@endsection