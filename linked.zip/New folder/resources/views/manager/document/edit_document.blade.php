@extends('manager.layouts.app')
@section('title', 'Edit Document')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Edit Documents</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a  href="{{url('manager/manage-document')}}" class="nav-link"><i class="fas fa-long-arrow-alt-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <form id="updateDocumentForm" onsubmit="return !!(checkDesc());" autocomplete="off" enctype="multipart/form-data" method="POST" action="{{url('manager/update-document')}}">
                    <input type="hidden" name="documentId" value="{{$document->id}}">
                    <input type="hidden" name="manager_id" value="{{$document->manager_id}}">            
                    {{csrf_field()}}
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Title<span class="text-danger">*</span></label>
                                <input type="text"  value="{{$document->title}}" name="title" class="form-control" >
                            </div>
                        </div>

                        <div class="col-sm-6">
                            @php
                            $categoryList = \App\Http\Models\BankingCategory::getActiveCategories();
                            @endphp
                            <div class="form-group">
                                <select name="category_id" class="form-control selectpicker" title="Select Category" onchange="$(this).valid()" data-size="5">
                                    <option value="">Select Category</option>
                                    @if(count($categoryList)>0)
                                    @foreach($categoryList as $category)
                                    <option value="{{$category->id}}" {{$category->id == $document->category_id ? "selected" : '' }}>{{$category->name}}</option>
                                    @endforeach
                                    @endif
                                </select>
                                <label class="control-label">Select Category<span class="text-danger">*</span></label>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class="control-label">Select options for<span class="text-danger">*</span></label>
                                <select id="document_type" name="document_type" class="form-control selectpicker" title="Select Document" data-size="5">
                                    <option value="doc"  {{ $document->document_type == 'doc' ? "selected" : '' }}>Upload a document</option>
                                    <option value="content"  {{ $document->document_type == 'content' ? "selected" : '' }}>Enter Document Content</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6" id="upload_pdf">
                            <div class="form-group">
                                <div class="file-upload">
                                    <div class="file-select">
                                        <div class="file-select-button" id="fileName">Choose File<span class="text-danger">*</span></div>
                                        <div class="file-select-name" id="noFile">{{!empty($document->pdf_upload) ? $document->pdf_upload : 'No file chosen...'}}</div> 
                                        <input type="file" name="pdf_upload" id="chooseFile">
                                        <input type="hidden" class="do-not-ignore" name="pdfUpload" id="pdfUpload" value="{{$document->pdf_upload}}">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12" id="document_content">
                            <div class="form-group">
                                <!-- <label>Content<span class="text-danger">*</span></label> -->
                                <textarea class="form-control" name="content" id="content" rows="6">{{$document->content}}</textarea>
                                <span id="content-error" style="font-size: 12px; color: red" class="help-block"></span>                                
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <button id="btnEditDocument" type="submit" class="btn btn-primary ripple-effect-dark submitButton">Save
                            <i id="addDocumentFormLoader" class="fa fa-spin fa-spinner" style="display: none;"></i> 
                        </button>
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Http\Requests\Manager\EditDocumentRequest','#updateDocumentForm') !!}                
            </div>
        </div>
    </div>
</main>

<script type="text/javascript">
    $(document).on('submit', '#updateDocumentForm', function (e) {
        if ($('#document_type').val() == 'content' && $('#content').val() == '') {
            $('#content-error').show();
            $('#content-error').html('The content field is required');
            return false;
        } else {
            $('#content-error').hide();
        }
        if ($('#updateDocumentForm').valid()) {
            $('#btnEditDocument').prop('disabled', true);
            $('#editDocumentFormLoader').show();
            var formData = new FormData($('#updateDocumentForm')[0]);
            $.ajax({
                url: "{{url('manager/update-document')}}",
                data: formData,
                type: 'POST',
                dataType: 'JSON',
                processData: false,
                contentType: false,
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "{{url('/manager/manage-document')}}";
                        }, 1000);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnEditDocument').prop('disabled', false);
                    }
                    $('#editDocumentFormLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        $('#editDocumentFormLoader').hide();
                        $('#btnEditDocument').prop('disabled', false);
                        toastrAlertMessage('error', obj[x]);
                    }
                }
            });
        }
    });

    $(document).ready(function () {
        tinymce.init({
            theme: "modern",
            selector: "textarea",
            relative_urls: false,
            remove_script_host: false,
            convert_urls: true,
            plugins: 'image code',
            height: 300,
            toolbar: 'undo redo | image code',
            images_upload_url: '{{ url("manager/content-image-upload") }}',
            images_upload_handler: function (blobInfo, success, failure) {
                var xhr, formData;
                xhr = new XMLHttpRequest();
                xhr.withCredentials = false;
                xhr.open('POST', '{{ url("manager/content-image-upload") }}');
                xhr.setRequestHeader('X-CSRF-TOKEN', '{{ csrf_token() }}');
                xhr.onload = function () {
                    var json;
                    if (xhr.status != 200)
                    {
                        failure('HTTP Error: ' + xhr.status);
                        return;
                    }
                    json = JSON.parse(xhr.responseText);
                    if (!json || typeof json.location != 'string')
                    {
                        failure('Invalid JSON: ' + xhr.responseText);
                        return;
                    }
                    success(json.location);
                };
                formData = new FormData();
                formData.append('file', blobInfo.blob(), blobInfo.filename());
                xhr.send(formData);
            },
            init_instance_callback: function (editor)
            {
                editor.on('keyup', function (e)
                {
                    var message = tinymce.get('content').getContent();
                    if (message === '')
                    {
                        $("#content-error").html('The content field is required');
                    } else
                    {
                        $("#content-error").html('');
                    }
                });
            }
        });
    });

    function checkDesc() {
        if ($('#document_type').val() == 'content' && $('#content').val() == '') {
            $('#content-error').show();
            $('#content-error').html('The content field is required');
            $("#content-error").css('color', 'red');
            return false;
        } else {
            $('#content-error').hide();
        }
    }

    $("#document_type > option").each(function () {
        if (this.selected == true && this.value == "doc") {
            $('#upload_pdf').show();
            $('#document_content').hide();
        } else if (this.selected == true && this.value == "content") {
            $('#upload_pdf').hide();
            $('#document_content').show();
        } else {

        }
    });

    $('#document_type').change(function () {
        var type = $(this).val();
        if (type == "content") {
            $('#upload_pdf').hide();
            $('#document_content').show();
        } else {
            $('#upload_pdf').show();
            $('#document_content').hide();
        }
    });

    $('#chooseFile').bind('change', function () {
        var filename = $("#chooseFile").val();
        $('#pdfUpload').val(filename);
        if (/^\s*$/.test(filename)) {
            $(".file-upload").removeClass('active');
            $("#noFile").text("No file chosen...");
        } else {
            $(".file-upload").addClass('active');
            $("#noFile").text(filename.replace(/C:\\fakepath\\/i, ''));
        }
    });
</script>

@endsection