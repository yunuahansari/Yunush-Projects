@extends('manager.layouts.app')
@section('title','Support Executive')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Support Executive Request Note View</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('manager/support-executive-view/'.$requestNotes->executive_id)}}" class="nav-link">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body view_info">
                <div class="row">
                    <div class="col-lg-6">
                        <ul class="list-unstyled info_list mb-0">
                            <li>
                                <label class="notes_label">Note</label>
                                <p class="mb-0">{{$requestNotes->notes}}</p>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- pagination end -->
            </div>
        </div>
    </div>
</main>
@endsection