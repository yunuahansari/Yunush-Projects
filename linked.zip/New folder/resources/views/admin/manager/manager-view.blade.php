@extends('admin.layouts.app')
@section('title', 'Merchant Processor Detail')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Support Merchant Processor View</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/manager')}}" class="nav-link">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body view_info">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="profile-img">
                            <img src="{{checkProfileImage($viewManager->profile_image)}}" alt="user-img" class="rounded-circle img-fluid">
                        </div>
                        <ul class="list-unstyled info_list mb-0">
                            <li>
                                <label>Name</label>
                                <span>{{getFullName($viewManager->first_name ,$viewManager->last_name )}}</span>
                            </li>
                            <li>
                                <label>Email</label>
                                <span>{{$viewManager->email}}</span>
                            </li>
                            <li>
                                <label>Phone Number</label>
                                <span> {{$viewManager->phone_number}}</span>
                            </li>
                            <li>
                                <label>Company</label>
                                <span>{{$viewManager->company_name}}</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection