@if(count($managers) >0)
<table class="table admin-table" id="data_table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Phone number</th>
            <th>Created Date</th>
            <th>Status</th>
            <th class="th_action no-sort">Action</th>
        </tr>
    </thead>
    <tbody>        
        @foreach($managers as $data)
        @php
        $bankName = \App\Http\Models\Bank::getBankByDucument($data->bank_id);
        @endphp
        <tr id="{{'managers'.$data->id}}">
            <td>{{$data->first_name.' '.$data->last_name}}</td>
            <td>{{$data->email}}</td>
            <td>{{$data->phone_number}}</td>
            <td>{{showDateTimeFormatSecond($data->created_at)}}</td>
            <td>
                <div class="switch">
                    <label>
                        <input id="userStatus_{{$data->id}}" type="checkbox" onclick='changeStatus("{{$data->id}}" , "{{$data->status}}")' {{$data->status == 'active' ? 'checked':'' }} >
                        <span class="lever" for="userStatus_{{$data->id}}"></span>
                    </label>
                </div>
            </td>
            <td class="action">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-ellipsis-h"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="{{url('admin/manager-view',$data->id)}}">View</a>
                        <a class="dropdown-item" href="{{url('admin/manager-edit',$data->id)}}">Edit</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick='changeStatus("{{$data->id}}" , "deleted")'>Delete</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick="changePassword('{{$data->id}}')">Change Password</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick="sendDetail('{{$data->id}}')">Send Detail</a>
                    </div>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif