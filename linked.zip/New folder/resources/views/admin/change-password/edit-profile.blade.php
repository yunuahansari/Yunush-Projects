@extends('admin.layouts.app')
@section('title', 'Edit Profile')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Edit Profile</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/view-profile')}}" class="nav-link">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body view_info">
                <div class="row justify-content-center">
                    <div class="col-sm-6 col-lg-5">
                        <form class="f-field" id="editProfileForm" action="{{url('admin/update-profile')}}" method="post" autocomplete="off">
                            {{ csrf_field() }}
                            <input type="hidden" name="id" value="{{Auth()->guard('admin')->user()->id}}">                            
                            <div class="form-group">
                                <label>Email<span class="text-danger">*</span></label>
                                <input type="text" name="email" value="{{Auth()->guard('admin')->user()->email}}" class="form-control" placeholder="">
                            </div>

                            <div class="form-group">
                                <label>Enter Current Password<span class="text-danger">*</span></label>
                                <input type="password" name="current_password" value="" class="form-control" placeholder="">
                                <span class="text-danger spanPassValidation" id="spanCurrentPassword"></span>                                                                
                            </div>

                            <div class="form-group">
                                <label>New Password<span class="text-danger">*</span></label>
                                <input type="password" name="password" value="" class="form-control" placeholder="">
                                <span class="text-danger spanPassValidation" id="spanPassword"></span>                                                                
                            </div>

                            <div class="form-group">
                                <label>Confirm New Password<span class="text-danger">*</span></label>
                                <input type="password" name="password_confirmation" value="" class="form-control" placeholder="">
                                <span class="text-danger spanPassValidation" id="spanConfirmPassword"></span>                                                                
                            </div>

                            <div class="form-group text-center">
                                <button type="submit" id="btnEditProfile" class="btn btn-primary ripple-effect-dark">Save
                                    <i id="btnEditProfileLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                    
                                </button>
                            </div>
                    </div>
                </div>
            </div>
            </form>
            {!! JsValidator::formRequest('App\Http\Requests\Admin\EditProfileRequest','#editProfileForm') !!}
        </div>
    </div>
</main>
<script>
    $(document).on('submit', '#editProfileForm', function (e) {
        e.preventDefault();
        if ($('#editProfileForm').valid()) {
            $('.spanPassValidation').text('');
            $('#btnEditProfile').prop('disabled', true);
            $('#btnEditProfileLoader').show();
            $.ajax({
                url: "{{url('admin/update-profile')}}",
                data: $('#editProfileForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "{{url('/admin/view-profile')}}";
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnEditProfile').prop('disabled', false);
                    }
                    $('#btnEditProfileLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        if ($.inArray('current_password', obj[x])) {
                            $('#spanCurrentPassword').text('');
                            $('#spanCurrentPassword').text(obj[x].current_password);
                        } else {
                            toastrAlertMessage('error', obj[x]);
                        }
                        if ($.inArray('password', obj[x])) {
                            $('#spanPassword').text('');
                            $('#spanPassword').text(obj[x].password);
                        } else {
                            toastrAlertMessage('error', obj[x]);
                        }
                        if ($.inArray('password_confirmation', obj[x])) {
                            $('#spanConfirmPassword').text('');
                            $('#spanConfirmPassword').text(obj[x].password_confirmation);
                        } else {
                            toastrAlertMessage('error', obj[x]);
                        }
                        $('#btnEditProfileLoader').hide();
                        $('#btnEditProfile').prop('disabled', false);
                    }
                }
            });
        }
    });
</script>
@endsection