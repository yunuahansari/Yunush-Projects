@if(count($contactAdmin) >0)
<table class="table admin-table" id="data_table">
    <thead>
        <tr>
            <th>Name</th>
            <th>Business Name</th>
            <th>Phone Number</th>
            <th>Email</th>
            <th class="th_action no-sort">Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach($contactAdmin as $data)
        <tr>
            <td>{{$data->name}}</td>
            <td>{{$data->business_name}}</td>
            <td>{{$data->phone_no}}</td>
            <td>{{$data->email}}</td>
            <td class="action">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-ellipsis-h"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="javascript:void(0);" onclick="viewContactAdmin('{{$data->id}}')">View</a>
                    </div>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif