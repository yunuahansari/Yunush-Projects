@extends('admin.layouts.app')
@section('title', 'Contact Admin')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Contact Admin List</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="#searchFilter" data-toggle="collapse" class="nav-link">
                            <i class="fa fa-search"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body form_box">
                <div class="filter_section collapse" id="searchFilter">
                    <form id="search_form" action="javascript:load_contactAdmin_list()" method="post" autocomplete="off">
                        {{ csrf_field() }}
                        <div class="row">
                            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6">
                                <div class="form-group">
                                    <label>Search By Name</label>
                                    <input type="text" name="name" id="name" class="form-control" placeholder="">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <button type="submit" class="btn btn-primary ripple-effect-dark mr-2">Search</button>
                                    <button type="reset" onclick="resetForm();" class="btn btn-warning ripple-effect-dark">Reset</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="table-responsive" id="contact_admin_list">
                </div>
            </div>
        </div>
    </div>
</main>

<!-- Modal -->
<div class="modal fade" id="viewContactAdmin" tabindex="-1" role="dialog" aria-labelledby="viewContactModalLabel" aria-hidden="true">
    <div class="modal-dialog common-modal modal-dialog-centered" role="document">
        <div class="modal-content profile-modal" id="getContactAdmin"></div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function ()
    {
        load_contactAdmin_list();
    });

    function resetForm() {
        $('#search_form')[0].reset();
        load_contactAdmin_list();
    }

    function load_contactAdmin_list()
    {
        pageDivLoader('show', 'contact_admin_list');
        var search_filter = $("#search_form").serializeArray();
        $.ajax({
            type: "POST",
            url: "{{ url('admin/contact-admin-list') }}",
            data: search_filter,
            success: function (response)
            {
                if (response.success) {
                    $("#contact_admin_list").html(response.html);
                    $("#data_table").DataTable({
                        searching: false,
                        "order": [],
                        "columnDefs": [{
                                "targets": [4, 4],
                                "orderable": false,
                            }]
                    });
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    function viewContactAdmin(id) {
        $.ajax({
            type: "GET",
            url: '{{url("admin/contact-admin-view")}}',
            data: {id: id},
            success: function (response) {
                if (response.success) {
                    $("#getContactAdmin").html(response.html);
                    $("#viewContactAdmin").modal('show');
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

</script>
@endsection