@if($merchantSE->count()>0)
<table class="table admin-table" id="data_table">
    <thead>
    <th>ID</th>
    <th>Name</th>
    <th>Manager Name</th>
    <th>Phone Number</th>
</thead>
<tbody>
    @foreach($merchantSE as $user)
    @php
    $managerName = \App\Http\Models\User::getManagerByDocument($user->manager_id);
    @endphp
    <tr>
        <td>{{!empty($user->userProfile->executive_number) ? $user->userProfile->executive_number : ''}}</td>
        <td>{{!empty($user->userDetail->contact_name) ? $user->userDetail->contact_name : ''}}</td>
        <td>{{!empty($managerName) ? ucfirst($managerName->first_name.' '.$managerName->last_name): '-'}}</td>
        <td>{{!empty($user->userDetail->phone_number) ? $user->userDetail->phone_number : ''}}</td>
    </tr>
    @endforeach
</tbody>
</table>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif
@if($merchantSE->count()>0)
<script>
    $(document).ready(function () {
        $('#merchantSE').show();
    });
</script>
@endif