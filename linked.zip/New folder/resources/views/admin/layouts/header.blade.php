<header  id="topHeader">
    <div class="container-fluid">
        <nav class="navbar navbar-light justify-content-between bg-transparent">
            <h3 class="page-title">
                <a href="javascript:void(0);" onclick="sideMenu();" class="toggle-icon">
                    <i class="fa fa-outdent"></i>
                </a>
                @php
                $currentRoute = Request::route()->getName();
                @endphp
                <span>
                    @if($currentRoute == 'manage-user')
                    {{"Merchant Processor"}}
                    @elseif($currentRoute == 'manage-executives' || $currentRoute == 'support-executive-request')
                    {{"Support Executive"}}
                    @elseif($currentRoute == 'manage-merchant' || $currentRoute == 'merchant-request' || $currentRoute == 'unassigned-request')
                    {{"Merchant"}}
                    @elseif($currentRoute == 'call-request')
                    {{"Call Request"}}
                    @elseif($currentRoute == 'documents')
                    {{"Wiki Document"}}
                    @elseif($currentRoute == 'banks')
                    {{"Bank"}}
                    @elseif($currentRoute == 'categories')
                    {{"Category"}}
                    @elseif($currentRoute =='contact-admin')
                    {{"Contact Admin"}}
                    @elseif($currentRoute == 'view-profile')
                    {{"View Profile"}}
                    @elseif($currentRoute == 'edit-profile')
                    {{"Edit Profile"}}
                    @elseif($currentRoute == 'change-password')
                    {{"Setting"}}
                    @elseif($currentRoute == 'ratings')
                    {{"Rating"}}
                    @elseif($currentRoute =='notifications')
                    NOTIFICATIONS
                    @else                    
                    {{"Dashboard"}}
                    @endif
                </span>
            </h3> 
            <ul class="nav align-items-center ml-auto">
                <li class="dropdown notification">
                    <a href="javascript:void(0);" onclick="readNotification()" class="dropdown-toggle" id="dropdownMenuButton01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <span class="count" id="count"></span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton01">
                        <div class="head">
                            <h3 class="font-hy mb-0">Notifications</h3>
                        </div>
                        <div class="noti_body"  id="notificationList">
                            <!-- <ul class="list-unstyled mCustomScrollbar" data-mcs-theme="minimal-dark">
                            </ul> -->
                        </div>
                    </div>
                </li>                
                <li class="dropdown user_avtar">
                    <a href="javascript:void(0);"  class="dropdown-toggle" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="{{checkProfileImage(Auth()->guard('admin')->user()->profile_image)}}" alt="user_img" class="user-img rounded-circle">
                        <span class="name">{{Auth()->guard('admin')->user()->first_name.' '.Auth()->guard('admin')->user()->last_name}}</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="{{url('admin/view-profile')}}">View Profile</a>
                        <a class="dropdown-item" href="{{url('admin/logout')}}" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit();">
                            Logout
                        </a>
                        <form id="logout-form" action="{{url('admin/logout')}}" method="POST" style="display: none;">
                            {{ csrf_field() }}
                        </form>
                    </div>
                </li>

            </ul>
        </nav>
    </div>
</header>

<script>
    $(document).ready(function () {
        loadNotificationList();
        countNotificationList();
        setInterval(countNotificationList, 5000);
    });
    function loadNotificationList() {
        pageDivLoader('show', 'notificationList');
        var url = "{{url('admin/load-notification-list')}}";
        $.ajax({
            url: url,
            type: 'GET',
            success: function (response) {
                if (response.success) {
                    $("#notificationList").html(response.html);
                    $(".notifi-list").mCustomScrollbar();
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    function countNotificationList() {
        var url = "{{url('admin/load-notification-count')}}";
        $.ajax({
            url: url,
            type: 'GET',
            success: function (response) {
                $('#count').html(response.data);
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    function readNotification() {
        var url = "{{url('admin/update-notification-list')}}";
        $.ajax({
            url: url,
            type: 'POST',
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
                loadNotificationList();
                countNotificationList();
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
</script>