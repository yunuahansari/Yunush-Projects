@extends('admin.layouts.app')
@section('title', 'Call Request View')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Call Request View</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/call-request')}}" class="nav-link">
                            <i class="fas fa-long-arrow-alt-left"></i>
                        </a>
                    </li>
                </ul>
            </div>
            <div class="card-body view_info">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="profile-img">
                            <img src="{{checkProfileImage($callRequest->customerDetail->profile_image)}}" alt="user-img" class="rounded-circle img-fluid">
                        </div>
                        <ul class="list-unstyled info_list mb-0">
                            <li>
                                <label>Merchant Name </label>
                                <span>{{!empty($callRequest->customerDetail->contact_name) ? ucfirst($callRequest->customerDetail->contact_name) : ''}}</span>
                            </li>
                            <li>
                                <label>Date of Call</label>
                                <span>{{showDateFormat($callRequest->created_at)}}
                                </span>
                            </li>
                            <li>
                                <label>Status of Call</label>
                                <span class="status {{$callRequest->status == 'resolved' ? 'resolved' : 'pending'}}">{{ucfirst($callRequest->status)}}</span>
                            </li>
                            <li>
                                <label>SE Assigned </label>
                                <span>{{!empty($callRequest->executiveDetail->contact_name) ? ucfirst($callRequest->executiveDetail->contact_name) : ''}}</span>
                            </li>
                            <li>
                                <label>Category</label>
                                <span>{{!empty($callRequest->BankCategory->name) ? $callRequest->BankCategory->name : ''}}</span>
                            </li>
                            <li>
                                @php
                                $executiveId = \App\Http\Models\CallRequest::getManagerIdByExecutive($callRequest->executive_id);
                                $managerName = \App\Http\Models\User::getManagerByDocument($executiveId->manager_id);
                                @endphp
                                <label>Manager Name</label>
                                <span>{{!empty($managerName) ? ucfirst($managerName->first_name.' '.$managerName->last_name): '-'}}</span>
                            </li>
                            <li>
                                <label>Ratings </label>
                                <span class="rating">
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                    <i class="fa fa-star" aria-hidden="true"></i>
                                </span>
                            </li>
                            <li>
                                <label class="notes_label">Notes</label>
                                <p class="mb-0">{{$callRequest->notes}}</p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection