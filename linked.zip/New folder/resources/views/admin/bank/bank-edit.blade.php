@extends('admin.layouts.app')
@section('title', 'Edit Bank')
@section('content')
<main class="main-content innerpages" id="mainContent">
    <div class="container-fluid">
        <div class="card custom_card" id="cardBox">
            <div class="card-header">
                <h4 class="page-title float-left">Edit Bank</h4>
                <ul class="list-inline mb-0 text-right">
                    <li class="list-inline-item">
                        <a href="{{url('admin/banks')}}" class="nav-link"><i class="fas fa-long-arrow-alt-left"></i></a>
                    </li>
                </ul>
            </div>
            <div class="card-body">
                <form id="editBankForm" autocomplete="off" class="f-field" method="POST" action="{{url('admin/bank-update')}}">
                    {{csrf_field()}}
                    <input type="hidden" name="bankId" value="{{$editBank->id}}">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <select name="waiting_time" title="Select Time" onchange="$(this).valid();" data-size="5" class="form-control selectpicker">
                                    <option value="">Select Waiting Time</option>
                                    @php
                                    for ($x = 1; $x <= 10; $x++) {
                                    @endphp
                                    <option value="{{$x}}" @if($x == $editBank->waiting_time) selected="selected" @endif>{{$x}} Minute</option>
                                    @php
                                    } 
                                    @endphp
                                </select>
                                <label class="control-label">Select Wiating Time</label>
                            </div>
                        </div>
                    </div>
                    <div class="from-group">
                        <button id="btnEditBank" type="submit" class="btn btn-primary btn_radius submitButton">
                            <i id="editBankFormLoader" class="fa fa-spin fa-spinner" style="display: none;"></i> Save
                        </button>
                    </div>
                </form>
                {!! JsValidator::formRequest('App\Http\Requests\Admin\EditBankRequest','#editBankForm') !!}
            </div>
        </div>
    </div>
</main>
<script type="text/javascript">
    $(document).on('submit', '#editBankForm', function (e) {
        e.preventDefault();
        if ($('#editBankForm').valid()) {
            $('#btnEditBank').prop('disabled', true);
            $('#editBankFormLoader').show();
            $.ajax({
                url: "{{url('admin/bank-update')}}",
                data: $('#editBankForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            window.location = "{{url('/admin/banks')}}";
                        }, 1000);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnEditBank').prop('disabled', false);
                    }
                    $('#editBankFormLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        $('#editBankFormLoader').hide();
                        $('#btnEditBank').prop('disabled', false);
                        toastrAlertMessage('error', obj[x]);
                    }
                }
            });
        }
    });


    function backloader()
    {
        $("#back-loader").attr("disabled", true);
        $("#back-loader").html('<i class="fa fa-spinner fa-spin"></i>');
    }
    ;

</script>

@endsection