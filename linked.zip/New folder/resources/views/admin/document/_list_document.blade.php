@if(count($documents) >0)
<table class="table admin-table" id="data_table">
    <thead>
        <tr>
            <th>Manager Name</th>
            <th>Title</th>
            <th>Created Date</th>
            <th class="th_action no-sort">Action</th>
        </tr>
    </thead>
    <tbody>
        @foreach($documents as $data)
        @php
        $managerName = \App\Http\Models\User::getManagerByDocument($data->manager_id);
        @endphp
        <tr id="documents{{$data->id}}">
            <td>{{!empty($managerName) ? ucfirst($managerName->first_name.' '.$managerName->last_name): '-'}}</td>
            <td>{{str_limit($data->title, 50)}}</td>
            <td>{{showDateTimeFormatSecond($data->created_at)}}</td>
            <td class="action">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-ellipsis-h"></i>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="{{url('admin/document-view',$data->id)}}">View</a>
                        <a class="dropdown-item" href="{{url('admin/document-edit',$data->id)}}">Edit</a>
                        <a class="dropdown-item" href="javascript:void(0);" onclick="deletefunction({{$data->id}})">Delete</a>
                    </div>
                </div>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif