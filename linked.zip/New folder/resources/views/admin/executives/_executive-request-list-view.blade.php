@if(count($executives) >0)
<table class="table admin-table" id="data_table">
    <thead>
    <th>Merchant Name</th>
    <th>SE Assigned</th>
    <th>Support Department</th>
    <th>Request generate date</th>
    <th>Request Status</th>
    <!--<th>Request Category</th>-->
    <th>Total time of Call</th>
    <th class="th_action no-sort">Action</th>
</thead>
<tbody>
    @foreach($executives as $data)
    <tr>
        <td>
            {{!empty($data->customerDetail->contact_name) ? $data->customerDetail->contact_name : ''}}
        </td>
        <td>
            {{!empty($data->executiveDetail->contact_name) ? $data->executiveDetail->contact_name : ''}}
        </td>
        <td>
            {{!empty($data->BankCategory->name) ? $data->BankCategory->name : ''}} 
        </td>
        <td>
            {{showFullMonthDateFormat($data->created_at)}}
        </td>
        <td>
            <div class="user_status {{$data->status == 'resolved' ? 'resolved' : 'pending'}}">
                <span>{{ucfirst($data->status)}}</span>
            </div>
        </td>
        <!--<td>Technical Support</td>-->
        <td>
            <div class="user_tym">
                <i class="far fa-clock"></i> {{$data->call_time}} mins
            </div>
        </td>
        <td class="action">
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle border-0 p-0" type="button" id="dropdownMenuButton" data-toggle="dropdown"
                        aria-haspopup="true" aria-expanded="false">
                    <i class="fas fa-ellipsis-h"></i>
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="{{url('admin/support-executive-request-note-view/'.$data->id)}}">View</a>
                </div>
            </div>
        </td>
    </tr>
    @endforeach
</tbody>
</table>
@else
<div class="alert alert-danger"><center>{{\Config::get('constants.no_record_found')}}</center></div>
@endif