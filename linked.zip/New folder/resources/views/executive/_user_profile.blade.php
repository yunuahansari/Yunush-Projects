
<div class="user-dtl-top d-sm-flex justify-content-between">
    <div class="left-dtl d-flex align-items-center">
        <div class="user-avtar">
            <img src="{{getImage($user->profile_image,'users','users')}}" alt="User" class="rounded-circle">
        </div>
        <div class="user-name ">
            <h3 class="font-hy">{{getFullName($user->first_name ,$user->last_name)}}</h3>
            <p>{{!empty($user->bankCategory->name) ? $user->bankCategory->name : ''}}</p>
        </div>
    </div>
</div>
<div class="user-dtl-in">
    <div class=" wrap d-block d-sm-flex align-items-center justify-content-between">
        <div class="label">Mobile</div>
        <div class="right font-hy">{{$user->phone_number}}</div>
    </div>
    <div class=" wrap d-block d-sm-flex align-items-center justify-content-between">
        <div class="label">Email</div>
        <div class="right font-hy">{{$user->email}}</div>
    </div>
    <div class="wrap d-block d-sm-flex align-items-center justify-content-between">
        <div class="label">Address</div>
        <div class="right font-hy">{{!empty($user->address) ? $user->address : '-'}}</div>
    </div>
</div>
