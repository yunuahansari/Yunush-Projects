@extends('executive.layouts.app')
@section('title', 'Linked Notes')
@section('content')

        
        <script src="https://webrtc.github.io/adapter/adapter-latest.js"></script>
        <script src="https://linked-assist-webrtc.codiant.com/socket.io/socket.io.js"></script>
        <script src="{{url('public/js/prortc.js')}}"></script>
<main class="main-content requests-page" id="content">
    <section class="tabs_section">
        <div class="row">
            <div class="col-lg-5 col-xl-6 left">
                <ul class="list-unstyled tabs_links d-flex justify-content-start nav nav-tabs" id="myTab" role="tablist">
                    <li class="text-uppercase nav-item"><a id="note-tab" onclick="noteTab();" data-toggle="tab" href="#note" role="tab" aria-controls="note" aria-selected="true" class="nav-link active">NOTE</a></li>
                    <li class="text-uppercase nav-item"><a id="documents-tab" onclick="documentTab();" data-toggle="tab" href="#documents" role="tab" aria-controls="documents" aria-selected="false" class="nav-link">DOCUMENTS</a></li>
                    <li class="text-uppercase nav-item"><a id="history-tab" onclick="historyTab();" data-toggle="tab" href="#notesHistory" role="tab" aria-controls="notesHistory" aria-selected="false" class="nav-link">NOTES HISTORY</a></li>

                    <div class="search_box ml-auto" id="searchBox">
                        <form id="searchFilterForm" action="javascript:void(0)" onsubmit="documentTab()" method="post" autocomplete="off">
                            {{ csrf_field() }}
                            <input type="hidden" name="manager_id" value="{{getManagerByExecutiveId(Auth::guard(getAuthGuard())->user()->id)}}">
                            <div class="input-group">
                                <input type="text" id="nameFilter" name="document_name" class="form-control" placeholder="Document name" aria-label="Document name" aria-describedby="document_button">
                                <div class="input-group-append">
                                    <button class="btn bg-transparent border-0" type="submit" id="document_button"><i class="icon-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </ul>
                <div class="tab-content tabs_content" id="myTabContent">
                    <div class="tab-pane fade show active" id="note" role="tabpanel" aria-labelledby="note-tab">
                        <div class="note_box">
                            <h5>Note</h5>
                            <div class="form-group mb-0">
                                <textarea class="form-control border-0 shadow-none" id="textAddNote" rows="8" cols="80" onkeyup="setGetNote($(this).val());">{{@$request->notes}}</textarea>
                            </div>
                        </div>
                    </div>
                    <!--document listing and view document-->
                    <div class="tab-pane fade" id="documents" role="tabpanel" aria-labelledby="documents-tab">
                        <div id="divDocumentList"></div>
                        <div class="document_view" id="viewContent">
                            <div class="d-flex justify-content-between">
                                <h4>Operation function</h4>
                                <a href="javascript:void(0);" onclick="documentClose();">Close</a>
                            </div>
                            <div class="content_text">
                                <span id="divTitle"></span>
                                <div id="divContent"></div>
                            </div>
                        </div>                        
                    </div>
                    <!-- customer and executive linked previous notes listing-->                    
                    <div class="tab-pane fade" id="notesHistory" role="tabpanel" aria-labelledby="history-tab">
                    </div>
                </div>
            </div>
            <div class="custom-col-4 col-lg-4">
                <div class="machine_sec">
                    <div class="machine_inner">
                        <!--<img src="{{url('public/admin-manager-assets/images/machine.jpg')}}" alt="img" class="img-fluid">-->
                        <canvas id="c" width="400" height="600" style="border:1px solid #aaa;"></canvas>
                        <video id="remote"></video>
                        <span id="play_video"></span>
                        <div style="display: inline-block; margin-left: 10px">
                            <div id="drawing-mode-options">
                                <select id="drawing-mode-selector" style="display: none">
                                    <option>Pencil</option>
                                </select><br>
                                <span class="info"></span>
                                <input type="range" value="2" min="0" max="10" id="drawing-line-width" style="display: none">
                                <input type="color" value="#005E7A" id="drawing-color" style="display: none">
                            </div>
                        </div>
                    </div>
                    <ul class="btn_list list-inline">
                        <li class="list-inline-item">
                            <div id="myEditDropdown" class="dropdown-content">
                                <a href="javascript:void(0);" id="clear-canvas" class="ripple-effect-dark"><i class="icon-close"></i><span>Clear</span></a>
                                <a href="javascript:void(0);" class="ripple-effect-dark" onclick="addCanvasText()"><i class="icon-text"></i><span>Text</span></a>
                                <a href="javascript:void(0);" class="ripple-effect-dark draw" onclick="draw_canvas()"><i class="icon-highlighter"></i><span>Draw</span></a>
                                <a href="javascript:void(0);" class="ripple-effect-dark" onclick="toggle_size()"><i class="size_text" ><span id="draw_width">2</span> pt</i><span>Size</span></a>
                                <a href="javascript:void(0);" class="ripple-effect-dark" onclick="toggle_color()"><i class="icon-fill"></i><span>Color</span></a>
                            </div>
                            <a href="javascript:void(0);" onclick="myEditToggle()" class="icons edit_btn ripple-effect-dark"><i class="icon-edit"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" onclick="openAddNoteModal();" class="icons callend_btn ripple-effect-dark"><i class="icon-call-cut"></i></a>
                        </li>
                        <li class="list-inline-item">
                            <a href="javascript:void(0);" class="icons camera_btn ripple-effect-dark" id="addImage"><i class="icon-photo-camera"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="custom-col-2 col-lg-3 right">
                <div class="profile_detail">
                    <img src="{{getImage(!empty($request->customerDetail->profile_image) ? $request->customerDetail->profile_image : '' ,'users','users')}}" alt="user" class="img-fluid rounded-circle">
                    <h3>{{!empty($request->customerDetail->contact_name) ? $request->customerDetail->contact_name : ''}}</h3>
                    <span class="bank_name">{{!empty($request->customerDetail->bank->name) ? $request->customerDetail->bank->name : ''}}</span>
                    <div class="info_list">
                        <div class="list d-flex justify-content-between">
                            <p>Merchant no.</p>
                            <span>{{!empty($request->UserProfile->merchant_number) ? $request->UserProfile->merchant_number : ''}}</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Product</p>
                            <span>{{!empty($request->UserProfile->product) ? $request->UserProfile->product : ''}}</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Company</p>
                            <span>{{!empty($request->customerDetail->bank->name) ? $request->customerDetail->bank->name  : ''}}</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Business name</p>
                            <span>{{!empty($request->UserProfile->bussiness_name) ? $request->UserProfile->bussiness_name : ''}}</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Business address</p>
                            <span>{{!empty($request->UserProfile->bussiness_address) ? $request->UserProfile->bussiness_address : ''}}</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Mobile</p>
                            <span>{{!empty($request->customerDetail->phone_number) ? $request->customerDetail->phone_number : ''}}</span>
                        </div>
                        <div class="list d-flex justify-content-between">
                            <p>Email</p>
                            <span>{{!empty($request->customerDetail->email) ? $request->customerDetail->email : ''}}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<!--call modal starts -->
<!-- add note Modal -->
<div class="modal fade common-modal add_note" id="AddNote" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="viewHestoryModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header ">
                <div class="col text-left p-0">
<!--                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>-->
                </div>
                <div class="col p-0 text-center">
                    <h5 class="modal-title" id="viewHestoryModalLabel">ADD NOTE</h5>
                </div>
                <div class="col p-0 text-center">

                </div>
            </div>
            <div class="modal-body" id="divAddNoteModalBody">

            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="{{asset('public/')}}/js/ajaxupload.3.5.js"></script>
<script>
    
    var add_image = $('#addImage');
    new AjaxUpload(add_image, {
        action: '{{ url("/upload-image") }}',
        name: 'add_image',
        cache: false,
        method : 'post',
        data : {_token : '{{ csrf_token() }}', ticket_id : $('#hdnTicketId').val() },
        responseType: "JSON",
        onSubmit: function (file, ext) {
            if (!(ext && /^(jpg|png|jpeg)$/.test(ext))) {
                toastrAlertMessage('error', 'Only jpg, jpeg, png files are allowed.');
                return false;
            }
        },
        onComplete: function (file, response) {
            if (file != "") {
                if (response.success == 1) {
                    var receiverId = $("#hdnCustomerId").val();
                    socket.emit('send-image',{image:response.filename,receiverId:receiverId})
                } else {
                    toastrAlertMessage('error', response.error);
                }
            } else {
                toastrAlertMessage('error', "Error occured! please try again.");
            }
        }
    });
    
    function status_radio(value) {
        $(".field_box").hide();
        $("." + value).show();
    }
    function notify_radio(value) {
        $(".notify_box").hide();
        $("." + value).show();
    }
    // function edit_history() {
    //     $("#EditHistory").modal("show");
    // }
</script>
<!--call modal ends -->

<script>
    $(document).ready(function () {
        var noteText = $('#textAddNote').val();
        setGetNote(noteText);
    });

    /* set input text to add note textarea and request add note textarea*/
    function setGetNote(noteText) {
        $('#textRequestAddNote').val(noteText);
        $('#textAddNote').val(noteText);
    }

    function myEditToggle() {
        $("#myEditDropdown").toggleClass("active");
    }
    
    function toggle_color(){
        //$("#drawing-color").toggle();
        $("#drawing-color").trigger('click');
    }
    
    function toggle_size(){
        $("#drawing-line-width").toggle();
    }
    $(document).ready(function () {
        $('#searchBox').hide();
    });
    function openAddNoteModal() {
        prortc.endCall();
        var customerId = $("#hdnCustomerId").val();
        socket.emit('end-user-call',{customerId:customerId});
        $("#c").hide();
        $.ajax({
            type: "GET",
            url: "{{url('load-add-note-modal')}}" + '/' + '{{@$request->id}}',
            success: function (response) {
                if (response.success) {
                    $("#AddNote").modal('show');
                    $('#divAddNoteModalBody').html(response.html);
                    $('.selectpicker').selectpicker('refresh');
                    setGetNote($('#textAddNote').val());
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
//                    toastrAlertMessage('error', obj[x]);
                }
            }
        });

    }
    function noteTab() {
        $('#searchBox').hide();
    }
    function documentTab() {
        $('#viewContent').hide();
        $('#divDocumentList').show();
        pageDivLoader('show', 'divDocumentList');
        var searchString = $("#searchFilterForm").serializeArray();
        $.ajax({
            type: "POST",
            url: "{{url('executive-document-list')}}",
            data: searchString,
            success: function (response) {
                if (response.success) {
                    $('#searchBox').show();
                    $('#divDocumentList').html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
//                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }
    function historyTab() {
        $('#searchBox').hide();
        $('#notesHistory').show();
        pageDivLoader('show', 'notesHistory');
        $.ajax({
            type: "GET",
            url: "{{url('linked-merchant-notes-history-list')}}" + '/' + '{{@$request->customerDetail->id}}',
            success: function (response) {
                if (response.success) {
                    $('#notesHistory').html(response.html);
                } else {
                    toastrAlertMessage('error', response.message);
                }
            },
            error: function (err) {
                var obj = jQuery.parseJSON(err.responseText);
                for (var x in obj) {
//                    toastrAlertMessage('error', obj[x]);
                }
            }
        });
    }

    function documentView(title, content) {
        $('#viewContent').show();
        $('#divDocumentList').hide();
        $('#divTitle').html('<h6>' + title + '</h6>');
        $('#divContent').html(content);
    }

    function documentClose() {
        $('#viewContent').hide();
        $('#divDocumentList').show();
    }
</script>
<script id="main">
    canvas = this.__canvas = new fabric.Canvas('c', {
        isDrawingMode: true
    });
$(document).ready(function () {
    var $ = function (id) {
        return document.getElementById(id)
    };
    
    var drawingOptionsEl = $('drawing-mode-options'),
            drawingColorEl = $('drawing-color'),
            drawingLineWidthEl = $('drawing-line-width');

    
    
//    var itext = new fabric.IText(' ', {
//	left: 100,
//	top: 150,
//	fill: '#D81B60',
//	strokeWidth: 2,
//	stroke: "#880E4F",
//});
//canvas.add(itext)
    var currentHistoryState = -1;
    var historyStates = [];

    function getQueryVariable(variable) {
        var query = window.location.search.substring(1);
        var vars = query.split("&");
        for (var i = 0; i < vars.length; i++) {
            var pair = vars[i].split("=");
            if (pair[0] == variable) {
                return pair[1];
            }
        }
        return (false);
    }
    
    
    let userType = getQueryVariable('type');

    prortc.on('remote_stream',
            function (stream, id) {
                console.log("main Praveen stream",stream);
                if (!userType) {
                    console.log('remote_stream', stream);
                    var videoE = document.createElement('video');
                    videoE.width = 1000;
                    videoE.height = 700;
                    videoE.muted = false;
                    videoE.srcObject = stream;

                    var fab_video = new fabric.Image(videoE, {
                        left: 0,
                        top: 0
                    });
                    canvas.add(fab_video);
                    fab_video.getElement().play();
                } else {
                    $('remote').srcObject = stream;
                    $('remote').play();
                }
            }
    );
    
    

    prortc.on('path:created', function (data) {
        console.log('path:created ', data);
        var pathLength = data.path.length;
        var pathArray = [];
        for (var i = 0; i < pathLength; i++) {
            var subPath = data.path[i];
            var subPathLength = subPath.length;
            for (var j = 0; j < subPathLength; j++) {
                pathArray.push(subPath[j]);
            }
        }
        var path = new fabric.Path(pathArray.join(' '), data);
        canvas.add(path);

        canvas.forEachObject(function (o) {
            o.selectable = false;
        });
        canvas.selectable = false;
        canvas.renderAll();
    });

    prortc.on('object:removed', function (data) {
        if (userType == 'user') {
            var obj = canvas.getObjects();
            for (var z = 0; z < obj.length; z++) {
                if (z > 0) {
                    canvas.remove(obj[z]);
                }
            }
        }
    });

    prortc.init('/');
    prortc.joinRoom({
        room: 'test'
    });
    let options;
    if (userType === 'user') {
        canvas.isDrawingMode = false;
        drawingOptionsEl.style.display = 'none';
        options = {
            video: true,
            audio: true
        }
    } else {
        options = {
            video: false,
            audio: true
        }
    }

    prortc.startCall(options,
            function (stream) {
                var videoE = document.createElement('video');
                videoE.width = 1000;
                videoE.height = 700;
                videoE.muted = true;
                videoE.srcObject = stream;

                var fab_video = new fabric.Image(videoE, {
                    left: 0,
                    top: 0
                });
                canvas.add(fab_video);
                fab_video.getElement().play();
            },
            function (error) {
                console.log(error);
            }
    );

    function generateId() {
        function s4() {
            return Math.floor((1 + Math.random()) * 0x10000)
                    .toString(16)
                    .substring(1);
        }

        return s4();
    }

    /**
     * Saves canvas history of changes.
     */
    function saveHistoryState() {
        if (currentHistoryState != -1) {
            historyStates = historyStates.slice(0, currentHistoryState + 1);
        }
        historyStates.push(canvas.toJSON(['id']));
        currentHistoryState = historyStates.length - 1;
    }


    fabric.util.requestAnimFrame(function render() {
        canvas.renderAll();
        fabric.util.requestAnimFrame(render);
    });

    canvas.on('object:modified', function (event) {
        var data = (event.target).toJSON(['id']);
        console.log('object:modified id before ', data.id);

        prortc.socket.emit('object:modified', data);

        saveHistoryState();
    });
    canvas.on('object:added', function (event) {
        //console.log('object:added', (event.target).toJSON(['id']));
        //saveHistoryState();
    });
    canvas.on('object:removed', function (event) {
        console.log('object:removed', event.target);
        prortc.socket.emit('object:removed', (event.target).toJSON(['id']));
        saveHistoryState();

    });
    canvas.on('path:created', function (event) {
        event.path.id = generateId();
        prortc.socket.emit('path:created', (event.path).toJSON(['id']));
        saveHistoryState();

    });

    fabric.Object.prototype.transparentCorners = false;

    clearEl = $('clear-canvas');
    clearEl.onclick = function () {
        var obj = canvas.getObjects();
        for (var z = 0; z < obj.length; z++) {
            if (z > 1) {
                canvas.remove(obj[z]);
            }
        }
    };

    $('drawing-mode-selector').onchange = function () {
        canvas.freeDrawingBrush = new fabric[this.value + 'Brush'](canvas);
        if (canvas.freeDrawingBrush) {
            canvas.freeDrawingBrush.color = drawingColorEl.value;
            canvas.freeDrawingBrush.width = parseInt(drawingLineWidthEl.value, 10) || 1;
            
        }
    };

    drawingColorEl.onchange = function () {
        canvas.freeDrawingBrush.color = this.value;
    };

    drawingLineWidthEl.onchange = function () {
        canvas.freeDrawingBrush.width = parseInt(this.value, 10) || 1;
        var canvasWidth = canvas.freeDrawingBrush.width;
        
        setTimeout(function(){
            document.getElementById('draw_width').innerHTML = canvasWidth;
//            $("#draw_width").html(canvasWidth);
        },100);
        this.previousSibling.innerHTML = this.value;
    };


    if (canvas.freeDrawingBrush) {
        canvas.freeDrawingBrush.color = drawingColorEl.value;
        canvas.freeDrawingBrush.width = parseInt(drawingLineWidthEl.value, 10) || 1;
    }

});

function addCanvasText() {
    canvas.isDrawingMode = false;
        var oText = new fabric.Textbox('', {
            left: 200,
            top: 200,
            width: 150,
            fontSize: 20,
            fontFamily: 'Times New Roman',
            underline: true,
            fontStyle: 'normal',
            textBackgroundColor: '#0A97FF',
        });
        canvas.add(oText);
        oText.bringToFront();
        canvas.setActiveObject(oText);
       // $('#fill, #font').trigger('change');
    }
    
    function draw_canvas(){
        canvas.isDrawingMode = true;
    }
        </script>

        <script>
            (function () {
                fabric.util.addListener(fabric.window, 'load', function () {
                    var canvas = this.__canvas || this.canvas,
                            canvases = this.__canvases || this.canvases;

                    canvas && canvas.calcOffset && canvas.calcOffset();

                    if (canvases && canvases.length) {
                        for (var i = 0, len = canvases.length; i < len; i++) {
                            canvases[i].calcOffset();
                        }
                    }
                });
            })();
        </script>
@endsection