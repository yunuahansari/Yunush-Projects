<form id="EditSEquestForm" autocomplete="off" class="f-field" method="POST" action="{{url('update-se-request')}}">
    {{csrf_field()}}
    <input type="hidden" name="request_id" value="{{$seRequest->id}}"> 
    <div class="form-group input_wrap">
        <label class="theme-color02 d-block">Request Status</label>
        <label class="i-checks">
            <input type="radio" name="status" value="pending" {{$seRequest->status == 'pending' ? 'checked' : ''}} onchange="status_radio('Pending');"><i></i> Pending 
        </label>
        <label class="i-checks ml-2 ml-sm-3">
            <input type="radio" name="status" value="resolved" {{$seRequest->status == 'resolved' ? 'checked' : ''}} onchange="status_radio('Resolved');"><i></i> Resolved 
        </label>
    </div>
    <div class="field_box Pending">
        <div class="form-group">
            <label class="theme-color02 d-block">Notify me</label>
            <div class="form-check form-check-inline">
                <label class="i-checks">
                    <input type="radio" class="radioStatus"  name="notify_type" id="radioWhenOnline" value="when_online" {{$seRequest->notify_type == 'when_online' ? 'checked' : ''}} onchange="notify_radio('UserOnline');"><i></i> When user back online 
                </label>
            </div>
            <div class="form-check form-check-inline">
                <label class="i-checks">
                    <input type="radio" class="radioStatus" name="notify_type" id="radioToday" value="today" {{$seRequest->notify_type == 'today' ? 'checked' : ''}} onchange="notify_radio('Today');"><i></i> Today 
                </label>
            </div>
            <div class="form-check form-check-inline">
                <label class="i-checks">
                    <input type="radio" class="radioStatus" name="notify_type" id="radioSelectedDate" value="selected_date" {{$seRequest->notify_type == 'selected_date' ? 'checked' : ''}} onchange="notify_radio('DateTime');"><i></i> Select date & time 
                </label>
            </div>
        </div>
        <div class="notify_box collapse Today">
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group input_wrap">
                        <label class="control-label">Notify in</label>
                        <select class="selectpicker select-custom" name="today_in_time" id="selectNotify" data-size="4">
                            <option value="30_minute" {{$seRequest->today_in_time == '00:30:00' ? 'selected' : ''}}>30 minutes</option>
                            <option value="1_hour" {{$seRequest->today_in_time == '01:00:00' ? 'selected' : ''}}>01 hour </option>
                            <option value="2_hour" {{$seRequest->today_in_time == '02:00:00' ? 'selected' : ''}}>02 hour </option>
                            <option value="3_hour" {{$seRequest->today_in_time == '03:00:00' ? 'selected' : ''}}>03 hour </option>
                            <option value="4_hour" {{$seRequest->today_in_time == '04:00:00' ? 'selected' : ''}}>04 hour </option>
                            <option value="5_hour" {{$seRequest->today_in_time == '05:00:00' ? 'selected' : ''}}>05 hour </option>
                        </select>
                    </div>
                </div>
            </div>
        </div>
        <div class="notify_box collapse DateTime">
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group input_wrap">
                        <label class="control-label">Select date</label>
                        <div class="dateicon">
                            <input type="text" name="notify_date" id="SelectDate01" readonly="true" class="form-control datetimepicker-input" data-target="#SelectDate01" data-toggle="datetimepicker" placeholder="DD/MM/YYYY"/>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="form-group input_wrap">
                        <label class="control-label">Select time</label>
                        <div class="timeicon">
                            <input type="text" name="notify_date_time" id="SelectTime01" readonly="true" class="form-control datetimepicker-input" data-target="#SelectTime01" data-toggle="datetimepicker" placeholder="HH/MM"/>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="form-group input_wrap">
                    <label class="control-label">Select category</label>
                    @php
                    $categories = \App\Http\Models\BankingCategory::getActiveCategories();
                    @endphp
                    <select class="selectpicker select-custom" name="category_id" onchange="getAllExecutiveByCategory($(this).val());
                            $(this).valid();" id="selectCategory" data-size="5">
                        @if(count($categories)>0)
                        @foreach($categories as $category)
                        <option value="{{$category->id}}" {{($category->id == $seRequest->category_id) ? 'selected' : ''}}>{{$category->name}}</option>
                        @endforeach
                        @endif
                    </select>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group input_wrap">
                    <label class="control-label">Select executive</label>
                    <select class="selectpicker select-custom" name="executive_id" id="selectExecutive" onchange="$(this).valid();" data-size="5">
                    </select>
                </div>
            </div>
        </div>
    </div>
    <div class="note border p-3 rounded">
        <label class="theme-color02">Note</label>
        <textarea class="form-control" name="notes" id="textRequestAddNote" rows="10" onkeyup="setGetNote($(this).val());">{{$seRequest->notes}}</textarea>
    </div>
    <div class="text-center">
        <button id="btnSubmitForm" type="submit" class="btn btn-primary text-uppercase ripple-effect-dark font-bk">FINISH CALL
            <i id="btnSubmitLoader" class="fa fa-spin fa-spinner" style="display: none;"></i>                                                                                    
        </button> 
    </div>
</form>
{!! JsValidator::formRequest('App\Http\Requests\Executive\AddEditNoteRequest','#EditSEquestForm') !!}                
<script>
    $(document).ready(function () {
        var categoryId = "{{ $seRequest->category_id }}";
        getAllExecutiveByCategory(categoryId);
        $('.select-custom').selectpicker();
        // date picker function
        var defaultDate = "{{$seRequest->notify_date}}";
        var currentDate = moment().format("L");
        if (defaultDate != "" && defaultDate != "0000-00-00" && defaultDate != '') {
            var newDate =  moment(defaultDate, "Y-M-DD").format("L");
        } else {
            var newDate = currentDate;
        }
        $('#SelectDate01').datetimepicker({
            focusOnShow: false,
//            format: 'DD-M-Y',
            format: 'L',
            ignoreReadonly: true,
            defaultDate: newDate,
            minDate: moment().format("L")
        });
    });

    // time picker function
    var dbTime = "{{$seRequest->notify_date_time}}";
    var newTime = moment(dbTime, "HH:mm a").format("hh:mm a");
    if (dbTime != '' && dbTime != '00:00:00') {
        var newHour = moment(newTime, "LTH").format("H");
        var newMinute = moment(newTime, "LTH").format("mm");
    } else {
        var newHour = moment().format("H");
        var newMinute = moment().format("mm");
    }
    $('#SelectTime01').datetimepicker({
        defaultDate: moment({
            hour: newHour,
            minute: newMinute,
        }),
//                minDate: moment({
//                hour: $('#SelectDate01').val() == moment().format("L") ?  moment().format("H") ? '',
//                        minute: $('#SelectDate01').val() == moment().format("L") ?  moment().format("mm") ? '',
//                }),
        focusOnShow: false,
        format: 'LT',
        ignoreReadonly: true,
    });

    // get all execuitive by category id
    function getAllExecutiveByCategory(categoryId) {
        var executiveId = "{{ Auth::guard()->user()->id }}";
        $.post("{{ url('get-executive-by-category') }}", {_token: "{{ csrf_token() }}", category_id: categoryId, executive_id: executiveId}, function (data) {
            $('#selectExecutive').html(data);
            $('#selectExecutive').selectpicker('refresh');
            if (categoryId != '' && categoryId != undefined)
            {
                $('#selectExecutive').selectpicker('val', executiveId);
                $('#selectExecutive').selectpicker('render');
            }
        });
    }

//       submit edit executive request form
    $(document).on('submit', '#EditSEquestForm', function (e) {
        e.preventDefault();
        if ($('#EditSEquestForm').valid()) {
            $('#btnSubmitForm').prop('disabled', true);
            $('#btnSubmitLoader').show();
            $.ajax({
                url: "{{ url('update-se-request') }}",
                data: $('#EditSEquestForm').serialize(),
                type: 'POST',
                dataType: 'JSON',
                success: function (response) {
                    if (response.success) {
                        toastrAlertMessage('success', response.message);
                        setTimeout(function () {
                            location.reload();
                        }, 1500);
                    } else {
                        toastrAlertMessage('error', response.message);
                        $('#btnSubmitForm').prop('disabled', false);
                    }
                    $('#btnSubmitLoader').hide();
                },
                error: function (err) {
                    var obj = jQuery.parseJSON(err.responseText);
                    for (var x in obj) {
                        toastrAlertMessage('error', obj[x]);
                    }
                    $('#btnSubmitForm').prop('disabled', false);
                }
            });
        }
    });
    
    $(document).ready(function () {
        var checkValue = $("input[name='status']:checked").val();
        if (checkValue == 'resolved') {
            $('.field_box').hide();
        }
        var checkValue1 = $("input[name='notify_type']:checked").val();
        if (checkValue1 == 'today') {
            $('.Today').show();
        } else if (checkValue1 == 'selected_date') {
            $('.DateTime').show();
        }
    });
    
    function status_radio(value) {
        var statusVal = $("input[name='notify_type']:checked").val();
        if (statusVal == 'today') {
            $('#radioToday').prop('checked', true);
        } else if (statusVal == 'when_online') {
            $('#radioWhenOnline').prop('checked', true);
        } else if (statusVal == 'selected_date') {
            $('#radioSelectedDate').prop('checked', true);
        } else {
            $('#radioWhenOnline').prop('checked', true);
        }
        $(".field_box").hide();
        $("." + value).show();
    }
    function notify_radio(value) {
        $(".notify_box").hide();
        $("." + value).show();
    }
</script>