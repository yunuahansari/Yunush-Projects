<!--header-->
<header class="header_inner fixed-top" id="top-header">
    <div class="container-fluid">
        <nav class="navbar navbar-light">
            <div class="navbar-brand">
                <a href="{{url('notification')}}" class="d-inline-block">
                    <h2 class="mb-0">LINKED ASSIST</h2>
                </a>
            </div>
            @php
            $authUser = \Auth::guard()->user();
            @endphp
            <ul class="nav ml-auto right-utility">
                <li class="nav-item dropdown user-avtar">
                    <a class="nav-link dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <img src="{{getImage($authUser->profile_image,'users','users')}}" class="rounded-circle">
                        <span class="username">{{ucfirst($authUser->contact_name)}}</span>
                    </a>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                        <a class="dropdown-item" href="javascript:void(0);" onClick="showUserProfile()">View Profile</a>
                        <a class="dropdown-item" href="{{url('logout')}}" onclick="event.preventDefault();
                                document.getElementById('logout-form').submit(); emitevent()">Logout</a> 
                        <form id="logout-form" action="{{url('logout')}}" method="POST" style="display: none;">
                            {{ csrf_field() }}
                        </form>                        
                    </div>
                </li>
            </ul>
        </nav>
    </div>
</header>