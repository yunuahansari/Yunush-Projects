<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        
        
        <link rel="apple-touch-icon" sizes="76x76" href="{{url('public/images/favicon/apple-touch-icon.png')}}">
		<link rel="icon" type="image/png" sizes="32x32" href="{{url('public/images/favicon/favicon-32x32.png')}}">
		<link rel="icon" type="image/png" sizes="16x16" href="{{url('public/images/favicon/favicon-16x16.png')}}">
		<link rel="manifest" href="{{url('public/images/favicon/site.webmanifest')}}">
		<link rel="mask-icon" href="{{url('public/images/favicon/safari-pinned-tab.svg')}}" color="#00c7ff">
		<meta name="msapplication-TileColor" content="#2d89ef">
		<meta name="theme-color" content="#0ab1ff">
        
        

        <link rel="stylesheet" href="{{url('public/css/iocnmoon.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/dataTables.bootstrap4.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/bootstrap.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/fontawesome.min.all.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/bootstrap-select.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/tempusdominus-bootstrap-4.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/custom.min.css')}}" type="text/css">
        <link rel="stylesheet" href="{{url('public/css/toastr.min.css')}}" type="text/css">

        <!-- js script -->
        <script src="{{url('public/js/jquery.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/jquery.dataTables.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/dataTables.bootstrap4.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/popper.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/bootstrap.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/bootstrap-select.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/moment.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/tempusdominus-bootstrap-4.min.js')}}" type="text/javascript"></script>
        <script src="{{url('public/js/jsvalidation.min.js')}}"></script>
        <script src="{{url('public/js/toastr.js')}}"></script>
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/2.3.6/fabric.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/2.0.4/socket.io.js"></script>
        <script src="{{url('public/js/prortc.js')}}"></script>
    
        <title>@yield('title') | {{env('app_name')}}</title>
    </head>
    <body class="">
        @guest
        <header class="header" id="main_header">
            <nav class="navbar navbar-light pl-0 pr-0">
                <div class="container">
                    <a href="{{url('/')}}" class="navbar-brand text-uppercase font-hy">
                        linked assist
                    </a>
                </div>
            </nav>
        </header>          
        @else        
        @include('executive.layouts.header_inner')   

        @endguest
        @yield('content')
        @include('executive.layouts.footer')    
         
            @if(!empty(Auth::guard()->user()->id))
           @php  $userId = Auth::guard()->user()->id; @endphp
            @endif
        <input type="hidden" name="hdnCustomerId" id="hdnCustomerId" value="">
<input type="hidden" name="hdnTicketId" id="hdnTicketId" value="">
        <script>
            
             socket = io.connect('https://linked-assist-webrtc.codiant.com');
   // socket.on('connect', function (data) {
        socket.emit('register',{'userID':<?php echo @$userId ?>})
        console.log("Connect");
        socket.on('show-online', function (data) {
            console.log(data);
            $("#customer_"+data.userJID).removeClass('offline').addClass('online');
            $("#show_login_status_"+data.userJID).html('online');
            $("#link_"+data.userJID).show();
        });
        socket.on('show-offline', function (data) {
          $("#customer_"+data.userJID).removeClass('online').addClass('offline');
          $("#show_login_status_"+data.userJID).html('offline');
          $("#link_"+data.userJID).hide();
        });
        
        //Receive Accept Confirmation Back to caller
        socket.on('get-accept-request',function(packet){
            $("#hdnSocketId").val(packet.socketId);
            var hdnCustomerId = $("#hdnCustomerId").val();
            get_call_page_content(hdnCustomerId);
        });
        
        socket.on('user-end-call',function(){
            openAddNoteModal();
        });
        
        // Receive Call Request From Customer
        socket.on("receive-call-request",function(packet){
            console.log("receive Call");
            prortc.joinRoom({
                room: packet.ticketId
            });
             socket.emit('join_room',{
                room: packet.ticketId
            });
            $("#hdnTicketId").val(packet.ticketId);
            var userJID = packet.userJID;
            $(".main-page").hide();
            $(".call-screen").show();
            $("#calling_customer_name").html($("#customerName_"+userJID).html());
            var customerImage = $("#customer_image_"+userJID).attr('src');
            $("#hdnCustomerId").val(userJID);
            $(".incomming").show();
            $(".outgoing").hide();
        });
        
        
            function request_to_call(customerId,ticketId,requestType,$requestId){
                $.ajax({
                    type: "POST",
                    data:{'customerId':customerId,ticketId:ticketId,requestType:requestType,$requestId:$requestId,_token: '{{csrf_token()}}' },
                    url: "{{url('create-call-request')}}",
                    dataType:"JSON",
                    success: function (response) {
                        if (response.success) {
                            if(requestType == "pending"){
                                $(".main-page").show();
                                $(".call-screen").hide();
                               // location.reload();
                            } else{
                                $(".main-page").hide();
                                $(".call-screen").show();
                                $("#calling_customer_name").html($("#customerName_"+customerId).html());
                                var customerImage = $("#customer_image_"+customerId).attr('src');
                                console.log(customerImage);
                                $("#calling_customer_image").attr("src",customerImage);
                                // For Initiate Call
                                $("#hdnCustomerId").val(customerId);
                                socket.emit('send-call-request', {'userJID': customerId,'callerId':<?php echo @$userId ?>,'ticketId':ticketId});
                                //socket.emit('send-call-request', {userJID: customerId});
                            }
                            $("#requestId").val(response.request_id);
                            setTimeout(function () {
                                request_to_call(customerId,ticketId,'pending',response.request_id);
                            }, 60000);

                        } else {
                            toastrAlertMessage('error', 'please try again');
                        }
                    }
                });
                    socket.emit('join_room',{
                      room: ticketId
                  });

                prortc.joinRoom({
                    room: ticketId
                });
    }
    
    function accept_call(){
        var hdnCustomerId = $("#hdnCustomerId").val();
        var hdnTicketId = $("#hdnTicketId").val();
        //Accept Call Request
        socket.emit('accept-call',{userJID:hdnCustomerId,ticketId:hdnTicketId});
        get_call_page_content(hdnCustomerId);
        console.log("Accept Call Praveen")
    }
    
    function get_call_page_content() {
        var id = $("#requestId").val();
        $.ajax({
            type: "POST",
            data: {'id': id, _token: '{{csrf_token()}}'},
            url: "{{url('linked-notes')}}",
            dataType: "JSON",
            success: function (response) {
                $(".main-page").show();
                $(".call-screen").hide();
                $(".actual-content").hide();
                $("#call-page-content").show();
                $("#call-page-content").html(response.html);
            }
        });
    }
    
    function reject_call(){
        var socketId = $("#hdnSocketId").val();
        var userId = $("#hdnCustomerId").val();
        console.log("Test end");
        socket.emit('end-user-call',{userId:userId});
        setTimeout(function(){
            location.reload();
        },1000);
    }
    
    
    function emitevent(){
        socket.emit('show-offline',{userId:<?php echo @$userId ?>})
    }
    
</script>
    </body>
</html>