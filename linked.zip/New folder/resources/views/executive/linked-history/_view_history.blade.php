<div class="modal-header align-items-center">
    <div class="col text-left p-0">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="col p-0 text-center">
        <h5 class="modal-title" id="viewHestoryModalLabel">HISTORY</h5>
    </div>
    <div class="col p-0 text-right">
        <a href="javascript:void(0)" onclick="editModalNote('{{$seRequest->id}}');" class="btn btn-secondary btn-icon"><i class="fas fa-pen"></i></a>
    </div>
</div>
<div class="modal-body">
    <div class="user-dtl-top d-sm-flex justify-content-between">
        <div class="left-dtl d-flex align-items-center">
            <div class="user-avtar">
                <img src="{{checkProfileImage(!empty($seRequest->customerDetail->profile_image) ? $seRequest->customerDetail->profile_image : '')}}" alt="User" class="rounded-circle">
            </div>
            <div class="user-name">
                <h3>{{!empty($seRequest->customerDetail->contact_name) ? ucfirst($seRequest->customerDetail->contact_name) : ''}}</h3>
                <p>{{!empty($seRequest->UserProfile->bussiness_name) ? $seRequest->UserProfile->bussiness_name : ''}}</p>
            </div>
        </div>
        <div class="right-dtl text-sm-right">
            <div class="user_status {{$seRequest->status == 'resolved' ? 'resolved' : 'pending'}}">
                <span>{{$seRequest->status}}</span>
            </div>
            <ul class="list-inline">
                <li class="list-inline-item">
                    <i class="icon-calendar"></i> <span>{{showFullMonthDateFormat($seRequest->created_at)}}</span>
                </li>
                <li class="list-inline-item">
                    <i class="icon-clock"></i> <span>{{$seRequest->call_time}} mins</span>
                </li>
            </ul>
        </div>
    </div>
    <div class="user-dtl-in">
        <p class="note">Note</p>
        <p>{{$seRequest->notes}}</p>
    </div>
</div>
