@if($seRequest->count()>0)
<table class="table no-border linkedhistory" id="data_table">
    <thead>
        <tr>
            <th>NAME</th>
            <th>ID</th>
            <th>CATEGORY</th>
            <th>TOTAL CALL TIME</th>
            <th>DATE OF CALL</th>
            <th>STATUS</th>
            <th width="140">ACTION</th>
        </tr>
    </thead>
    <tbody>
        @foreach($seRequest as $data)
        <tr>
            <td width="200">
                <div class="d-flex align-items-center">
                    <div class="user_img">
                        <img src="{{checkProfileImage(!empty($data->customerDetail->profile_image) ? $data->customerDetail->profile_image : '')}}" alt="user" class="rounded-circle">
                    </div>
                    <div class="user_detail">
                        <h4>{{!empty($data->customerDetail->contact_name) ? ucfirst($data->customerDetail->contact_name) : ''}}</h4>
                        <p class="mb-0">{{!empty($data->UserProfile->bussiness_name) ? $data->UserProfile->bussiness_name : ''}}</p>
                    </div>
                </div>
            </td>
            <td>ID: {{!empty($data->UserProfile->merchant_number) ? $data->UserProfile->merchant_number : ''}}</td>
            <td>{{!empty($data->BankCategory->name) ? $data->BankCategory->name : ''}}</td>
            <td>
                <div class="user_tym">
                    <i class="icon-clock"></i> {{$data->call_time}} mins
                </div>
            </td>
            <td>
                <div class="user_date">
                    <i class="icon-calendar"></i> 
                    {{showFullMonthDateFormat($data->created_at)}}
                </div>
            </td>
            <td>
                <div class="user_status {{$data->status == 'resolved' ? 'resolved' : 'pending'}}">
                    <span>{{$data->status}}</span>
                </div>
            </td>
            <td>
                <ul class="list_btns list-inline mb-0">
                    <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary btn-icon ripple-effect-dark" onClick="viewHestory('{{$data->id}}')"><i class="icon-eye"></i></a></li>
                    <li class="list-inline-item"><a href="javascript:void(0);" class="btn btn-secondary ripple-effect-dark btn-icon" onclick="editNote('{{$data->id}}');"><i class="icon-pencil"></i></a></li>
                </ul>
            </td>
        </tr>
        @endforeach
    </tbody>
</table>
@else
<div class="alert alert-danger text-center m-4">{{\Config::get('constants.no_record_found')}}</div>
@endif
<script>
//ripple-effect for button
    $('.ripple-effect, .ripple-effect-dark').on('click', function(e) {
    var rippleDiv = $('<span class="ripple-overlay">'),
            rippleOffset = $(this).offset(),
            rippleY = e.pageY - rippleOffset.top,
            rippleX = e.pageX - rippleOffset.left;
    rippleDiv.css({
    top: rippleY - (rippleDiv.height() / 2),
            left: rippleX - (rippleDiv.width() / 2),
    }).appendTo($(this));
    window.setTimeout(function() {
    rippleDiv.remove();
    }, 800);
    });

</script>
