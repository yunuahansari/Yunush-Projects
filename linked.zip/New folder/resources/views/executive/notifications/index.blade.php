@extends('executive.layouts.app')
@section('title', 'Notification')
@section('content')
@php
$currentRoute = Request::route()->getName();
use Illuminate\Support\Facades\Auth;
@endphp
<main class="main-content requests-page main-page" id="content">
    <section class="tabs_section">
        <ul class="list-unstyled tabs_links d-flex justify-content-start">
            <?php $userId = Auth::guard()->user()->id; ?>
            <li class="text-uppercase {{($currentRoute == 'executive-notification' )?'active':''}}"><a href="{{url('notification')}}">NOTIFICATIONS <span id="notificationCount">({{getUnreadNotificationCountByUserId($userId)}})</span></a></li>
            <li class="text-uppercase {{($currentRoute == 'executive-request' )?'active':''}}"><a href="{{url('customer-request')}}">CUSTOMER REQUESTS</a></li>
            <li class="text-uppercase {{($currentRoute == 'executive-history' )?'active':''}}"><a href="{{url('linked-history')}}">LINKED HISTORY</a></li>
        </ul>
        <div class="tabs_content">
            <div class="table-responsive actual-content" id="getnotifications">
                
            </div>
            <div class="table-responsive" id="call-page-content" style="display:none">

            </div>
        </div>
    </section>
</main>
@include('executive.layouts.call-screen')
<script>
    $(document).ready(function () {
        getNotificationslist();
    });
    function getNotificationslist() {
        $("#getnotifications").html('<div class="listloader text-center pb-4"><i class="fa-2x fa-spin fas fa-spinner"></i></div>');
        var url = '{{url("notification-list")}}';
        $.ajax({type: "GET", url: url,dataType: 'JSON',
            success: function (response) {
                
                    $("#getnotifications").html("");
                    $("#getnotifications").html(response.html);
                
            }
        });
    }
</script>
@endsection