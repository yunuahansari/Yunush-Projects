<table class="table no-border">
    <tbody>
        <?php
        if (count($notificationList) > 0) {
            foreach ($notificationList as $val) {
                ?>
                <tr>
                    <td align="right">
                        <div class="user_img">
                            <?php $image = \App\Http\Models\User::getUserDataByKey($val->from_id, 'profile_image'); ?>
                            <img src="{{getImage($image,'users','users')}}" alt="user" class="rounded-circle">
                        </div>
                    </td>
                    <td class="min200">
                        <div class="user_detail">
                            <h4><?php echo \App\Http\Models\User::getUserDataByKey($val->from_id, 'contact_name') ?></h4>
                            <p class="mb-0"><?php echo \App\Http\Models\User::getUserProfileDataByKey($val->from_id, 'bussiness_name') ?></p>
                        </div>
                    </td>
                    <td class="min1100"><?php echo $val->message; ?></td>
                    <td width="200">
                        <div class="user_tym">
                            <i class="icon-clock"></i>{{$val->created_at}}
                        </div>
                    </td>
                    <td><a href="{{url('/linked-notes')}}" class="btn btn-primary ripple-effect-dark"><i class="icon-call"></i> LINK</a></td>
                </tr>
            <?php }
        } else {
            ?>
            <tr>
                <td colspan="4"><div class="alert alert-danger">No Notification Found</div></td>
            </tr>
        <?php } ?>
    </tbody>
</table>
<script>
    //ripple-effect for button
    $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
        var rippleDiv = $('<span class="ripple-overlay">'),
                rippleOffset = $(this).offset(),
                rippleY = e.pageY - rippleOffset.top,
                rippleX = e.pageX - rippleOffset.left;

        rippleDiv.css({
            top: rippleY - (rippleDiv.height() / 2),
            left: rippleX - (rippleDiv.width() / 2),
            // background: $(this).data("ripple-color");
        }).appendTo($(this));

        window.setTimeout(function () {
            rippleDiv.remove();
        }, 800);
    });
</script>