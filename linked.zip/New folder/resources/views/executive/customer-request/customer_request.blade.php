@extends('executive.layouts.app')
@section('title', 'Customer Request')
@section('content')
@php
$currentRoute = Request::route()->getName();
use Illuminate\Support\Facades\Auth;
@endphp

<main class="main-content requests-page main-page" id="content">
    <section class="tabs_section">
        <?php $userId = Auth::guard()->user()->id; ?>
        <ul class="list-unstyled tabs_links d-flex justify-content-start">
            <li class="text-uppercase {{($currentRoute == 'executive-notification' )?'active':''}}"><a href="{{url('notification')}}">NOTIFICATIONS <span>({{getUnreadNotificationCountByUserId($userId)}})</span></a></li>
            <li class="text-uppercase {{($currentRoute == 'executive-request' )?'active':''}}"><a href="{{url('customer-request')}}">CUSTOMER REQUESTS</a></li>
            <li class="text-uppercase {{($currentRoute == 'executive-history' )?'active':''}}"><a href="{{url('linked-history')}}">LINKED HISTORY</a></li>
        </ul>
        <div class="tabs_content">
            <div class="table-responsive actual-content" id="divCustomerRequest">

            </div>
            <div class="table-responsive" id="call-page-content" style="display:none">

            </div>
        </div>
    </section>
    
</main>

@include('executive.layouts.call-screen')


<script>
$(document).ready(function () {
    getCutomerRequest();
});

function getCutomerRequest() {
    pageDivLoader('show', 'divCustomerRequest');
    $.ajax({
        type: "GET",
        url: "{{url('customer-request-list')}}",
        success: function (response) {
            if (response.success) {
                $("#call-page-content").hide();
                $('#divCustomerRequest').show();
                $('#divCustomerRequest').html(response.html);
            } else {
                toastrAlertMessage('error', response.message);
            }
        },
        error: function (err) {
            var obj = jQuery.parseJSON(err.responseText);
            for (var x in obj) {
                toastrAlertMessage('error', obj[x]);
            }
        }
    });
}
</script>
 

@endsection