@if($requests->count() > 0)
<table class="table no-border">      
    <tbody>
        @foreach($requests as $request)
        <?php
        $ticket = getTicketById($request->ticket_id);
        $loginStatus = \App\Http\Models\User::getUserDataByKey($request->customer_id, 'online_status');
        ?>
        <tr>
            <td width="100" align="right">
                <div class="user_img">
                    <img id="customer_image_<?php echo $request->customer_id ?>" src="{{getImage(!empty($request->customerDetail->profile_image) ? $request->customerDetail->profile_image : '','users','users')}}" alt="user" class="rounded-circle">
                    <span id="customer_<?php echo $request->customer_id ?>" class="status <?php echo $loginStatus ?>"></span>
                </div>
            </td>
            <td class="min200">
                <div class="user_detail">
                    <h4 id="customerName_<?php echo $request->customer_id ?>">{{!empty($request->customerDetail->contact_name) ? ucfirst($request->customerDetail->contact_name) : ''}}</h4>
                    <p class="mb-0">{{!empty($request->customerDetail->bank->name) ? $request->customerDetail->bank->name : ''}}</p>
                </div>
            </td>
            <td class="min1100">{{$request->notes}}</td>
            <td class="min150">
                <div class="user_tym">
                    <i class="icon-clock"></i> {{dateDayAgoFormat($request->created_at)}}
                </div>
            </td>
            <td width="230" id="show_login_status_<?php echo $request->customer_id ?>"><?php echo $loginStatus ?></td>
            <td width="150">
                <?php 
                if($loginStatus == 'online'){
                    $style = 'block';
                 } else { 
                     $style = 'none';
                     } ?>
                <!--<a href="{{url('/linked-notes',$request->id)}}" id="link_<?php //echo $request->customer_id ?>" class="btn btn-primary ripple-effect-dark" style="display: <?php echo $style ?>"><i class="icon-call"></i> LINK</a>-->
                <a href="javascript:void(0)" onclick="request_to_call('{{$request->customerDetail->id}}','{{$ticket}}','missed_request','')" id="link_<?php echo $request->customer_id ?>" class="btn btn-primary ripple-effect-dark" style="display: <?php echo $style ?>"><i class="icon-call"></i> LINK</a>
            </td>
        </tr>
        @endforeach
    </tbody> 
</table>
{{ $requests->links() }}
@else
<div class="alert alert-danger text-center m-4">{{\Config::get('constants.no_record_found')}}</div>
@endif
<?php $userId = Auth::guard()->user()->id; ?>

<script>
    callInterval = null;
    
        
   // });
    
    
    $(document).ready(function () {
        $(".pagination li a").on('click', function (e) {
            e.preventDefault();
            pageDivLoader('show', 'divCustomerRequest');
            var $this = $(this);
            var pageLink = $this.attr('href');
            $.ajax({
                type: 'GET',
                url: pageLink,
                success: function (response) {
                    $('.pagination:first').remove();
                    $("#divCustomerRequest").html(response.html);
                }
            });
        });
       
    });

    //ripple-effect for button
    $('.ripple-effect, .ripple-effect-dark').on('click', function (e) {
        var rippleDiv = $('<span class="ripple-overlay">'),
                rippleOffset = $(this).offset(),
                rippleY = e.pageY - rippleOffset.top,
                rippleX = e.pageX - rippleOffset.left;

        rippleDiv.css({
            top: rippleY - (rippleDiv.height() / 2),
            left: rippleX - (rippleDiv.width() / 2),
            // background: $(this).data("ripple-color");
        }).appendTo($(this));

        window.setTimeout(function () {
            rippleDiv.remove();
        }, 800);
    });
    
    
    
    
</script>
  