<?php

Route::get('dashboard', 'DashboardController@index')->name('admin-dashboard');
Route::post('request-chart-list', 'DashboardController@requestChartList');

/* Change password */
Route::get('change-password', 'ChangePasswordController@changePassword')->name('admin-change-password');
Route::post('update-password', 'ChangePasswordController@updatePassword');
Route::get('view-profile', 'ChangePasswordController@viewProfile')->name('view-profile');
Route::get('edit-profile', 'ChangePasswordController@editProfile')->name('edit-profile');
Route::post('update-profile', 'ChangePasswordController@updateProfile');
Route::post('/admin-image-upload', 'DashboardController@adminImageUpload');
Route::get('user-change-password/{id}', 'DashboardController@changePasswordById');
Route::get('ratings', 'DashboardController@ratings')->name('ratings');
Route::post('load-rating-list', 'DashboardController@loadRatingList');
/* End */

/* image cropper routes for profile image */
Route::post('/upload-media-image', 'DashboardController@uploadMedia');
Route::get('/load-image-cropper', 'DashboardController@loadImageCropper');
Route::post('/upload-cropped-image', 'DashboardController@uploadCroppedPicture');
/* End */

Route::post('change-user-status', 'DashboardController@changeUserStatus');
Route::post('update-user-password', 'DashboardController@updateUserPassword');
Route::get('/send-detail/{id}', 'DashboardController@sendDetail');

/* Manager Section */
Route::get('/manager', 'ManagerController@managerList')->name('manage-user');
Route::post('/manager-list', 'ManagerController@listAllManagers');
Route::get('/add-manager', 'ManagerController@addManagerForm')->name('manage-user');
Route::post('/add-manager', 'ManagerController@addManager');
Route::get('/manager-edit/{id}', 'ManagerController@managerEdit')->name('manage-user');
Route::post('/manager-update', 'ManagerController@managerUpdate');
Route::get('/manager-view/{id}', 'ManagerController@managerView')->name('manage-user');
Route::get('/manager-csv-download', 'ManagerController@downloadManagerCsv');
/*  End */

/* Executive Section */
Route::get('manage-executives', 'ExecutivesController@index')->name('manage-executives');
Route::post('executives-list', 'ExecutivesController@allExecutives');
Route::get('add-executive', 'ExecutivesController@addExecutive')->name('manage-executives');
Route::post('save-executive', 'ExecutivesController@saveExecutive');
Route::post('update-executive', 'ExecutivesController@updateExecutive');
Route::get('edit-executive/{id}', 'ExecutivesController@editExecutive')->name('manage-executives');
Route::get('view-executive/{id}', 'ExecutivesController@viewExecutive')->name('manage-executives');
Route::get('merchant-assigned-list/{id}', 'ExecutivesController@assignedMerchantList');
Route::get('support-executive-request', 'ExecutivesController@seRequest')->name('support-executive-request');
Route::post('se-request-list', 'ExecutivesController@listSeRequest');
Route::get('support-executive-view/{id}', 'ExecutivesController@seRequestView')->name('support-executive-request');
Route::get('support-executive-view-list', 'ExecutivesController@seRequestViewList');
Route::get('support-executive-request-note-view/{id}', 'ExecutivesController@seRequestNoteView')->name('support-executive-request');
Route::get('/executive-csv-download', 'ExecutivesController@downloadExecutiveCsv');
Route::get('/executive-request-csv-download', 'ExecutivesController@downloadExecutiveRequestCsv');
Route::post('get-executive-by-manager', 'ExecutivesController@getExecutiveByManager');
/*  End */

/* Executive Section */
Route::get('manage-merchant', 'MerchantController@index')->name('manage-merchant');
Route::post('merchant-list', 'MerchantController@allMerchant');
Route::get('add-merchant', 'MerchantController@addMerchant')->name('manage-merchant');
Route::post('save-merchant', 'MerchantController@saveMerchant');
Route::get('edit-merchant/{id}', 'MerchantController@editMerchant')->name('manage-merchant');
Route::post('update-merchant', 'MerchantController@updateMerchant');
Route::get('view-merchant/{id}', 'MerchantController@viewMerchant')->name('manage-merchant');
Route::get('linked-support/{id}', 'MerchantController@linkedSupport')->name('manage-merchant');
Route::post('linked-support-list', 'MerchantController@linkedSupportList')->name('manage-merchant');
Route::get('merchant-linked-executive/{id}', 'MerchantController@merchantLinkedExcutives')->name('manage-merchant');
Route::get('merchant-linked-executive-list', 'MerchantController@merchantLinkedExcutiveList');
Route::get('/merchant-csv-download', 'MerchantController@downloadMerchantCsv');
Route::get('/merchant-history-csv-download', 'MerchantController@downloadMerchantHistoryCsv');
Route::get('/merchant-linked-executive-csv-download/{id}', 'MerchantController@downloadMerchantLinkedExecutiveCsv');

Route::get('merchant-request', 'MerchantController@merchantRequest')->name('merchant-request');
Route::post('merchant-request-list', 'MerchantController@listMerchantRequest');
Route::get('merchant-request-view/{id}', 'MerchantController@merchantRequestView')->name('merchant-request');
Route::get('unassigned-request', 'MerchantController@merchantUnassignedRequest')->name('unassigned-request');
Route::get('unassigned-request-list', 'MerchantController@listUnassignedRequest');
Route::get('unassigned-request-view', 'MerchantController@unassignedRequestView')->name('unassigned-request');
Route::get('edit-merchant-request-modal/{id}', 'MerchantController@editMerchantRequestModal');
Route::post('update-merchant-request', 'MerchantController@updateMerchantRequest');
/*  End */

/* Document Section */
Route::get('/documents', 'DocumentController@documentList')->name('documents');
Route::post('/document-list', 'DocumentController@listAllDocument');
Route::get('/add-document', 'DocumentController@addDocumentForm')->name('documents');
Route::post('/add-document', 'DocumentController@addDocument');
Route::get('/document-view/{id}', 'DocumentController@documentView')->name('documents');
Route::get('/document-edit/{id}', 'DocumentController@documentEdit')->name('documents');
Route::post('/document-update', 'DocumentController@documentUpdate');
Route::get('/delete-document/{id}', 'DocumentController@documentDelete');
/*  End */

/* Categoty Section */
Route::get('/categories', 'CategoryController@categoryList')->name('categories');
Route::post('/category-list', 'CategoryController@listAllCategories');
Route::get('/category-edit/{id}', 'CategoryController@categoryEdit')->name('categories');
Route::post('/category-update', 'CategoryController@categoryUpdate');
/*  End */

/* Bank Section */
Route::get('/banks', 'BankController@bankList')->name('banks');
Route::post('/bank-list', 'BankController@listAllbanks');
Route::get('/delete-bank/{id}', 'BankController@bankDelete');
Route::get('/bank-edit/{id}', 'BankController@bankEdit')->name('banks');
Route::post('/bank-update', 'BankController@bankUpdate');
Route::post('/active-inactive-bank/{id}', 'BankController@activeInactiveBank');
/*  End */

/* Call Request */
Route::get('/call-request', 'CallRequestController@callRequestList')->name('call-request');
Route::post('/call-request-list', 'CallRequestController@listAllCallRequest');
Route::get('call-request-view/{id}', 'CallRequestController@callRequestView')->name('call-request');
Route::get('/call-request-csv-download', 'CallRequestController@downloadCallRequestCsv');
/* End */

/* notification routes */
Route::get('notifications', 'NotificationController@notifications')->name('notifications');
Route::get('notification-list', 'NotificationController@listNotificationList');
Route::get('load-notification-list', 'NotificationController@loadNotificationList');
Route::get('load-notification-count', 'NotificationController@loadNotificationCount');
Route::post('update-notification-list', 'NotificationController@updateNotificationList');
/* End */

/* Contact Admin */
Route::get('/contact-admin', 'ContactAdminController@contactAdminList')->name('contact-admin');
Route::post('/contact-admin-list', 'ContactAdminController@listAllContactAdmin');
Route::get('contact-admin-view', 'ContactAdminController@contactAdminView')->name('contact-admin');
/* End */
