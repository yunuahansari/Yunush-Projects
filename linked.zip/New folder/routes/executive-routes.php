<?php

/* notifications routes */
Route::get('/notification', 'NotificationController@index')->name('executive-notification');
Route::get('/notification-list', 'NotificationController@notificationList');

/* customer request routes */
Route::get('/customer-request', 'CustomerRequestController@index')->name('executive-request');
Route::get('/customer-request-list', 'CustomerRequestController@customerRequestList');
Route::post('/create-call-request', 'CustomerRequestController@createCallRequest');
Route::post('/get-call-content', 'LinkedNotesController@getCallContent');
Route::post('/update-call-status', 'LinkedNotesController@updateCallStatus');


/* linked history routes */
Route::get('/linked-history', 'LinkedHistoryController@index')->name('executive-history');
Route::get('/linked-history-list', 'LinkedHistoryController@linkedHistoryList');
Route::get('/linked-history-view', 'LinkedHistoryController@linkedHistoryView');
Route::get('/linked-history-edit', 'LinkedHistoryController@linkedHistoryEdit');
Route::post('/update-se-request', 'LinkedHistoryController@updateExecutiveRequest');

/* linked notes routes */
Route::post('/linked-notes', 'LinkedNotesController@index');
Route::post('/executive-document-list', 'LinkedNotesController@executiveDocumentsList');
Route::get('/linked-merchant-notes-history-list/{id}', 'LinkedNotesController@linkedMerchantNotesHistoryList');
Route::get('/load-add-note-modal/{id}', 'LinkedNotesController@loadAddNoteModal');

/* dashboard rouets */
Route::get('/user-profile', 'DashboardController@viewUserProfile');

/* select executive by category */
Route::post('get-executive-by-category', 'DashboardController@getExecutiveByCategory');

Route::post('/upload-image', 'LinkedNotesController@uploadImage');