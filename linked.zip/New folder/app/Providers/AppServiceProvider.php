<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Request;
use DB;

class AppServiceProvider extends ServiceProvider {

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot() {
        Schema::defaultStringLength(191);

        /* validations */
        Validator::extend('valid_email', function ($attribute, $value, $parameters, $validator) {
            $user = \DB::table('users')->where('email', '=', $value)->get();
            if ($user->count() > 0) {
                return true;
            } else {
                return false;
            }
        });

        Validator::extend('check_matched_email', function ($attribute, $value, $parameters, $validator) {
            $user = \DB::table('users')->where('id', '!=', Auth::user()->id)->where('email', '=', $value)->get();
            if ($user->count() > 0) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('check_email_format', function ($attribute, $value, $parameters, $validator) {
            if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('check_matched_username', function ($attribute, $value, $parameters, $validator) {
            $userId = Auth::user()->id;
            $user = \DB::table('users')->where('id', '!=', $userId)->where('username', '=', $value)->get();
            if ($user->count() > 0) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('current_password', function ($attribute, $value, $parameters, $validator) {
            if (!empty(\Auth::guard(getAuthGuard())->user()->id)) {
                $password = \Auth::guard(getAuthGuard())->user()->password;
            }
            return \Illuminate\Support\Facades\Hash::check($value, $password);
        });

        /* check email type if admin */
        Validator::extend('admin_email', function ($attribute, $value, $parameters, $validator) {
            $user = \DB::table('users')->where('email', '=', $value)->where('role', '=', 'admin')->get();
            if ($user->count() > 0) {
                return true;
            } else {
                return false;
            }
        });

        Validator::extend('manager_email', function ($attribute, $value, $parameters, $validator) {
            $user = \DB::table('users')->where('email', '=', $value)->where('role', '=', 'manager')->get();
            if ($user->count() > 0) {
                return true;
            } else {
                return false;
            }
        });

        Validator::extend('check_email_format', function ($attribute, $value, $parameters, $validator) {
            if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                return false;
            } else {
                return true;
            }
        });

        Validator::extend('phone_format', function ($attribute, $value, $parameters, $validator) {
            if ($value != "") {
                return preg_match("/^(\+\d{1,3}[- ]?)?\d{10}$/", $value);
            } else {
                return true;
            }
        });

        Validator::extend('email_status_active', function ($attribute, $value, $parameters, $validator) {
            $user = \DB::table('users')->where('email', '=', $value)->where('status', 'active')->first();
            if (!empty($user)) {
                return true;
            } else {
                return false;
            }
        });

        Validator::extend('current_user_password', function ($attribute, $value, $parameters, $validator) {
            $post = Request::all();
            $user = \DB::table('users')->where('id', $post['user_id'])->first();
            if (!empty($user)) {
                $password = $user->password;
            }
            return \Illuminate\Support\Facades\Hash::check($value, $password);
        });

        Validator::extend('without_spaces', function ($attribute, $value, $parameters, $validator) {
            return preg_match('/^\S*$/u', $value);
        });

        /* validation for check unique email in database witch status is not deleted */
        Validator::extend('email_unique_not_deleted', function ($attribute, $value, $parameters, $validator) {
            $user = \DB::table('users')->where('email', $value)->where('status', '!=', 'deleted')->first();
            if (!empty($user)) {
                return false;
            }
            return true;
        });

        /* validation for check unique email expecting current user in database witch status is not deleted */
        Validator::extend('email_matched_not_deleted', function ($attribute, $value, $parameters, $validator) {
            $post = Request::all();
            if (isset($post['managerId'])) {
                $userId = $post['managerId'];
            } else {
                $userId = $post['user_id'];
            }
            $user = \DB::table('users')->where('id', '!=', $userId)->where('email', $post['email'])->where('status', '!=', 'deleted')->first();
            if (!empty($user)) {
                return false;
            }
            return true;
        });

        /* validation for check no spaces contain in field */
        Validator::extend('remove_spaces', function($attribute, $value, $parameters, $validator) {
            if (trim($value) == '') {
                return false;
            }
            return true;
        });

        /* validation for check unique username in database witch status is not deleted */
        Validator::extend('username_unique_not_deleted', function ($attribute, $value, $parameters, $validator) {
            $user = \DB::table('users')->where('username', $value)->where('status', '!=', 'deleted')->first();
            if (!empty($user)) {
                return false;
            }
            return true;
        });

        /* validation for check unique username expecting current user in database witch status is not deleted */
        Validator::extend('username_matched_not_deleted', function ($attribute, $value, $parameters, $validator) {
            $post = Request::all();
            $user = \DB::table('users')->where('id', '!=', $post['userId'])->where('username', $post['username'])->where('status', '!=', 'deleted')->first();
            if (!empty($user)) {
                return false;
            }
            return true;
        });

        /* validation for check unique ID number in database witch status is not deleted */
        Validator::extend('id_number_unique_not_deleted', function ($attribute, $value, $parameters, $validator) {
            $user = \DB::table('user_profiles')->join('users', 'users.id', 'user_profiles.user_id')
                            ->where('users.status', '!=', 'deleted')
                            ->where('user_profiles.executive_number', $value)->first();
            if (!empty($user)) {
                return false;
            }
            return true;
        });

        /* validation for check unique id number expecting current user in database witch status is not deleted */
        Validator::extend('id_number_matched_not_deleted', function ($attribute, $value, $parameters, $validator) {
            $post = Request::all();
            $user = \DB::table('user_profiles')->join('users', 'users.id', 'user_profiles.user_id')
                            ->where('users.status', '!=', 'deleted')
                            ->where('user_profiles.executive_number', $value)
                            ->where('users.id', '!=', $post['user_id'])->first();
            if (!empty($user)) {
                return false;
            }
            return true;
        });
    }

}
