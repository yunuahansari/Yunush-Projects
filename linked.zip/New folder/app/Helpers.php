<?php

use Carbon\Carbon;

function sendMail($data) {
    try {
        switch ($data['request']) {
            case "admin_forgot_password":
                Mail::send('emails.admin_forgot_password', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(\Config::get('constants.from_email'), 'Linked Assist')
                            ->subject($data['subject']);
                });
                break;

            case "manager_forgot_password":
                Mail::send('emails.manager_forgot_password', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(\Config::get('constants.from_email'), 'Linked Assist')
                            ->subject($data['subject']);
                });
                break;
            case "change_password":
                Mail::send('emails.subadmin_new_credential', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(\Config::get('constants.from_email'), 'Linked Assist')
                            ->subject($data['subject']);
                });
                break;
            case "user_mail":
                Mail::send('emails.user_credentials', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(\Config::get('constants.from_email'), 'Linked Assist')
                            ->subject($data['subject']);
                });
                break;
            case "change_password_mail":
                Mail::send('emails.change_user_password', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(\Config::get('constants.from_email'), 'Linked Assist')
                            ->subject($data['subject']);
                });
                break;
            case "send_detail_mail":
                Mail::send('emails.send_detail_mail', ['data' => $data], function ($message) use ($data) {
                    $message->to($data['email'])
                            ->from(\Config::get('constants.from_email'), 'Linked Assist')
                            ->subject($data['subject']);
                });
                break;
            default:
                break;
        }
        return true;
    } catch (Exception $e) {
        return $e->getMessage();
    }
}

/*
 * get image url and set image path
 */

function getImage($image, $folder = null, $type) {
    if ($type == 'users') {
        $src = url('public/admin-manager-assets/images/default-user.jpg');
    }
    $fileName = public_path() . '/uploads/' . $folder . '/' . $image;
    if (!empty($image) && file_exists($fileName)) {
        $src = url('public/uploads/' . $folder . '/' . $image);
    }
    return $src;
}

/*
 * get full name
 */

function getFullName($firstName, $lastName) {
    return $firstName . ' ' . $lastName;
}

/*
 * return database date format
 * 2018-12-01
 */

function getDBdateFormat($date) {
    return date('Y-m-d', strtotime($date));
}

/*
 * show date format from database
 *   04-21-2019
 */

function showDateFormat($date) {
    return date('d-m-Y', strtotime($date));
}

/*
 * show date format from database
 *   04 Aug 2019
 */

function showFullMonthDateFormat($date) {
    return date('d M Y', strtotime($date));
}

/*
 * show date time format from database
  04-21-2019 - 10:40 AM
 */

function showDateTimeFormat($date) {
    return date('d-m-Y - h:i A', strtotime($date));
}

/*
 * show full date format from database
  March-20-2018
 */

function showFullDateFormat($date) {
    return date('M-d-Y', strtotime($date));
}

/*
 * show full date format from database
  March-20-2018 - 10:40 AM
 */

function showFullDateTimeFormat($date) {
    return date('M-d-Y - h:i A', strtotime($date));
}

/*
 * show date time format with second
  04-21-2019 - 10:40 AM
 */

function showDateTimeFormatSecond($date) {
    return date('d-m-Y h:i:s', strtotime($date));
}

/*
 * show difference day , hours date format from database
  1 day ago , 1 hour ago
 */

function dateDayAgoFormat($date) {
    return Carbon::parse($date)->diffForHumans();
}

/*
 * function for get guard name.
 */

function getAuthGuard() {
    if (Auth::guard('admin')->check()) {
        $guard = 'admin';
    } else if (Auth::guard('manager')->check()) {
        $guard = 'manager';
    } else {
        $guard = 'web';
    }
    return $guard;
}

/**
 *  unlink image
 * */
//function unlinkFile($fileName, $folder) {
//    $filePath = public_path("uploads/") . $folder . '/' . $fileName;
//    unlink($filePath);
//}

/*
 * Function for text char limit.
 */

function getLimitText($limit, $text) {
    $string = substr($text, 0, $limit);
    if (strlen($text) > $limit) {
        $string .= '...';
    };
    return $string;
}

function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

//Rahul : check user image method
function checkProfileImage($image) {
    $src = url('public/admin-manager-assets/images/default-user.jpg');
    $fileName = public_path() . '/uploads/users/' . $image;
    if (filter_var($image, FILTER_VALIDATE_URL) != FALSE) {
        $src = $image;
    } elseif (!empty($image) && file_exists($fileName)) {
        $src = url('public/uploads/users/' . $image);
    }
    return $src;
}

/*
 * Function for get all executives count by manager id.
 */

function getAllExectiveCountByManager($id) {
    return \App\Http\Models\User::getAllExecutivesByManager('', 'count');
}

/*
 * Function for get all merchant count by manager id.
 */

function getAllMerchantCountByManager($id) {
    return \App\Http\Models\User::getAllMerchantByManager($id)->count();
}

/*
 * Function for get count of all merchant request rised by manager id.
 */

function getAllRequestRisedCountByManager() {
    $post = [];
//    return \App\Http\Models\CallRequest::getAllMerchantRequestHistory($post, 'request_count_manager');
    return \App\Http\Models\CallRequest::allCallRequestCount('manager');
}

/*
 * Function for create username.
 */

function getUserName($firstName, $companyName, $userId) {
    $name = preg_replace("/[^a-zA-Z0-9]+/", "", $firstName);
    $companyName = preg_replace("/[^a-zA-Z0-9]+/", "", $companyName);
    return trim(strtolower($name) . $companyName . $userId);
}

/*
 * function for get user categories
 */

function getUserCategory($userCategory) {
    $catName = '';
    if (!empty($userCategory)) {
        $expCategoryId = explode(',', $userCategory);
        if (!empty($expCategoryId)) {
            foreach ($expCategoryId as $catId) {
                $categoryModel = \App\Http\Models\BankingCategory::where(['id' => $catId])->first();
                if (!empty($categoryModel)) {
                    $catName .= $categoryModel->name . ',';
                }
            }
        }
    }
    return rtrim($catName, ',');
}

/*
 * function for get user categories
 */

function getExecutiveCategoryName($exeId) {
    $catName = '';
    $executiveCategory = \App\Http\Models\ExecutiveCategory::getCategoriesById($exeId);
    if (!empty($executiveCategory)) {
        $catArr = [];
        foreach ($executiveCategory as $exeCat) {
            $categoryModel = \App\Http\Models\BankingCategory::getCategoryById($exeCat->category_id);
            if (!empty($categoryModel)) {
                $catName .= $categoryModel->name . ',';
            }
        }
    }
    return rtrim($catName, ',');
}

/*
 * function for get dycripted base64 string
 */

function decodeString($string) {
    return base64_decode($string);
}

/*
 * function for get document url
 */

function getDocUrl($doc) {
//    $src = url('public/admin-manager-assets/documents/default.pdf');
    $fileName = public_path() . '/uploads/documents/' . $doc;
    if (filter_var($doc, FILTER_VALIDATE_URL) != FALSE) {
        $src = $doc;
    } elseif (!empty($doc) && file_exists($fileName)) {
        $src = url('public/uploads/documents/' . $doc);
    } else {
        $src = "";
    }
    return $src;
}

// Praveen Commit: Get Unread Notification Count
function getUnreadNotificationCountByUserId($userId) {
    $notificationCount = App\Http\Models\Notification::where(['type' => 'customer_call_request', 'to_id' => $userId, 'read_status' => 0])->count();
    return $notificationCount;
}

function getMerhcantCountByExcutive($id) {
    return \App\Http\Models\User::getMerhcantCountByExcutive($id);
}

// Rahul: Get Category By Executive
function getCategoryByExecutive($id) {
    $categoryName = array();
    $data = \App\Http\Models\ExecutiveCategory::getCategoriesByExecutiveId($id);
    if ($data->count() > 0) {
        foreach ($data as $cat) {
            $categoryName[] = $cat->name;
        }
        return $result = implode(',', $categoryName);
    }
    return '-';
}

// get manager by executive id
function getManagerByExecutiveId($id) {
    return App\Http\Models\ExecutiveManagerRelation::getManagerByExecutiveId($id);
}

// Rahul : Get Unread Notification Count By Admin
function loadNotificationCount($userId) {
    $notification = App\Http\Models\Notification::where('to_id', $userId)->where('read_status', 0)->count();
    return $notification;
}

// Rahul : Get Unread Notification Count By Admin
function updateNotificationList($userId) {
    $notification = App\Http\Models\Notification::where('to_id', $userId)->where('read_status', 0)->update(['read_status' => 1]);
    return $notification;
}


//Praveen
function getTicketById($ticketId) {
    $ticketData = App\Http\Models\Ticket::where(['id' => $ticketId])->first();
    if (!empty($ticketData)) {
        return $ticketData->ticket_number;
    } else {
        return "";
    }
}

function getTicketDataByNumber($ticketNumber) {
    $ticketData = App\Http\Models\Ticket::where(['ticket_number' => $ticketNumber])->first();
    return $ticketData;
}
