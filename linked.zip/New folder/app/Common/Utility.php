<?php

namespace App\Common;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\models\ContestListings;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Exception;
//use App\Models\User;
use App\Http\Models\Notification;
use App\Http\Models\User;

class Utility {

    //notification code 

    public static function FcmPushNotification($registatoinIds, $message, $user_type, $data = array(), $userId, $to_id,$saveType='save') {
        if ($user_type == 'executive') {
            $API_ACCESS_KEY = \Config::get('constants.executive_api_access_key');
        } else {
            $API_ACCESS_KEY = \Config::get('constants.customer_api_access_key');
        }
        if (!isset($API_ACCESS_KEY)) {
            return false;
        }

        $url = 'https://fcm.googleapis.com/fcm/send';
        $fields = array(
            'registration_ids' => $registatoinIds,
            //'data' => ,
        );
        $headers = array
            (
            'Authorization: key=' . $API_ACCESS_KEY,
            'Content-Type: application/json'
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
//         print_r($headers); die;
        $data = json_decode($result);
        echo "<pre>";
        print_r($data);
        exit;
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }
        if ($data->success == 1) {
            $notificationType = "missed_call";
            $data = [];
            if($saveType == 'save'){
                self::saveNotification($userId, $message, $notificationType, $data, $to_id);
            }
            curl_close($ch);
            return true;
        } else {
            curl_close($ch);
            return false;
        }
    }

    // Send Ios Notification Using P8 File
    public static function APNSPushDeviceNotification($deviceId, $message, $user_type, $data = array(), $userId, $to_id,$saveType='save') {
        try {
            $authKeyId = \Config::get('constants.auth_key'); // your p8 file 
            $keyId = \Config::get('constants.key_id'); // Your Bundle ID
            $teamId = \Config::get('constants.team_id'); //Your Team ID (see Developer Portal)
            $bundelId = ($user_type == 'executive') ? 'com.codiant.LinkedAssistSE' : 'com.codiant.LinkedAssistCustomer'; // Your Key ID
            $authKey = "$authKeyId";
            $arClaim = ['iss' => $teamId, 'iat' => time()];
            $arParam['p_key'] = file_get_contents(app_path() . $authKey);
            $arParam['header_jwt'] = \App\Http\Models\Jwt::encode($arClaim, $arParam['p_key'], $keyId, 'RS256');
            $body = $message; //body message
            $arSendData = array();
            $url_cnt = "https://www.google.com";
            $arSendData['aps']['alert']['title'] = sprintf("Notification Title"); // Notification title
            $arSendData['aps']['alert']['body'] = sprintf($body); // body text
            $arSendData['data']['jump-url'] = $url_cnt; // other parameters to send to the app
            $sendDataJson = json_encode($arSendData);
            $endPoint = 'https://api.development.push.apple.com/3/device'; // https://api.push.apple.com/3/device
            $ar_request_head[] = sprintf("content-type: application/json");
            $ar_request_head[] = sprintf("authorization: bearer %s", $arParam['header_jwt']);
            $ar_request_head[] = sprintf("apns-topic: %s", $bundelId);
            $dev_token = $deviceId;  // Device token
            $url = sprintf("%s/%s", $endPoint, $deviceId);
            $ch = curl_init($url);

            curl_setopt($ch, CURLOPT_POSTFIELDS, $sendDataJson);
            curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2_0);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $ar_request_head);
            $response = curl_exec($ch);
            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if (empty(curl_error($ch))) {
                // echo "empty curl error \n";
            }
            curl_close($ch);
            $notificationType = "missed_call";
            $data = [];
            if($saveType == 'save'){
                self::saveNotification($userId, $message, $notification_type, $data, $to_id);
            }
            return true;
        } catch (Exception $e) {
            echo "<pre>";
            print_r($e->getMessage());
            die;
            return false;
        }
    }

    public static function sendNotification($userIds, $message, $type, $data = array(),$userId,$toId) {
        try {
            $users = User::whereIn('id', $userIds)->with('UserDevices')->get();
            if (!empty($users)) {
                foreach ($users as $user) {
                    if ($user->userDevices && $user->userDevices->device_type == 'ios') {
                        self::APNSPushDeviceNotification($user->userDevices->device_id, $message, $type, $user->role, $data,$userId,$toId);
                    }
                    if ($user->userDevices && $user->userDevices->device_type == 'android') {
                        return self::FcmPushNotification(array($user->userDevices->device_id), $message, $type, $user->role, $data,$userId,$toId);
                    }
                }
                return true;
            } else {
                return false;
            }
        } catch (Exception $e) {
            return false;
        }
    }

    public static function saveNotification($userId, $message, $notification_type, $data = array(), $to_id = null) {
        try {
            $notification = new Notification();
            $notification->from_id = $userId;
            $notification->to_id = $to_id;
            $notification->message = $message;
            $notification->type = $notification_type;
            $notification->notification_data = json_encode($data);
            $notification->read_status = 'unread';
            $notification->status = 'active';
            if ($notification->save()) {
                return true;
            }
        } catch (Exception $e) {
            echo "<pre>";
            print_r($e->getMessage());
            return false;
        }
    }

    public static function getCategoryLogo($logo) {
        $src = url('public/admin-manager-assets/images/default-user.jpg');
        $fileName = public_path() . '/uploads/category/' . $logo;
        if (filter_var($logo, FILTER_VALIDATE_URL) != FALSE) {
            $src = $logo;
        } elseif (!empty($logo) && file_exists($fileName)) {
            $src = url('public/uploads/category/' . $logo);
        }
        return $src;
    }

    public static function generateTicket() {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomStr = substr(str_shuffle($characters), 0, 10);
        return $randomStr;
    }

}
