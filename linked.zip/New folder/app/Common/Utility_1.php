<?php

namespace App\Common;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\models\ContestListings;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Exception;
//use App\Models\User;
use App\Http\Models\Notification;
use App\Http\Models\User;

class Utility {

      
    //notification code 

    public static function FcmPushNotification($registatoinIds, $message,$user_type, $data = array(),$userId,$to_id) {

        if ($user_type == 'executive') {
            $API_ACCESS_KEY = \Config::get('constants.executive_api_access_key');
        } else {
            $API_ACCESS_KEY = \Config::get('constants.customer_api_access_key');
        }
        if (!isset($API_ACCESS_KEY)) {
            return false;
        }

        $url = 'https://fcm.googleapis.com/fcm/send';
        $fields = array(
            'registration_ids' => $registatoinIds,
            'data' => $data,
        );
        $headers = array
            (
            'Authorization: key=' . $API_ACCESS_KEY,
            'Content-Type: application/json'
        );
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        $result = curl_exec($ch);
//         print_r($headers); die;
        $data = json_decode($result);
        
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }
        if ($data->success == 1) {
            $notificationType = "missed_call";
            $data = [];
            self::saveNotification($userId, $message, $notificationType,$data,$to_id);
            curl_close($ch);
            return true;
        } else {
            curl_close($ch);
            return false;
        }
    }

    /**
     * [APNSPushDeviceNotification <Send push notifications to IOS device>]
     * @param [type] $deviceId  [description]
     * @param [type] $certType  [description]
     * @param [type] $message   [description]
     * @param [type] $type      [description]
     * @param [type] $user_type [description]
     * @param array  $data      [description]
     */
    public static function APNSPushDeviceNotification($deviceId, $message, $user_type, $data = array(),$userId,$to_id) {
        try {
//            $authKeyId = '/AuthKey_SJQTVZK57P.p8'; // your p8 file 
//            $keyId = 'SJQTVZK57P'; // Your Bundle ID
//            $teamId = 'Q84UD28472'; //Your Team ID (see Developer Portal)
            $authKeyId =  \Config::get('constants.auth_key'); // your p8 file 
            $keyId =  \Config::get('constants.key_id'); // Your Bundle ID
            $teamId =  \Config::get('constants.team_id'); //Your Team ID (see Developer Portal)
            $bundelId = ($user_type == 'executive') ? 'com.codiant.LinkedAssistSE' : 'com.codiant.LinkedAssistCustomer'; // Your Key ID

            $authKey = "$authKeyId";
//            $arParam['teamId'] = $teamId; // Get it from Apple Developer's page
//            $arParam['authKeyId'] = $keyId;
//            $arParam['apns-topic'] = $bundelId;
//            $arParam['message'] = $message;
            $arClaim = ['iss' => $teamId, 'iat' => time()];
            $arParam['p_key'] = file_get_contents(app_path() . $authKey);
            $arParam['header_jwt'] = \App\Http\Models\Jwt::encode($arClaim, $arParam['p_key'], $keyId, 'RS256');
//            $stat = self::push_to_apns($arParam, $ar_msg,$deviceId);

            $body = $message; //body message
            $arSendData = array();

            $url_cnt = "https://www.google.com";
            $arSendData['aps']['alert']['title'] = sprintf("Notification Title"); // Notification title
            $arSendData['aps']['alert']['body'] = sprintf($body); // body text
            $arSendData['data']['jump-url'] = $url_cnt; // other parameters to send to the app

            $sendDataJson = json_encode($arSendData);
            $endPoint = 'https://api.development.push.apple.com/3/device'; // https://api.push.apple.com/3/device
            //ã€€Preparing request header for APNS
            $ar_request_head[] = sprintf("content-type: application/json");
            $ar_request_head[] = sprintf("authorization: bearer %s", $arParam['header_jwt']);
            $ar_request_head[] = sprintf("apns-topic: %s", $bundelId);

            $dev_token = $deviceId;  // Device token

            $url = sprintf("%s/%s", $endPoint, $deviceId);

            $ch = curl_init($url);

            curl_setopt($ch, CURLOPT_POSTFIELDS, $sendDataJson);
            curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2_0);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $ar_request_head);
            $response = curl_exec($ch);
            $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if (empty(curl_error($ch))) {
                // echo "empty curl error \n";
            }
            curl_close($ch);
            $notificationType = "missed_call";
            $data = [];
            self::saveNotification($userId, $message, $notification_type,$data,$to_id);
            return true;
        } catch (Exception $e) {
            echo "<pre>";
            print_r($e->getMessage());
            die;
            return false;
        }
    }

    /**
     * [sendNotification < single function send and save push notifications to IOS and android device >]
     * @param  [type] $user_ids [description]
     * @param  [type] $message  [description]
     * @param  [type] $type     [description]
     * @param  array  $data     [description]
     * @return [type]           [description]
     */
    public static function push_to_apns($arParam, &$ar_msg, $deviceId) {
        //$deviceId = $arParam['device_id']; //device token 
        $body = $arParam['message']; //body message
        $arSendData = array();

        $url_cnt = "https://www.google.com";
        $arSendData['aps']['alert']['title'] = sprintf("Notification Title"); // Notification title
        $arSendData['aps']['alert']['body'] = sprintf($body); // body text
        $arSendData['data']['jump-url'] = $url_cnt; // other parameters to send to the app

        $sendDataJson = json_encode($arSendData);
        $endPoint = 'https://api.development.push.apple.com/3/device'; // https://api.push.apple.com/3/device
        //ã€€Preparing request header for APNS
        $ar_request_head[] = sprintf("content-type: application/json");
        $ar_request_head[] = sprintf("authorization: bearer %s", $arParam['header_jwt']);
        $ar_request_head[] = sprintf("apns-topic: %s", $arParam['apns-topic']);

        $dev_token = $deviceId;  // Device token

        $url = sprintf("%s/%s", $endPoint, $deviceId);

        $ch = curl_init($url);

        curl_setopt($ch, CURLOPT_POSTFIELDS, $sendDataJson);
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2_0);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $ar_request_head);
        $response = curl_exec($ch);
        $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if (empty(curl_error($ch))) {
            // echo "empty curl error \n";
        }
        curl_close($ch);
        return true;
    }

    public static function sendNotification($user_ids, $custome_message, $type, $data = array()) {

        try {
            $users = User::whereIn('id', $user_ids)->with('UserDevices')->get();
            foreach ($users as $user) {
                $message = $custome_message;
                if ($user->userDevices && $user->userDevices->device_type == 'ios') {
                    self::APNSPushDeviceNotification(
                            $user->userDevices->device_id, $message, $type, $user->role, $data
                    );
                }

                if ($user->userDevices && $user->userDevices->device_type == 'android') {
                    return self::FcmPushNotification(
                                    array($user->userDevices->device_id), $message, $type, $user->role, $data
                    );
                }
            }
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * [saveNotification <TO save notification>]
     * @param  [type] $user              [description]
     * @param  [type] $message           [description]
     * @param  [type] $notification_type [description]
     * @param  array  $data              [description]
     * @return [type]                    [description]
     */
    public static function saveNotification($userId, $message, $notification_type, $data = array(), $to_id = null) {
        try {
            $notification = new Notification();
            $notification->from_id = $userId;
            $notification->to_id = $to_id;
            $notification->message = $message;
            $notification->type = $notification_type;
            $notification->notification_data = json_encode($data);
            $notification->read_status = 'unread';
            $notification->status = 'active';
            if ($notification->save()) {
                return true;
            }
        } catch (Exception $e) {
            echo "<pre>";
            print_r($e->getMessage());
            return false;
        }
    }
   
    public static function getCategoryLogo($logo) {
        $src = url('public/admin-manager-assets/images/default-user.jpg');
        $fileName = public_path() . '/uploads/category/' . $logo;
        if (filter_var($logo, FILTER_VALIDATE_URL) != FALSE) {
            $src = $logo;
        } elseif (!empty($logo) && file_exists($fileName)) {
            $src = url('public/uploads/category/' . $logo);
        }
        return $src;
    }

    public static function generateTicket() {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomStr = substr(str_shuffle($characters), 0, 10);
        return $randomStr;
    }

}
