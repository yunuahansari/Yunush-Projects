<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Auth;

class CustomerExecutiveRelation extends Model {

    protected $table = 'customer_executive_relations';

    /*
     * relation with user table by exeutive_id
     */

    public function userDetail() {
        return $this->belongsTo('App\Http\Models\User', 'executive_id');
    }

    /*
     * relation with user table by customer_id
     */

    public function userCustomerDetail() {
        return $this->belongsTo('App\Http\Models\User', 'customer_id');
    }

    /*
     * relation with user profile table by exeutive_id
     */

    public function userProfile() {
        return $this->belongsTo('App\Http\Models\UserProfile', 'executive_id', 'user_id');
    }

    /*
     * relation with user profile table by customer_id
     */

    public function userCustomerProfile() {
        return $this->belongsTo('App\Http\Models\UserProfile', 'customer_id', 'user_id');
    }

    /*
     * get customers by executive id
     */

    public static function getCustomerByExecutiveId($executiveId) {
        return CustomerExecutiveRelation::join('users', 'users.id', 'customer_executive_relations.customer_id')
                        ->where('users.status', '!=', 'deleted')
                        ->where('users.role', '=', 'customer')
                        ->where('executive_id', $executiveId)->get();
    }

    /*
     * get executives by executive id
     */

    public static function getExecutiveByCustomerId($customerId) {
        return CustomerExecutiveRelation::where('customer_id', $customerId)->get();
    }

    /*
     * get executives by manager id
     */

    public static function getExecutiveByCustomerManagerId($customerId) {
        return CustomerExecutiveRelation::where('manager_id', Auth::guard('manager')->user()->id)
                        ->where('customer_id', $customerId)->get();
    }

    /*
     * get merchants by manager id from customer_Exectives_relations
     * not in use at the time
     */
//    public static function getAllMerchantByManager($id) {
//        return CustomerExecutiveRelation::select('customer_executive_relations.customer_id')->where('manager_id', $id)->groupBy('customer_executive_relations.customer_id')->get(['customer_id']);
////        return CustomerExecutiveRelation::where('manager_id', $id)->distinct()->get(['customer_id'])->count();  /* commented query will give only count, may be use in future*/
//    }
}
