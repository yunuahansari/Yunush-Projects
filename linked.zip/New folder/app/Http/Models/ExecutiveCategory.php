<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;

class ExecutiveCategory extends Model {
    /*
     * relation with bank category table by category_id
     */

    public function bankCategory() {
        return $this->belongsTo('App\Http\Models\BankingCategory', 'category_id');
    }

    public static function getCategoriesById($id) {
        return ExecutiveCategory::where('executive_id', $id)->get();
    }

    public static function getAllExecutiveCategories() {
        return ExecutiveCategory::get();
    }

    public static function getExecutiveCategoryName($category_id) {
        $category = BankingCategory::where(['id' => $category_id])->first();
        return ($category) ? $category['name'] : '';
    }

    public static function getCategoryExecutive($get) {
        $executives = ExecutiveCategory::where(['category_id' => $get['category_id']])->get();
        if (count($executives) > 0) {
            foreach ($executives as $val) {
                $executive = User::getUserById($val->executive_id);
                $val->first_name = $executive['first_name'];
                $val->last_name = $executive['last_name'];
                $val->contact_name = $executive['contact_name'];
            }
            return $executives;
        }return false;
    }

    //Rahul : get category by executive
    public static function getCategoriesByExecutiveId($id) {
        return ExecutiveCategory::select('banking_categories.name')
                        ->join('banking_categories', 'executive_categories.category_id', 'banking_categories.id')
                        ->where('executive_categories.executive_id', $id)->get();
    }

}
