<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use JWTAuth;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Collection;

class Rating extends Model {

    //Rahul : get executive by executive id
    public function executiveDetail() {
        return $this->belongsTo('App\Http\Models\User', 'executive_id');
    }

    public static function rateToExecutive($post) {

        $rating = new Rating();
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        if (!empty($user)) {
            $rating->request_id = $post['request_id'];
            $rating->customer_id = $user->id;
            $rating->executive_id = $post['executive_id'];
            $rating->behaviour_rating = $post['executive_rating'];
            $rating->waiting_time_rating = $post['waiting_rating'];
            $rating->overall_rating = $post['overall_rating'];
            $rating->review = $post['review'];
            if ($rating->save()) {
                return true;
            }
        }
        return false;
    }

    //Rahul : get top five ratings on dashboard by executives
    public static function getTopFiveRatings($userType) {
        $getRatings = Rating::select(DB::raw("ratings.executive_id, (SUM(behaviour_rating) + SUM(waiting_time_rating) + SUM(overall_rating))/3/COUNT(*) as avgRating"))
                ->join('call_requests', 'call_requests.id', 'ratings.request_id')
                ->join('executive_manager_relations', 'ratings.executive_id', 'executive_manager_relations.executive_id')
                ->join('users', 'users.id', 'ratings.executive_id')
                ->where('users.status', '!=', 'deleted')
                ->groupBy('ratings.executive_id')
                ->orderBy('avgRating', 'desc');
        if ($userType == "manager") {
            $getRatings->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
        }
        return $getRatings->take(5)->get();
    }

    //Rahul : get top five ratings on dashboard by executives
    public static function getAllRatings($post, $userType) {
        $getRatings = Rating::select(DB::raw("ratings.executive_id, (SUM(behaviour_rating) + SUM(waiting_time_rating) + SUM(overall_rating))/3/COUNT(*) as avgRating"))
                ->join('call_requests', 'call_requests.id', 'ratings.request_id')
                ->join('executive_manager_relations', 'ratings.executive_id', 'executive_manager_relations.executive_id')
                ->join('users', 'users.id', 'ratings.executive_id')
                ->where('users.status', '!=', 'deleted')
                ->groupBy('ratings.executive_id')
                ->orderBy('avgRating', 'desc');
        if ($userType == "manager") {
            $getRatings->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
        }
        if (isset($post['name']) && !empty($post['name'])) {
            $getRatings->where('users.contact_name', 'like', '%' . $post['name'] . '%');
        }
        if (isset($post['email']) && !empty($post['email'])) {
            $getRatings->where('users.email', 'like', '%' . $post['email'] . '%');
        }
        $getData = $getRatings->get();
        if (isset($post['rating']) && !empty($post['rating'])) {
            $getData = collect($getData);
            $getData = $getData->where('avgRating', '>', $post['rating']);
            $getData = $getData->where('avgRating', '<=', $post['rating'] + 1);
            $getData = $getData->all();
        }
        return $getData;
    }

}
