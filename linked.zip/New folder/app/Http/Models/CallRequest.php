<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use App\Http\Models\User;
use App\Http\Models\ExecutiveCategory;
use JWTAuth;
use App\Common\Utility;
use App\Http\Models\Notification;
use Illuminate\Support\Facades\Auth;

class CallRequest extends Model {
    /*
     * relation with user table by customer_id
     */

    public function customerDetail() {
        return $this->belongsTo('App\Http\Models\User', 'customer_id');
    }

    /*
     * relation with user table by executive_id
     */

    public function executiveDetail() {
        return $this->belongsTo('App\Http\Models\User', 'executive_id');
    }

    /*
     * relation with category table by category_id
     */

    public function BankCategory() {
        return $this->belongsTo('App\Http\Models\BankingCategory', 'category_id');
    }

    /*
     * relation with user profile table by customer_id
     */

    public function UserProfile() {
        return $this->belongsTo('App\Http\Models\UserProfile', 'customer_id', 'user_id');
    }

    /*
     * relation with rating table by customer_id
     */

    public function customerRating() {
        return $this->belongsTo('App\Http\Models\Rating', 'customer_id', 'customer_id');
    }

    /*
     * get resolved call request by executive id
     */

    public static function getResolveCallRequestByExecutive($executive_id, $callFrom) {
        $lists = CallRequest::where('executive_id', '=', $executive_id)->where('status', '=', 'resolved');
        if ($callFrom == 'count') {
            return $lists->get()->count();
        } else {
            return $lists->paginate(10);
        }
    }

    /*
     * get pending call request by executive id
     */

    public static function getPendingCallRequestByExecutive($executive_id, $callFrom) {
        $lists = CallRequest::where('executive_id', '=', $executive_id)->where('status', '!=', 'resolved');
        if ($callFrom == 'count') {
            return $lists->get()->count();
        } else {
            return $lists->paginate(10);
        }
    }

    /*
     * Function for get count of all merchant request rised by manager id.
     */

    public static function getAllRequestByManager($id) {
        return CallRequest::where('executive_id', '=', $id)->where('status', '=', 'resolved')->count();
    }

//api side for linked history
    public static function getLinkerHistory() {
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        if (!empty($user)) {
            if ($user->role == 'customer') {
                $lists = CallRequest::where('customer_id', $user->id)
                                ->where(function ($lists) {
                                    $lists->where('status', 'pending')
                                    ->orWhere('status', 'resolved');
                                })->orderBy('id', 'desc')->paginate(10);
            } else {
                $lists = CallRequest::where('executive_id', $user->id)
                                ->where(function ($lists) {
                                    $lists->where('status', 'pending')
                                    ->orWhere('status', 'resolved');
                                })->orderBy('id', 'desc')->paginate(10);
            }
            if (!empty($lists) && count($lists) > 0) {
                foreach ($lists as $list) {
                    $executive = User::where(['id' => $list->executive_id])->first();
                    $customer = User::where(['id' => $list->customer_id])->first();
                    if ($user->role == 'customer') {
                        $list->executive_name = $executive['contact_name'];
                        $list->executive_profile = checkProfileImage($executive['profile_image']);
                        $list->executive_bank = Bank::getbankNameById($executive['bank_id']);
                        $list->bank_category = ExecutiveCategory::getExecutiveCategoryName($list['category_id']);
                    } else {
                        $list->customer_name = $customer['contact_name'];
                        $list->customer_profile = checkProfileImage($customer['profile_image']);
                        $list->customer_bank = Bank::getbankNameById($customer['bank_id']);
                        $list->bank_category = ExecutiveCategory::getExecutiveCategoryName($list['category_id']);
                    }
                }
                return $lists;
            }return false;
        }
    }

// history detail
    public static function getHistoryDetail($get) {

        $call_history = CallRequest::where(['id' => $get['request_id']])->first();
        if (!empty($call_history)) {
            $executive = User::where(['id' => $call_history->executive_id])->first();
            $customer = User::where(['id' => $call_history->customer_id])->first();
            $call_history->executive_name = $executive['contact_name'];
            $call_history->customer_name = $customer['contact_name'];
            $call_history->customer_profile = checkProfileImage($customer['profile_image']);
            $call_history->customer_bank = Bank::getbankNameById($customer['bank_id']);
            $call_history->bank_category = ExecutiveCategory::getExecutiveCategoryName($call_history['category_id']);
            return $call_history;
        }return false;
    }

    /*
     * get all merchant call request history
     */

    public static function getAllMerchantRequestHistory($post, $callFrom) {
        $merchantRequest = CallRequest::select('call_requests.*')
                ->join('executive_manager_relations', 'call_requests.executive_id', 'executive_manager_relations.executive_id')
                ->join('users', 'users.id', 'call_requests.customer_id')
                ->join('user_profiles', 'user_profiles.user_id', 'call_requests.customer_id')
                ->where('users.status', '!=', 'deleted')
                ->where('users.role', '=', 'customer')
                ->where('call_requests.status', '!=', 'missed_request');
        if ($callFrom == 'manager') {
            $merchantRequest->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
        }
        if ($callFrom == 'request_count_manager') {
            return $merchantRequest->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id)->count();
        }
        if (isset($post['request_date']) && !empty($post['request_date'])) {
            $merchantRequest->whereDate('call_requests.created_at', getDBdateFormat($post['request_date']));
        }
        if (isset($post['category_id']) && !empty($post['category_id'])) {
            $merchantRequest->where('call_requests.category_id', $post['category_id']);
        }
        if (isset($post['executive_id']) && !empty($post['executive_id'])) {
            $merchantRequest->where('call_requests.executive_id', $post['executive_id']);
        }
        if (isset($post['bussiness_name']) && !empty($post['bussiness_name'])) {
            $merchantRequest->where('user_profiles.bussiness_name', 'like', '%' . $post['bussiness_name'] . '%');
        }
        if (isset($post['phone']) && !empty($post['phone'])) {
            $merchantRequest->where('users.phone_number', 'like', '%' . $post['phone'] . '%');
        }

        return $merchantRequest->get();
    }

    /*
     * get merchant call request history by id
     */

    public static function getCallRequestsById($id) {
        return CallRequest::where('id', $id)->first();
    }

    /*
     * update call request
     */

    public static function updateCallRequests($post) {
        try {
            $requestModel = CallRequest::where('id', $post['request_id'])->first();
            $requestModel->status = $post['status'];
            $requestModel->category_id = $post['category_id'];
            $requestModel->notes = $post['notes'];
            $requestModel->save();
            return Response::json(['success' => true, 'message' => \Config::get('constants.request_updated')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public static function getCallRequestList($post, $userType) {
        $callRequest = CallRequest::select('call_requests.*')
                ->join('executive_manager_relations', 'call_requests.executive_id', 'executive_manager_relations.executive_id')
                ->join('users', 'users.id', 'call_requests.customer_id')
                ->join('user_profiles', 'user_profiles.user_id', 'call_requests.customer_id')
                ->where('call_requests.status', '!=', 'missed_request');
        if ($userType == 'manager') {
            $callRequest->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
        }
        if (isset($post['merchant_number']) && !empty($post['merchant_number'])) {
            $callRequest->where('user_profiles.merchant_number', 'like', '%' . $post['merchant_number'] . '%');
        }
        if (isset($post['se_assigned']) && !empty($post['se_assigned'])) {
            $callRequest->where('call_requests.executive_id', $post['se_assigned']);
        }
        if (isset($post['business_name']) && !empty($post['business_name'])) {
            $callRequest->where('user_profiles.bussiness_name', 'like', '%' . $post['business_name'] . '%');
        }
        if (isset($post['date_of_call']) && !empty($post['date_of_call'])) {
            $callRequest->whereDate('call_requests.created_at', getDBdateFormat($post['date_of_call']));
        }
        return $callRequest->get();
    }

    public static function getMerchantRequestList($post, $userType) {
        $merchantRequest = CallRequest::select('call_requests.*')
                ->join('executive_manager_relations', 'call_requests.executive_id', 'executive_manager_relations.executive_id')
                ->join('users', 'users.id', 'call_requests.customer_id')
                ->join('user_profiles', 'user_profiles.user_id', 'call_requests.customer_id')
                ->where('call_requests.customer_id', '=', $post['user_id'])
                ->where('call_requests.status', '!=', 'missed_request');
        if ($userType == 'manager') {
            $merchantRequest->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
        }
        if (isset($post['name']) && !empty($post['name'])) {
            $merchantRequest->where('users.contact_name', 'like', '%' . $post['name'] . '%');
        }
        if (isset($post['generate_date']) && !empty($post['generate_date'])) {
            $merchantRequest->whereDate('call_requests.created_at', getDBdateFormat($post['generate_date']));
        }
        if (isset($post['category_id']) && !empty($post['category_id'])) {
            $merchantRequest->where('call_requests.category_id', $post['category_id']);
        }
        if (isset($post['executive_id']) && !empty($post['executive_id'])) {
            $merchantRequest->where('call_requests.executive_id', $post['executive_id']);
        }

        return $merchantRequest->orderBy('call_requests.id', 'desc')->get();
    }

    /*
     * get executives linked merchant notes history by executive and merchant id
     */

    public static function getMerchantLinkedNotesHistoryByExecutive($executiveId, $merchantId) {
        return CallRequest::where(['executive_id' => $executiveId, 'customer_id' => $merchantId])->paginate(10);
    }

    /* update call request by executve
     */

    public static function updateCallRequestsExecutive($post) {
        try {
            $requestModel = CallRequest::where('id', $post['request_id'])->first();
            $requestModel->status = $post['status'];
            if ($post['status'] == "pending") {
                $requestModel->notify_type = $post['notify_type'];
                if ($post['notify_type'] == "selected_date") {
                    $requestModel->notify_date = getDBdateFormat($post['notify_date']);
                    $requestModel->notify_date_time = date('H:i:s', strtotime($post['notify_date_time']));
                    $requestModel->today_in_time = "";
                } elseif ($post['notify_type'] == "today") {
                    $splitStr = explode("_", $post['today_in_time']);
                    if ($splitStr['1'] == 'hour') {
                        $todayInTime = gmdate('H:i:s', strtok($post['today_in_time'], '_') * 60 * 60);
                    } else {
                        $todayInTime = gmdate('H:i:s', strtok($post['today_in_time'], '_') * 60);
                    }
                    $requestModel->today_in_time = $todayInTime;
                    $requestModel->notify_date = null;
                    $requestModel->notify_date_time = "";
                } else {
                    $requestModel->today_in_time = "";
                    $requestModel->notify_date = null;
                    $requestModel->notify_date_time = "";
                }
            } else {
                $requestModel->notify_type = "";
                $requestModel->today_in_time = "";
                $requestModel->notify_date = null;
                $requestModel->notify_date_time = "";
            }
            $requestModel->category_id = $post['category_id'];
            $requestModel->executive_id = $post['executive_id'];
            $requestModel->notes = $post['notes'];
            $requestModel->save();
            return Response::json(['success' => true, 'message' => \Config::get('constants.request_updated')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public static function saveFinishCallDetail($post) {
        $ticketData = Ticket::where(['ticket_number'=>$post['ticket_id']])->first();
        $request = CallRequest::where(['ticket_id' => $ticketData->id])->orderBy('id','desc')->first();
        if (!empty($request)) {
            $request->status = $post['request_status'];
//            $request->executive_id = $post['executive_id'];
//            $request->category_id = $post['category_id'];
            $request->notes = $post['notes'];
            if ($post['notify_type'] == 'selected_date') {
                $request->notify_date = $post['notify_date'];
                $request->notify_date_time = $post['notify_date_time'];
            }
            if ($post['notify_type'] == 'today') {
                $request->today_in_time = $post['today_in_time'];
            }
            if ($request->save()) {
                return true;
            }
        }
        return false;
    }

// api for home screen in executive side
    public static function getMissedRequest() {
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        if (!empty($user)) {
            $lists = CallRequest::select('id', 'customer_id', 'ticket_id', 'executive_id', 'notes', 'created_at', 'status')->where(['status' => 'missed_request', 'executive_id' => $user->id])->orderBy('id', 'desc')->paginate(10);
            if (count($lists) > 0) {
                foreach ($lists as $val) {
                    $customer = User::where(['id' => $val->customer_id])->first();
                    $val->customer_name = $customer['contact_name'];
                    $val->customer_profile = checkProfileImage($customer['profile_image']);
                    $val->customer_bank = Bank::getbankNameById($customer['bank_id']);
                    $val->online_status = User::getUserDataByKey($val->customer_id, 'online_status');
                    $val->last_login_time = User::getUserDataByKey($val->customer_id, 'last_login_time');
                    $val->ticket_number = getTicketById($val->ticket_id);
                }
                return $lists;
            }return false;
        }return false;
    }

    // send request to executive in api side
    public static function sendRequestNotification($post) {

        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);

        $ticket = Ticket::where(['customer_id' => $user->id, 'category_id' => $post['category_id'], 'status' => 'pending'])->where('executive_id', 'IS NOT', NULL)->first();
        if (empty($ticket)) {
            $executive = User::select('users.*')
                            ->join('executive_categories', 'executive_categories.executive_id', 'users.id')
                            ->where(['executive_categories.category_id' => $post['category_id'], 'online_status' => 'online'])->get();
            if (!empty($executive)) {
                // save ticket
                $ticketNumber = Utility::generateTicket();
                $ticket = new Ticket();
                $ticket->ticket_number = $ticketNumber;
                $ticket->customer_id = $user->id;
                $ticket->category_id = $post['category_id'];
                $ticket->save();
                // save request 
                $newArr = [];
                foreach ($executive as $val) {
                    $newArr[] = $val->id;
                    $requestModel = new CallRequest();
                    $requestModel->ticket_id = $ticket->id;
                    $requestModel->customer_id = $user->id;
                    $requestModel->category_id = $post['category_id'];
                    $requestModel->executive_id = $val->id;
                    $requestModel->status = 'missed_request';
                    $requestModel->save();
                }
                return response()->json(['success' => TRUE, 'data' => $newArr, 'ticketId' => $ticketNumber]);
                //$callRequest = self::saveCallRequuest($post, $ticket);
            } else {
                return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'No executive online']]);
            }
        } else {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'You already have SE for this category']]);
            //   $callRequest = self::saveCallRequuest($post, $ticket);
        }
//        if (!empty($callRequest)) {
//            $userIds[] = $callRequest->executive_id;
//            $message = 'You have a missed call from ' . $user->contact_name;
//            $type = 'customer_call_request';
//            $fromId = $user->id;
//            $toId = $callRequest->executive_id;
//            $data = [];
//            $data['type'] = $type;
//            $data['message'] = $message;
//            $customer_image = checkProfileImage($user->profile_image);
//            $data['profile_image'] = $customer_image;
//            $data['business_name'] = Bank::getbankNameById($user->bank_id);
//            $data['first_name'] = $user['first_name'];
//            $data['last_name'] = $user['last_name'];
//            $data['contact_name'] = $user->contact_name;
//            $data['request_status'] = 'pending';
//            $data['ticket_id'] = $ticket->ticket_number;
//            $data['request_id'] = $callRequest->id;
//            $data['customer_id'] = $callRequest->customer_id;
//            //Utility::saveNotification($from_id, $message, $type, $data, $to_id);
//            Utility::sendNotification($userIds, $message, $type, $data,$fromId,$toId);
//            return response()->json(['success' => true, 'data' => [], 'message' => 'Notification sent']);
//        }
        return response()->json(['success' => false]);
    }

    public static function saveCallRequuest($post, $ticket) {
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        $callRequest = CallRequest::where(['customer_id' => $user->id, 'executive_id' => $ticket->executive_id, 'status' => 'pending', 'status' => 'missed_request', 'category_id' => $post['category_id']])->first();
        if (empty($callRequest)) {
            $callRequest = new CallRequest();
            $callRequest->ticket_id = $ticket->id;
            $callRequest->customer_id = $user->id;
            $callRequest->executive_id = $ticket->executive_id;
            $callRequest->category_id = $post['category_id'];
            $callRequest->status = 'missed_request';
            $callRequest->notes = $post['notes'];
            $callRequest->save();
        }
        return $callRequest;
    }

    public static function saveCallRequuestFromWeb($post) {
        $userId = Auth::guard()->user()->id;
        $ticketData = Ticket::where(['ticket_number' => $post['ticketId'], 'status' => 'resolved'])->first();
        if (empty($ticketData)) {
            $ticketData = Ticket::where(['ticket_number' => $post['ticketId']])->orderBy('id', 'desc')->first();
            if ($post['requestType'] == 'pending') {
                $callRequest = CallRequest::where(['id' => $post['$requestId']])->first();
                $userDeviceData = UserDevice::where(['user_id' => $post['customerId']])->first();
                if (!empty($userDeviceData)) {
                    $executiveName = User::getUserDataByKey($userId, 'contact_name');
                    $message = "You have a missed call from $executiveName";
                    $userType = 'customer';
                    $data = ['notification_type' => 'MISSED_CALL'];
                    Utility::sendNotification([$userDeviceData->device_id], $message, $userType, $data, $userId, $post['customerId']);
                }
            } else {
                $callRequest = new CallRequest();
            }
            $callRequest->ticket_id = $ticketData->id;
            $callRequest->customer_id = $post['customerId'];
            $callRequest->executive_id = $userId;
            $callRequest->category_id = $ticketData->category_id;
            $callRequest->status = 'missed_request';
            $callRequest->save();
            return $callRequest->id;
        } else {
            return false;
        }
    }

// linking with customer by execurive in api side

    public static function linkWithCustomer1($post) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            if (!empty($user)) {
                $userIds[] = ($user->role == 'executive') ? $post['customer_id'] : $post['executive_id'];
                $message = 'You have a missed call from ' . $user->contact_name;
                $type = ($user->role == 'executive') ? 'executive_call_link' : 'customer_call_link';
                $from_id = $user->id;
                $to_id = ($user->role == 'executive') ? $post['customer_id'] : $post['executive_id'];
                $data = [];
                $data['type'] = $type;
                $data['message'] = $message;
                $executive_image = checkProfileImage($user->profile_image);
                $data['profile_image'] = $executive_image;
                $data['business_name'] = Bank::getbankNameById($user->bank_id);
                $data['first_name'] = $user['first_name'];
                $data['last_name'] = $user['last_name'];
                $data['contact_name'] = $user->contact_name;
                $data['request_status'] = 'pending';
                $data['ticket_id'] = $post['ticket_id'];
                $data['request_id'] = '';
                Utility::saveNotification($from_id, $message, $type, $data, $to_id);
                if (Utility::sendNotification($userIds, $message, $type, $data)) {
                    return response()->json(['success' => true, 'data' => [], 'message' => 'link notification sent']);
                }return response()->json(['success' => false, 'data' => [], 'message' => 'not sent']);
            }
        } catch (\Exception $ex) {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => $ex->getMessage()]]);
        }
    }

    //Praveen 
    public static function linkWithCustomer($post) {
        try {
            $token = \Request::header('access-token');
            $user = JWTAuth::toUser($token);
            if (!empty($user)) {

                $ticketData = Ticket::where(['ticket_number' => $post['ticket_id']])->first();
                $model = new CallRequest();
                $model->ticket_id = $post['ticket_id'];
                if (isset($post['customer_id'])) {
                    $postUserId = $post['customer_id'];
                    $model->customer_id = $post['customer_id'];
                    $model->executive_id = $user->id;
                } else {
                    $postUserId = $post['executive_id'];
                    $model->executive_id = $post['executive_id'];
                    ;
                    $model->customer_id = $user->id;
                }

                $model->category_id = $ticketData->category_id;
                $model->status = 'pending';
                $model->save();
                $arr = [];

                $arr['name'] = User::getUserDataByKey($postUserId, 'contact_name');
                $image = User::getUserDataByKey($postUserId, 'profile_image');
                $arr['image'] = getImage($image, 'users', 'users');
                return response()->json(['success' => true, 'data' => $arr, 'error' => ['message' => ""]]);
            }
        } catch (\Exception $ex) {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => $ex->getMessage()]]);
        }
    }

    //Rahul : get all call request count by admin
    public static function allCallRequestCount($userType) {
        $merchantRequest = CallRequest::join('executive_manager_relations', 'call_requests.executive_id', 'executive_manager_relations.executive_id')
                ->join('users', 'users.id', 'call_requests.customer_id')
                ->join('user_profiles', 'user_profiles.user_id', 'call_requests.customer_id')
                ->where('call_requests.status', '!=', 'missed_request');
        if ($userType == 'manager') {
            $merchantRequest->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
        }
        return $merchantRequest->count();
    }

    //Rahul : get manager id by executive
    public static function getManagerIdByExecutive($executive_id) {
        return CallRequest::join('executive_manager_relations', 'executive_manager_relations.executive_id', 'call_requests.executive_id')
                        ->where('call_requests.status', '!=', 'missed_request')
                        ->where('call_requests.executive_id', $executive_id)->first();
    }

    //Rahul : get request history in executive section
    public static function getLinkedHistoryRequest($id) {
        return CallRequest::select('call_requests.*')
                        ->join('users', 'users.id', 'call_requests.customer_id')
                        ->where('call_requests.status', '!=', 'missed_request')
                        ->where('call_requests.executive_id', '=', $id)
                        ->where('users.role', '=', 'customer')
                        ->where('users.status', '!=', 'deleted')
                        ->orderBy('call_requests.executive_id', 'desc')
                        ->get();
    }

    public static function updateCallStatus($post) {
        $tocketData = Ticket::where(['ticket_number' => $post['ticketId']])->first();
        $model = CallRequest::where(['ticket_id' => $tocketData->id])->first();
        $model->status = 'pending';
        $model->save();
        return true;
    }

    public static function requestChartList($post, $userType) {
        $userPendingMonth = array();
        $userResolvedMonth = array();
        $months = array();

        if (isset($post['from_date']) && isset($post['to_date'])) {
            $j = date('m', strtotime($post['from_date']));
            $k = date('m', strtotime($post['to_date']));
        } else {
            $j = 1;
            $k = 12;
        }
        $z = 0;
        for ($i = $j; $i <= $k; $i++) {

            $dateObj = \DateTime::createFromFormat('!m', $i);
            $monthName = $dateObj->format('M');
            $months[$z] = $monthName;
            $z++;
            $month = 12 - $i;
            $q1 = CallRequest::join('executive_manager_relations', 'call_requests.executive_id', 'executive_manager_relations.executive_id')
                    ->join('users', 'users.id', 'call_requests.customer_id')
                    ->join('user_profiles', 'user_profiles.user_id', 'call_requests.customer_id')
                    ->where('call_requests.status', '!=', 'missed_request');
            if ($userType == "manager") {
                $q1->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
            }
            if (isset($post['executive_id']) && !empty($post['executive_id'])) {
                $q1 = $q1->where('executive_manager_relations.executive_id', $post['executive_id']);
            }
            $q1 = $q1->whereMonth('call_requests.created_at', '=', date('m') - $month)
                            ->where('call_requests.status', 'pending')->get();
            $userPendingMonth[$i] = count($q1);

            $q2 = CallRequest::join('executive_manager_relations', 'call_requests.executive_id', 'executive_manager_relations.executive_id')
                    ->join('users', 'users.id', 'call_requests.customer_id')
                    ->join('user_profiles', 'user_profiles.user_id', 'call_requests.customer_id')
                    ->where('call_requests.status', '!=', 'missed_request');
            if ($userType == "manager") {
                $q2->where('executive_manager_relations.manager_id', \Auth::guard('manager')->user()->id);
            }
            if (isset($post['executive_id']) && !empty($post['executive_id'])) {
                $q2 = $q2->where('executive_manager_relations.executive_id', $post['executive_id']);
            }
            $q2 = $q2->whereMonth('call_requests.created_at', '=', date('m') - $month)
                            ->where('call_requests.status', 'resolved')->get();
            $userResolvedMonth[$i] = count($q2);
        }

        $result['resolved'] = $userResolvedMonth;
        $result['pending'] = $userPendingMonth;
        $result['months'] = $months;
        return $result;
    }

}
