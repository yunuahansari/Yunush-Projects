<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use JWTAuth;
use Illuminate\Support\Facades\Auth;

class Notification extends Model {

    public static function getNotificationList() {
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        if ($user) {
            $notificatios = Notification::where(['to_id' => $user->id, 'status' => 'active'])->paginate(10);
            if (!empty($notificatios)) {
                foreach ($notificatios as $notificatio) {
                    $notificatio->notification_data = json_decode($notificatio->notification_data);
                    $start_time = $notificatio->created_at;
                    $current_time = date('Y-m-d h:i:s');
                    //Convert them to timestamps.
                    $start_time = strtotime($start_time);
                    $current_time = strtotime($current_time);
                    //Calculate the difference.
                    $difference = $current_time - $start_time;
                    // time in mint
                    $difference = date('H:i', $difference);
                    $time_array = explode(':', $difference);
                    $hours = $time_array[0];
                    $mint = $time_array[1];
                    if ($hours == 0 && $mint <= \Config::get('constants.active_time')) {
                        $notificatio['notification_data']->call_return = TRUE;
                    } else {
                        $notificatio['notification_data']->call_return = FALSE;
                    }
                }
            }
            return $notificatios;
        }
    }

    public static function getCustomerNotificationList() {
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        if ($user) {
            $notificatios = Notification::select('notification_data')->where(['to_id' => $user->id, 'status' => 'active'])->paginate(10);
            if (!empty($notificatios)) {
                foreach ($notificatios as $notificatio) {
                    $notificatio->notification_data = json_decode($notificatio->notification_data);
                    $notificatio->business_name = $notificatio->notification_data->business_name;
                    $notificatio->request_status = $notificatio->notification_data->request_status;
                    $notificatio->profile_image = $notificatio->notification_data->profile_image;
                    $notificatio->type = $notificatio->notification_data->type;
                    $notificatio->message = $notificatio->notification_data->message;
                    $notificatio->notification_data = "";
                }
            }
            return $notificatios;
        }
    }

    //Rahul : get notification by admin
    public static function getNotificationByAdmin($toId) {
        $notification = Notification::where('to_id', $toId)->orderBy('created_at', 'desc')->paginate(10);
        return $notification;
    }

    //Rahul : get notification by admin on bell icon
    public static function loadNotificationByAdmin($toId) {
        $notification = Notification::where('to_id', $toId)->take(3)->orderBy('created_at', 'desc')->get();
        return $notification;
    }

}
