<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;

class BankingCategory extends Model {

    //Rahul : get all categories by admin
    public static function getCategoryList($request) {
        $category = BankingCategory::Select('banking_categories.*');
        if (isset($request['name']) && !empty($request['name'])) {
            $category->where('name', 'like', '%' . $request['name'] . '%');
        }
        $result = $category->orderBy('id', 'desc')->get();
        return $result;
    }

    //Rahul : update categories by admin
    public static function updateCategory($request) {
        try {
            $id = $request->categoryId;
            $model = BankingCategory::where('id', $id)->first();
            $model->name = $request['name'];
            $model->description = $request['description'];
            $model->save();
            return Response::json(['success' => true, 'message' => \Config::get('constants.category_update')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * get all active categories 
     */

    public static function getActiveCategories() {
        return BankingCategory::get();
    }

    /*
     * get category by id 
     */

    public static function getCategoryById($id) {
        return BankingCategory::where('id', $id)->first();
    }

// api side

    public static function getCategoryApiList() {
        $lists = BankingCategory::get();
        if (count($lists) > 0) {
            foreach ($lists as $list) {
                $list->category_logo = \App\Common\Utility::getCategoryLogo($list->category_logo);
            }
            return $lists;
        }
        return false;
    }

    // Rahul :  get all active executives by category id

    public static function getAllActiveExecutiveByCategory($post) {
        return BankingCategory::select('users.*')
                        ->join('executive_categories', 'executive_categories.category_id', 'banking_categories.id')
                        ->join('users', 'executive_categories.executive_id', 'users.id')
                        ->where(['users.role' => 'executive', 'executive_categories.category_id' => $post['category_id'], 'users.status' => 'active'])
                        ->get();
    }

}
