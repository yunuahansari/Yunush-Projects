<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use JWTAuth;

class Document extends Model {
    /*
     * relation with document table by created_by
     */

    public function user() {
        return $this->belongsTo('App\Http\Models\User', 'created_by');
    }

    /*
     * relation with bank table by bank_id
     */

    public function bank() {
        return $this->belongsTo('App\Http\Models\Bank', 'bank_id');
    }

    public static function getDocumentList($request) {
        $document = Document::Select('documents.*');
        if (isset($request['manager_id']) && !empty($request['manager_id'])) {
            $document->where('manager_id', '=', $request['manager_id']);
        }
        if (isset($request['title']) && !empty($request['title'])) {
            $document->where('title', 'like', '%' . $request['title'] . '%');
        }
        $result = $document->orderBy('id', 'desc')->get();
        return $result;
    }

    public static function saveDocuments($request) {
        try {
            $model = new Document();
            $model->document_type = $request['document_type'];
            if ($request['document_type'] == "doc") {
                if ($request->hasFile('pdf_upload')) {
                    $pdfPath = public_path() . '/uploads/documents/';
                    if (!is_dir($pdfPath)) {
                        File::makeDirectory($pdfPath, $mode = 0777, true, true);
                    }
                    $photo = $request->file('pdf_upload');
                    $pdfUpload = time() . '.' . $photo->getClientOriginalExtension();
                    $request->pdf_upload->move($pdfPath, $pdfUpload);
                    $model->pdf_upload = $pdfUpload;
                    $model->content = "";
                }
            } else {
                $model->pdf_upload = "";
                $model->content = $request['content'];
            }
            $model->manager_id = $request['manager_id'];
            $model->category_id = $request['category_id'];
            $model->title = $request['title'];
            $model->created_by = Auth()->guard(getAuthGuard())->user()->id;
            $model->save();
            return Response::json(['success' => true, 'message' => \Config::get('constants.document_add')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * update document
     */

    public static function updateDocuments($request) {
        try {
            $id = $request->documentId;
            $model = Document::where('id', $id)->first();
            $model->document_type = $request['document_type'];
            if ($request['document_type'] == "doc") {
                if ($request->hasFile('pdf_upload')) {
                    $pdfPath = public_path() . '/uploads/documents/';
                    if (!is_dir($pdfPath)) {
                        File::makeDirectory($pdfPath, $mode = 0777, true, true);
                    }
                    $photo = $request->file('pdf_upload');
                    $pdfUpload = time() . '.' . $photo->getClientOriginalExtension();
                    $request->pdf_upload->move($pdfPath, $pdfUpload);
                    $model->pdf_upload = $pdfUpload;
                    $model->content = "";
                }
            } else {
                $model->pdf_upload = "";
                $model->content = $request['content'];
            }
            $model->manager_id = $request['manager_id'];
            $model->category_id = $request['category_id'];
            $model->title = $request['title'];
            $model->save();
            return Response::json(['success' => true, 'message' => \Config::get('constants.document_update')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public static function deleteDocument($id) {
        try {
            Document::where('id', $id)->delete();
            return Response::json(['success' => true, 'message' => \Config::get('constants.document_deleted')]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * get all document's created by id
     */

    public static function getDocumentsCreatedById($request) {
        $userId = Auth::guard(getAuthGuard())->user()->id;
        $document = Document::Select('documents.*');
//        if (isset($request['bank_id']) && !empty($request['bank_id'])) {
//            $document->where('bank_id', $request['bank_id']);
//        }
        if (isset($request['title']) && !empty($request['title'])) {
            $document->where('title', 'like', '%' . $request['title'] . '%');
        }
        $result = $document->where('manager_id', $userId)->orderBy('id', 'desc')->paginate(10);
        return $result;
    }
// yunush : document list api side
    public static function getDocList($request) {
        
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        if(!empty($user)){
        $manager = User::select('executive_manager_relations.*')
                            ->join('executive_manager_relations', 'executive_manager_relations.executive_id', 'users.id')
                            ->where(['executive_manager_relations.executive_id' =>$user->id])->first();
        }
        $documents = Document::where(['manager_id' => $manager['manager_id']]);
        if (!empty($request['document_name'])) {
            $name = $request['document_name'];
            $documents->whereRaw("title LIKE '%$name%'");
        }
        return $documents->orderBy('id', 'desc')->paginate(10);
    }

    public static function getManagerByDocumentAdmin($id) {
        $data = Document::where('id', $id)->first();
        return $data['manager_id'];
    }

}
