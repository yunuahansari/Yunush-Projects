<?php

namespace App\Http\Middleware;

use Illuminate\Support\Facades\Auth;
use Closure;

class ExecutiveCheck {

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = 'web') {
        if (!Auth::guard($guard)->check()) {
            return redirect('/');
        }
        $userId = Auth::guard()->user($guard)->id;
        $userData = \App\Http\Models\User::where(['id' => $userId,'status' => 'active'])->first();
        if(!empty($userData)){
            return $next($request);
        } else {
            return redirect('/');
        }
    }

}
