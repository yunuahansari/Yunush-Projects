<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use App\Http\Models\User;
use View;
use Excel;
use App\Http\Requests\Admin\AddMerchantRequest;
use App\Http\Requests\Admin\EditMerchantRequest;
use App\Http\Requests\Admin\EditMerchantCallRequest;
use App\Http\Models\CallRequest;
use \App\Http\Models\CustomerExecutiveRelation;

class MerchantController extends Controller {

    /**
     * manage merchants index
     * @return view
     * */
    public function index() {
        return view('admin.merchants.index');
    }

    /**
     * all merchants list
     * @return view
     * */
    public function allMerchant(Request $request) {
        try {
            $users = User::getAllMerchantByAdmin($request->all());
            $html = View::make('admin.merchants._merchant_list', ['users' => $users])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     *  add new merchant
     * @return \Illuminate\Http\Response
     * */
    public function addMerchant() {
        return view('admin.merchants.add_merchant');
    }

    /**
     *  save merchant
     * @return \Illuminate\Http\Response
     * */
    public function saveMerchant(AddMerchantRequest $request) {
        return User::saveMerchant($request->all());
    }

    /**
     *  edit merchant form
     * @return view
     * */
    public function editMerchant($id) {
        $user = User::getUsersByType($id, 'customer');
        if (!empty($user)) {
            return view('admin.merchants.edit_merchant', ['user' => $user]);
        }
        abort(404);
    }

    /**
     *  update merchant
     * @return \Illuminate\Http\Response
     * */
    public function updateMerchant(EditMerchantRequest $request) {
        return User::updateMerchant($request->all());
    }

    /**
     *  view merchant
     * @return view
     * */
    public function viewMerchant($id) {
        $user = User::getUsersByType($id, 'customer');
        if (!empty($user)) {
            return view('admin.merchants.view_merchant', ['user' => $user]);
        }
        abort(404);
    }

    public function linkedSupport($id) {
        $merchantCall = User::where('id', $id)->where('role','customer')->where('status','!=','deleted')->first();
        if (!empty($merchantCall)) {
            return view('admin.merchants.linked-support', ['id' => $id]);
        }
        abort(404);
    }

    public function linkedSupportList(Request $request) {
        try {
            $merchantCall = CallRequest::getMerchantRequestList($request, 'admin');
            $html = View::make('admin.merchants._linked-support-list', ['merchantCall' => $merchantCall])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     *  merchant's linked executive view
     * @return view
     */

    public function merchantLinkedExcutives($id) {
        $merchantSE = User::where('id', $id)->where('role','customer')->where('status','!=','deleted')->first();
        if (!empty($merchantSE)) {
            return view('admin.merchants.merchant-linked-executive', ['id' => $id]);
        }
        abort(404);
    }

    /*
     *  merchant's linked executive listing
     * @return \Illuminate\Http\Response
     */

    public function merchantLinkedExcutiveList(Request $request) {
        try {
            $merchantSE = CustomerExecutiveRelation::getExecutiveByCustomerId($request->id);
            $html = View::make('admin.merchants._merchant-linked-executive-list', ['merchantSE' => $merchantSE])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function merchantRequest(Request $request) {
        return view('admin.merchants.merchant-request');
    }

    public function listMerchantRequest(Request $request) {
        try {
            $callRequest = \App\Http\Models\CallRequest::getAllMerchantRequestHistory($request->all(), 'admin');
            $html = View::make('admin.merchants._merchant_request_list', ['callRequest' => $callRequest])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function merchantRequestView($id) {
        $callRequest = \App\Http\Models\CallRequest::where('id', '=', $id)->first();
        if (!empty($callRequest)) {
            return view('admin.merchants.merchant-request-view', ['callRequest' => $callRequest]);
        }
        abort(404);
    }

    public function merchantUnassignedRequest(Request $request) {
        return view('admin.merchants.request-unassigned');
    }

    public function listUnassignedRequest(Request $request) {
        try {
            $html = View::make('admin.merchants._request-unassigned')->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function unassignedRequestView(Request $request) {
        return view('admin.merchants.request-unassigned-view');
    }

    public function downloadMerchantCsv() {
        $post = [];
        $merchants = User::getAllMerchantByAdmin($post);
        $excelDownload = Excel::create('merchant_records', function($excel) use ($merchants) {
                    $excel->sheet('Sheet1', function($sheet) use($merchants) {
                        $arr = array();
                        foreach ($merchants as $userData) {
                            $string = $userData->city . ',' . $userData->state;
                            $string = trim($string, ',');
                            $data = array(
                                !empty($userData->merchant_number) ? $userData->merchant_number : '-',
                                $userData->bussiness_name,
                                !empty($userData->contact_name) ? ucfirst($userData->contact_name) : '-',
                                !empty($userData->phone_number) ? $userData->phone_number : '-',
                                $userData->machine_model,
                                !empty($userData->city || $userData->state) ? $string : '-'
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'Merchant Number', 'Business Name', 'Contact Name', 'Phone Number', 'Machine Model', 'City/State')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', 'export merchant');
            return redirect()->back();
        }
    }

    public function downloadMerchantHistoryCsv() {
        $post = [];
        $merchants = \App\Http\Models\CallRequest::getAllMerchantRequestHistory($post, 'admin');
        $excelDownload = Excel::create('merchant_history_records', function($excel) use ($merchants) {
                    $excel->sheet('Sheet1', function($sheet) use($merchants) {
                        $arr = array();
                        foreach ($merchants as $userData) {
                            $data = array(
                                $userData->customerDetail->contact_name,
                                !empty($userData->UserProfile->product) ? $userData->UserProfile->product : '',
                                date('d M Y', strtotime($userData->created_at)),
                                $userData->status,
                                $userData->executiveDetail->contact_name,
                                $userData->BankCategory->name,
                                $userData->call_time . ' mins'
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'Name', 'Processor', 'Generate Date', 'Status', 'SE Assigned', 'Category', 'Call of Time')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', 'export merchant request history');
            return redirect()->back();
        }
    }

    public function downloadMerchantLinkedExecutiveCsv($id) {
        $merchantSE = CustomerExecutiveRelation::getExecutiveByCustomerId($id);
        $excelDownload = Excel::create('merchant_executive_records', function($excel) use ($merchantSE) {
                    $excel->sheet('Sheet1', function($sheet) use($merchantSE) {
                        $arr = array();
                        foreach ($merchantSE as $userData) {
                            $managerName = \App\Http\Models\User::getManagerByDocument($userData->manager_id);
                            $data = array(
                                !empty($userData->userProfile->executive_number) ? $userData->userProfile->executive_number : '',
                                $userData->userDetail->contact_name,
                                !empty($managerName) ? ucfirst($managerName->first_name . ' ' . $managerName->last_name) : '-',
                                $userData->userDetail->phone_number,
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'ID', 'Name', 'Manager Name', 'Phone Number')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', 'export merchant executive');
            return redirect()->back();
        }
    }

    /*
     * edit merchant request modal
     * @return \Illuminate\Http\Response view
     */

    public function editMerchantRequestModal($id) {
        try {
            $callRequest = CallRequest::getCallRequestsById($id);
            $html = View::make('admin.merchants._edit_merchant_request', ['callRequest' => $callRequest])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /*
     * update merchant
     * @return \Illuminate\Http\Response
     */

    public function updateMerchantRequest(EditMerchantCallRequest $request) {
        return CallRequest::updateCallRequests($request->all());
    }

}
