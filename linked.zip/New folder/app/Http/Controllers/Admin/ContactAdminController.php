<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Http\Models\AdminContact;

class ContactAdminController extends Controller {

    public function contactAdminList(Request $request) {
        return view('admin.contact-admin.index');
    }

    public function listAllContactAdmin(Request $request) {
        try {
            $contactAdmin = AdminContact::getContactAdminList($request);
            $html = View::make('admin.contact-admin._contact_admin_list', ['contactAdmin' => $contactAdmin])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function contactAdminView(Request $request) {
        try {
            $id = $request->id;
            $contactAdmin = AdminContact::where('id', $id)->first();
            $html = View::make('admin.contact-admin._contact_admin_view', ['contactAdmin' => $contactAdmin])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

}
