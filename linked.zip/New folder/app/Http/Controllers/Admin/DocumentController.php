<?php

namespace App\Http\Controllers\Admin;

use App\Http\Models\Document;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Http\Requests\Admin\AddDocumentRequest;
use App\Http\Requests\Admin\EditDocumentRequest;

class DocumentController extends Controller {

    public function documentList(Request $request) {
        return view('admin.document.index');
    }

    public function listAllDocument(Request $request) {
        try {
            $documents = Document::getDocumentList($request);
            $html = View::make('admin.document._list_document', ['documents' => $documents])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function addDocumentForm() {
        return view('admin.document.document-add');
    }

    public function addDocument(AddDocumentRequest $request) {
        return Document::saveDocuments($request);
    }

    public function documentView($id) {
        $viewDocuments = Document::where('id', $id)->first();
        if (!empty($viewDocuments)) {
            return view('admin.document.document-view', ['viewDocuments' => $viewDocuments]);
        }
        abort(404);
    }

    public function documentEdit($id) {
        $editDocuments = Document::where('id', $id)->first();
        if (!empty($editDocuments)) {
            return view('admin.document.document-edit', ['editDocuments' => $editDocuments]);
        }
        abort(404);
    }

    public function documentDelete($id) {
        return Document::deleteDocument($id);
    }

    public function documentUpdate(EditDocumentRequest $request) {
        return Document::updateDocuments($request);
    }

}
