<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Http\Models\User;
use App\Http\Requests\Admin\AddManagerRequest;
use App\Http\Requests\Admin\EditManagerRequest;
use Excel;

class ManagerController extends Controller {

    public function managerList(Request $request) {
        return view('admin.manager.index');
    }

    public function listAllManagers(Request $request) {
        try {
            $managers = User::getManagerList($request);
            $html = View::make('admin.manager._list_manager', ['managers' => $managers])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function addManagerForm() {
        return view('admin.manager.manager-add');
    }

    public function addManager(AddManagerRequest $request) {
        $manager = User::saveManager($request);
        return $manager;
    }

    public function managerEdit($id) {
        $editManager = User::where('id', $id)->where('role', 'manager')->where('status', '!=', 'deleted')->first();
        if (!empty($editManager)) {
            return view('admin.manager.manager-edit', ['editManager' => $editManager]);
        }
        abort(404);
    }

    public function managerDelete($id) {
        return User::deleteManager($id);
    }

    public function managerUpdate(EditManagerRequest $request) {
        $manager = User::updateManager($request);
        return $manager;
    }

    public function managerView($id) {
        $viewManager = User::where('id', $id)->where('role', 'manager')->where('status', '!=', 'deleted')->first();
        if (!empty($viewManager)) {
            return view('admin.manager.manager-view', ['viewManager' => $viewManager]);
        }
        abort(404);
    }

    public function downloadManagerCsv() {
        $post = [];
        $managers = User::getManagerList($post);
        $excelDownload = Excel::create('merchant_processor_records', function($excel) use ($managers) {
                    $excel->sheet('Sheet1', function($sheet) use($managers) {
                        $arr = array();
                        foreach ($managers as $userData) {
                            $data = array(
                                getFullName($userData->first_name, $userData->last_name),
                                $userData->email,
                                $userData->phone_number,
                                showDateTimeFormatSecond($userData->created_at),
                                $userData->status
                            );
                            array_push($arr, $data);
                        }
                        $sheet->fromArray($arr, null, 'A1', false, false)->prependRow(array(
                            'Name', 'Email', 'Phone Number', 'Created Date', 'Status')
                        );
                        $sheet->row(1, function($row) {
                            $row->setFontWeight('bold');
                        });
                    });
                })->export('csv');

        if ($excelDownload) {
            return redirect()->back();
        } else {
            session()->flash('error', 'error');
            session()->flash('error', 'export merchant processor');
            return redirect()->back();
        }
    }

}
