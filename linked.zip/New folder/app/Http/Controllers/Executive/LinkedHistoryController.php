<?php

namespace App\Http\Controllers\Executive;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;
use Illuminate\Http\Request;
use App\Http\Models\CallRequest;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\Executive\AddEditNoteRequest;

class LinkedHistoryController extends Controller {

    public function index() {
        return view('executive.linked-history.linked_history');
    }

    public function linkedHistoryList() {
        try {
            $id = Auth::guard()->user()->id;
            $seRequest = CallRequest::getLinkedHistoryRequest($id);
            $html = View::make('executive.linked-history._list_linked_history', ['seRequest' => $seRequest])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function linkedHistoryView(Request $request) {
        try {
            $id = $request['id'];
            $seRequest = CallRequest::where('id', '=', $id)->first();
            $html = View::make('executive.linked-history._view_history', ['seRequest' => $seRequest])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function linkedHistoryEdit(Request $request) {
        try {
            $id = $request['id'];
            $seRequest = CallRequest::where('id', '=', $id)->first();
            $html = View::make('executive.linked-history._edit_history', ['seRequest' => $seRequest])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function updateExecutiveRequest(AddEditNoteRequest $request) {
        return CallRequest::updateCallRequestsExecutive($request->all());
    }

}
