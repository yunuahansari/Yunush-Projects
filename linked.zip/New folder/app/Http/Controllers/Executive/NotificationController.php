<?php

namespace App\Http\Controllers\Executive;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class NotificationController extends Controller {

    /**
     * executive dashboard
     * @return view
     * */
    public function index() {
        return view('executive.notifications.index');
    }

    public function notificationList() {
        $userId = Auth::guard()->user()->id;
        $notificationList = \App\Http\Models\Notification::where(['type'=>'customer_call_request','to_id'=>$userId])->get();
        if(!empty($notificationList)){
            foreach($notificationList as $val){
                $val->read_status = 1;
                $val->save();
            }
        }
        $html = View::make('executive.notifications._notifications',['notificationList'=>$notificationList])->render();
        return Response::json(['success' => true, 'html' => $html]);
        
    }

}
