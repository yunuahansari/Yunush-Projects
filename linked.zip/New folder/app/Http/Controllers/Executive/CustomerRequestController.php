<?php

namespace App\Http\Controllers\Executive;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Models\CallRequest;

class CustomerRequestController extends Controller {

    public function index() {
        return view('executive.customer-request.customer_request');
        
    }

    public function customerRequestList() {
        try {
            $requests = CallRequest::getPendingCallRequestByExecutive(Auth::guard('web')->user()->id, 'listing');
            $html = View::make('executive.customer-request._customer_request_list', ['requests' => $requests])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
    public function createCallRequest(Request $request){
        $post = $request->all();
        $result = CallRequest::saveCallRequuestFromWeb($post);
        if($result){
            return Response::json(['success' => true, 'request_id' => $result]);
        } else {
            return Response::json(['success' => false]);
        }
        
    }

}
