<?php

namespace App\Http\Controllers\Executive;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use App\Http\Models\CallRequest;
use App\Http\Models\Document;
use Illuminate\Support\Facades\Auth;
use File;
use App\Http\Models\CallImage;

class LinkedNotesController extends Controller {

    /**
     * executive dashboard
     * @return view
     * */
    public function index(Request $request) {
        $post = $request->all();
        $id = $post['id'];
        $request = CallRequest::getCallRequestsById($id);
        //return view('executive.linked-notes.index', ['request' => $request]);
        $html = View::make('executive.linked-notes.index', ['request' => $request])->render();
        return Response::json(['success' => true, 'html' => $html]);
    }

    /**
     * executive's bank document listing
     * @return \Illuminate\Http\Response
     * */
    public function executiveDocumentsList(Request $request) {
        try {
            $documents = Document::getDocList($request->all());
            $html = View::make('executive.linked-notes._document_list', ['documents' => $documents])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * executive's linked merhcant notes history listing
     * @return \Illuminate\Http\Response
     * */
    public function linkedMerchantNotesHistoryList($merchantId) {
        try {
            $executiveId = Auth::guard('web')->user()->id;
            $notesHistory = CallRequest::getMerchantLinkedNotesHistoryByExecutive($executiveId, $merchantId);
            $html = View::make('executive.linked-notes._linked_notes_history', ['notesHistory' => $notesHistory])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    /**
     * executive's linked merhcant notes history modal
     * @return \Illuminate\Http\Response
     * */
    public function loadAddNoteModal($requestId) {
        try {
            $seRequest = CallRequest::getCallRequestsById($requestId);
            $html = View::make('executive.linked-notes._add_note_modal', ['seRequest' => $seRequest])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }
    
    public function updateCallStatus(Request $request){
        $post = $request->all();
        CallRequest::updateCallStatus($post);
    }
    
    public function uploadImage(Request $request){
        $file = $_FILES; 
        $type = explode("/", $file["add_image"]["type"]);
        
        if($type[0]=='image'){
            if ($file["add_image"]["size"] < (1000 * 1000 * 5)) {
                $size = getimagesize($file["add_image"]['tmp_name']);
                $filename = time() . "-" . $file['add_image']['name'];
                $imagePath = base_path() . '/public/uploads/linked-call-images/';
                if (!is_dir($imagePath)) {
                    File::makeDirectory($imagePath, $mode = 0777, true, true);
                }
                move_uploaded_file($file['add_image']['tmp_name'], $imagePath . $filename);
                
                $ticket = $request->ticket_id;
                $lastCall = CallRequest::where(['ticket_id' => $ticket])->orderBy('id', 'DESC')->first();
                $callId = 0;
                if(!empty($lastCall)){
                    $callId = $lastCall->id;
                }
                
                $callImage = new CallImage();
                $callImage->call_id = $callId;
                $callImage->ticket_id = $ticket;
                $callImage->image_name = $filename;
                $callImage->save();
                
                $image = url('/public/uploads/linked-call-images/'.$filename);
                return Response::json(['success' => 1, 'filename' => $image]);
                
            } else {
                return Response::json(['success' => 0, 'error' => 'Image has to be smaller than 5MB']);
            }
        }
    }

}
