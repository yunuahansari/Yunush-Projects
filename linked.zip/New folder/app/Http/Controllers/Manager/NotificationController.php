<?php

namespace App\Http\Controllers\Manager;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;
use App\Http\Models\Notification;
use Illuminate\Support\Facades\Auth;

class NotificationController extends Controller {

    public function notifications(Request $request) {
        return view('manager.notifications.index');
    }

    public function listNotificationList(Request $request) {
        try {
            $notifications = Notification::getNotificationByAdmin(Auth::guard('manager')->user()->id);
            $html = View::make('manager.notifications._notifications-list', ['notifications' => $notifications])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function loadNotificationList(Request $request) {
        try {
            $notifications = Notification::loadNotificationByAdmin(Auth::guard('manager')->user()->id);
            $html = View::make('manager.notifications._load_notification_list', ['notifications' => $notifications])->render();
            return Response::json(['success' => true, 'html' => $html]);
        } catch (\Exception $e) {
            return Response::json(['success' => false, 'message' => $e->getMessage()]);
        }
    }

    public function updateNotificationList(Request $request) {
        $userId = Auth::guard('manager')->user()->id;
        return updateNotificationList($userId);
    }

    public function loadNotificationCount() {
        $userId = Auth::guard('manager')->user()->id;
        $notificationCount = loadNotificationCount($userId);
        return Response::json(['success' => true, 'data' => $notificationCount]);
    }

}
