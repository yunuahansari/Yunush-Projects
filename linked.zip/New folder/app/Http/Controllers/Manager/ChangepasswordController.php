<?php

namespace App\Http\Controllers\Admin;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\ChangePasswordRequest;
use Illuminate\Support\Facades\Response;

class ChangepasswordController extends Controller
{
    public function changePassword()
    {
    	return view('admin.change-password.change-password');
    }

    public function updatePassword(ChangePasswordRequest $request)
    {
    	$updatepassword = User::updateAdminPassword($request);
    	if ($updatepassword)
        {
            $request->session()->flash('success', 'Password updated successfully');
            return Response::json(['success' => true]);
        }
        else
        {
            $request->session()->flash('error', 'Something went wrong');
            return Response::json(['success' => false]);
        }
    }
}
