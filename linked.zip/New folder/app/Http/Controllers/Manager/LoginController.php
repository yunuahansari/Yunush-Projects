<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Response;
use Illuminate\Http\Request;
use App\Http\Requests\Manager\ManagerLoginRequest;
use App\User;

class LoginController extends Controller {
    /*
      |--------------------------------------------------------------------------
      | Login Controller
      |--------------------------------------------------------------------------
      |
      | This controller handles authenticating users for the application and
      | redirecting them to your home screen. The controller uses a trait
      | to conveniently provide its functionality to your applications.
      |
     */

use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/manager';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        $this->middleware('guest')->except('logout');
    }

    /**
     * Handle a login request to the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Http\Response
     */
    public function login(ManagerLoginRequest $request) {
        $this->validateLogin($request);
        if ($this->hasTooManyLoginAttempts($request)) {
            $this->fireLockoutEvent($request);
            return $this->sendLockoutResponse($request);
        }
        if ($this->attemptLogin($request)) {
            if (Auth::guard('manager')->user()->role != 'manager') {
                $this->guard()->logout();
                $this->incrementLoginAttempts($request);
                return $this->sendFailedLoginResponse($request, 'auth.user_type');
            }
            /*
              if (Auth::guard('manager')->user()->status == 'inactive') {
              $this->guard('manager')->logout();
              $this->incrementLoginAttempts($request);
              return $this->sendFailedLoginResponse($request, 'auth.user_status_inactive');
              }
              if (Auth::guard('manager')->user()->status == 'deleted') {
              $this->guard('manager')->logout();
              $this->incrementLoginAttempts($request);
              return $this->sendFailedLoginResponse($request, 'auth.user_status_deleted');
              }
             */
            return Response::json(['success' => true, 'message' => 'You are successfully logged in.', 'redirectUrl' => url('manager/dashboard')]);
//            return $this->sendLoginResponse($request);
        }

        /* check the reason to fail login */
        $user = \App\User::where('username', $request->get($this->username()))->where('status', '!=', 'deleted')->first();
// If the login attempt was unsuccessful we will increment the number of attempts
// to login and redirect the user back to the login form. Of course, when this
// user surpasses their maximum number of attempts they will get locked out.
        $this->incrementLoginAttempts($request);
        if (!empty($user)) {
            if ($user->status == 'inactive') {
                return $this->sendFailedLoginResponse($request, 'auth.user_status_inactive');
            }
        }
        return $this->sendFailedLoginResponse($request);
    }

    /**
     * Attempt to log the user into the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return bool
     */
    protected function attemptLogin(ManagerLoginRequest $request) {
        return $this->guard()->attempt(
                        $this->credentials($request), $request->has('remember')
        );
    }

    /**
     * Get the needed authorization credentials from the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    protected function credentials(ManagerLoginRequest $request) {
// assuming that the email or username is passed through a 'email' parameter
        $credentials = $request->only($this->username(), 'password');
// Customization: validate if user status is active
        $credentials['status'] = 'active';
        return $credentials;
    }

    /**
     * Send the response after the user was authenticated.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    protected function sendLoginResponse(ManagerLoginRequest $request) {
        $request->session()->regenerate();

        $this->clearLoginAttempts($request);

        return $this->authenticated($request, $this->guard()->user())
                ? : redirect()->intended($this->redirectPath());
    }

    /**
     * Get the failed login response instance.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    protected function sendFailedLoginResponse(ManagerLoginRequest $request, $trans = 'auth.failed') {
        $errors = [$this->username() => trans($trans)];
        if ($request->expectsJson()) {
            return response()->json($errors, 422);
        }
        return redirect()->back()
                        ->withInput($request->only($this->username(), 'remember'))
                        ->withErrors($errors);
    }

    /**
     * Get the login username to be used by the controller.
     *
     * @return string
     */
    public function username() {
        return 'username';
    }

    /**
     * Log the user out of the application.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function logout(Request $request) {
        $this->guard()->logout();
        $request->session()->invalidate();
        return redirect('/manager');
    }

    /**
     * Get the guard to be used during authentication.
     *
     * @return \Illuminate\Contracts\Auth\StatefulGuard
     */
    protected function guard() {
        return Auth::guard('manager');
    }

}
