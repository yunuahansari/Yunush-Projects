<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
//        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('executive.index');
    }
    
    public function site()
    {
        return view('site');
    }
    
    public function test($deviceId,$user_type,$device){
        //$deviceId = "8b25caaefc0642a433d20231bd09296f5ce003de7bbb60c444bd966780d0193e";
        $message = "123456789";
        $type = "";
        $user_type = "executive";
        if($device == 'android'){
            \App\Common\Utility::FcmPushNotification([$deviceId], $message, $user_type,[],1,1,'nosave');
        } else {
            \App\Common\Utility::APNSPushDeviceNotification($deviceId,$message,$user_type,[],1,1,'nosave');
        }
    }
}
