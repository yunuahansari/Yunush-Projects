<?php
namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\ContactAdminRequest;
use Illuminate\Support\Facades\Response;
use App\Http\Models\AdminContact;
use JWTAuth;
use App\Common\Utility;
use App\Http\Models\UserProfile;
use App\Http\Models\Rating;
use App\Http\Models\Notification;
use App\Http\Models\CallRequest;
use App\Http\Models\User;

class CustomerController extends Controller {

    public function getProfile(){
        try{
         $token = \Request::header('access-token');
         $user = JWTAuth::toUser($token);
         if(!empty($user)){
           $user->profile_image = checkProfileImage($user->profile_image);
           $customer_profile = UserProfile::where(['user_id'=>$user->id])->first();
           $user->merchant_no = (!empty($customer_profile))?$customer_profile->merchant_number:'';
           $user->product = (!empty($customer_profile))?$customer_profile->product:'';
           $user->bussiness_name = (!empty($customer_profile))?$customer_profile->bussiness_name:'';
           $user->bussiness_address = (!empty($customer_profile))?$customer_profile->bussiness_address:'';
           return  response()->json(['success' => true, 'data' => $user]);
         }
        }  catch (\Exception $ex){
           
        }
    }
    
    // customer rate to executive
    public function rateToexecutive(Request $request) {
        $post = $request->all();
        $response = Rating::rateToExecutive($post);
        if ($response) {
            return response()->json(['success' => true, 'data' => [], 'message' => 'rated successfully']);
        }
        return response()->json(['success' => false, 'data' => [], 'message' => 'not rated']);
    }
    
    //notification list
    public function getNotificationList(Request $request) {
         try {
            $post = $request->all();
            $response = Notification::getNotificationList();
            if (!empty($response) && count($response) > 0) {
                return response()->json(['success' => true, 'data' => $response, 'message' => '']);
            }
            return response()->json(['success' => true, 'data' => [], 'message' => 'no notification found']);
            
        } catch (\Exception $ex) {
           return response()->json(['success' => false, 'data' => [], 'message' =>$ex->getMessage()]);  
        }
    }

    // linked history of customer
    public function getLinkedHistory() {
         try {
            $response = CallRequest::getLinkerHistory();
            if ($response) {
                return response()->json(['success' => true, 'data' => $response, 'message' => '']);
            }
            return response()->json(['success' => true, 'data' => [], 'message' => 'no List found']);
        } catch (\Exception $ex) {
            return response()->json(['success' => false, 'data' => [], 'message' => $ex->getMessage()]);
        }
    }

    // customer's home detail
    public function getHomeDetail() {
      $response =  User::GetCustomerHomeDetail();
      if($response){
         return response()->json(['success' => true, 'data' => $response, 'message' => '']); 
      }
      return response()->json(['success' => false, 'data' => [], 'message' => 'not found']);
    }
    // customer send call request to executive
    public function sendRequestToExecutive(Request $request){
        $post = $request->all();
        $response =  CallRequest::sendRequestNotification($post);
        if($response){
            return $response;
        }
    }
    
    public function linkCall(Request $request){
         $post = $request->all();
        $response = CallRequest::linkWithCustomer($post); 
        if($response){
            return $response;
        }
    }

}
