<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\ContactAdminRequest;
use Illuminate\Support\Facades\Response;
use App\Http\Models\AdminContact;
use JWTAuth;
use App\User;
use App\Common\Utility;
use App\Http\Models\UserProfile;
use App\Http\Models\Bank;
use App\Http\Models\Ticket;
use App\Http\Models\Document;
use App\Http\Models\ExecutiveCategory;
use App\Http\Models\BankingCategory;
use App\Http\Models\CallRequest;
use App\Http\Models\Notification;
use App\Http\Models\CallImage;
use File;

class ExecutiveController extends Controller {

    public function getCustomerProfile(Request $request) {

        $get = $request->all();
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        $array = [];
        $profile = [];
        $note = [];

        $customer = User::where(['id' => $get['customer_id']])->first();
        if (!empty($customer)) {
            $array['customer_profile'] = checkProfileImage($customer->profile_image);
            $array['customer_name'] = $customer->contact_name;
            $customer_profile = UserProfile::where(['user_id' => $customer->id])->first();
            $bank = Bank::where(['id' => $customer->bank_id])->first();
            $array['bank'] = (!empty($bank)) ? $bank['name'] : '';
            //profiel detail

            $profile['merchant_no'] = (!empty($customer_profile)) ? $customer_profile['merchant_number'] : '';
            $profile['product'] = (!empty($customer_profile)) ? $customer_profile['bussiness_name'] : '';
            $profile['company'] = (!empty($bank)) ? $customer_profile['name'] : '';
            $profile['business_name'] = (!empty($customer_profile)) ? $customer_profile['bussiness_name'] : '';
            $profile['business_address'] = (!empty($customer_profile)) ? $customer_profile['bussiness_address'] : '';
            $profile['mobile'] = $customer->phone_number;
            $profile['email'] = $customer->email;

            //note detal
            $notes = Ticket::where(['customer_id' => $get['customer_id'], 'executive_id' => $user->id, 'status' => 'resolved'])->get();
            $array['profile'] = $profile;
            $array['note_history'] = $notes;

            return response()->json(['success' => true, 'data' => $array, 'error' => []]);
        }
        return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'No Customer Found']]);

    }

    public function getDocumentList(Request $request) {
        $documents = Document::getDocList($request);
        if (!empty($documents) && (count($documents) > 0)) {
            foreach ($documents as $doc) {
                if (!empty($doc->pdf_upload)) {
                    $doc->file_name = $doc->pdf_upload;
                    $doc->title = $doc->title;
                    $doc->file_url = getDocUrl($doc->pdf_upload);
                } else {
                    $doc->title = $doc->title;
                    $doc->content = $doc->content;
                }
            }
            return response()->json(['success' => true, 'data' => $documents, 'error' => []]);
        }
        return response()->json(['success' => true, 'data' => $documents, 'message' => 'No Bank Document Found']);
    }

    public function getProfile(Request $request) {
        $response = [];
        $token = \Request::header('access-token');
        $user = JWTAuth::toUser($token);
        if (!empty($user)) {
//            $result =  ExecutiveCategory::getCategoriesById($user->id);
            $response['id'] = $user->id;
            $response['profile_image'] = checkProfileImage($user->profile_image);
            $response['email'] = $user->email;
            $response['mobile'] = $user->phone_number;
            $response['executive_name'] = $user->contact_name;
            $response['address'] = $user->address;
            $executives = ExecutiveCategory::where(['executive_id' => $user->id])->get();
            $array = [];
            $all = [];
            if (!empty($executives) && count($executives)) {
                foreach ($executives as $exe) {
                    $category = BankingCategory::where(['id' => $exe['category_id']])->first();
                    $array['id'] = $category['id'];
                    $array['category_name'] = $category['name'];
                    $all[] = $array;
                }
            }
            $response['executive_categorys'] = $all;
            return response()->json(['success' => true, 'data' => $response, 'error' => []]);
        }
        return response()->json(['success' => false, 'data' => [], 'error' => ['message' => 'No Executive Found']]);
    }

    public function getLinkedHistory() {
        try {
            $response = CallRequest::getLinkerHistory();
            if ($response) {
                return response()->json(['success' => true, 'data' => $response, 'message' => '']);
            }
            return response()->json(['success' => true, 'data' => [], 'message' => 'no List found']);
        } catch (\Exception $ex) {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => $ex->getMessage()]]);
        }
    }

    public function getNotificationList() {
        try {
            $response = Notification::getNotificationList();
            if (!empty($response) && count($response) > 0) {
                return response()->json(['success' => true, 'data' => $response, 'message' => '']);
            }
            return response()->json(['success' => true, 'data' => [], 'message' => 'no notification found']);
        } catch (\Exception $ex) {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => $ex->getMessage()]]);
        }
    }

// yunush : home detail page executive side
    public function getHostoryDetail(Request $request) {
        $get = $request->all();
        $response = CallRequest::getHistoryDetail($get);
        if (!empty($response)) {
            return response()->json(['success' => true, 'data' => $response, 'message' => '']);
        }
        return response()->json(['success' => false, 'data' => [], 'message' => 'no notification found']);
    }

    //yunush : company category list
    public function getCategoryList() {
        $response = BankingCategory::getCategoryApiList();
        try {
            if (!empty($response)) {
                return response()->json(['success' => true, 'data' => $response, 'message' => '']);
            }
            return response()->json(['success' => true, 'data' => [], 'message' => 'No Category list found']);
        } catch (\Exception $ex) {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => $ex->getMessage()]]);
        }
    }

//yunush : category executive list
    public function getExecutiveList(Request $request) {
        try {
            $get = $request->all();
            $response = ExecutiveCategory::getCategoryExecutive($get);
            if (!empty($response)) {
                return response()->json(['success' => true, 'data' => $response, 'message' => '']);
            }
            return response()->json(['success' => true, 'data' => [], 'message' => 'no executive found']);
        } catch (\Exception $ex) {
            return response()->json(['success' => false, 'data' => [], 'error' => ['message' => $ex->getMessage()]]);
        }
    }

    //yunush :executive finish call save detail
    public function saveRequestDetail(Request $request) {
        $post = $request->all();
        $response = CallRequest::saveFinishCallDetail($post);
        if (!empty($response)) {
            return response()->json(['success' => true, 'data' => [], 'message' => 'Call finished successfully']);
        }
        return response()->json(['success' => false, 'data' => [], 'message' => '']);
    }

    //yunush :list of missed request in executive side 
    public function executiveHomeDetail(Request $request) {
        try {
            $get = $request->all();
            $response = CallRequest::getMissedRequest($get);
            if (!empty($response)) {
                return response()->json(['success' => true, 'data' => $response, 'message' => '']);
            }
            return response()->json(['success' => true, 'data' => [], 'message' => '']);
        } catch (\Exception $ex) {
            return response()->json(['success' => false, 'data' => [], 'message' => $ex->getMessage()]);
        }
    }

    public function linkcall(Request $request) {
        $post = $request->all();
        $response = CallRequest::linkWithCustomer($post);
        return $response;
    }

    public function sendcallnotification(Request $request) {
        $post = $request->all();
        $userName = \App\Http\Models\User::getUserDataByKey($post['calledId'], 'contact_name');
        $receiverData = \App\Http\Models\UserDevice::where(['user_id' => $post['receiverId']])->first();
        $userData = \App\Http\Models\User::where(['id' => $post['receiverId']])->first();
        $message = "You have received one notification from $userName";
        $data = [
            'notification_type' => 'call_request'
        ];
        if (!empty($receiverData)) {
            if ($receiverData->device_type == "ios") {
                Utility::APNSPushDeviceNotification($receiverData->call_device_id, $message, $userData->role, $data, $post['calledId'], $post['receiverId']);
            } else {
                Utility::FcmPushNotification([$receiverData->device_id], $message, $userData->role, $data, $post['calledId'], $post['receiverId']);
            }
        } else {
            $data = [
                'notification_type' => 'call_request'
            ];
            Utility::saveNotification($post['calledId'], $message, 'call_request',$data,$post['receiverId']);
        }

        //$data = Utility::
    }
    
    public function shareImage(Request $request){
        try {
            $file = $_FILES; 
            $type = explode("/", $file["image"]["type"]);

            if($type[0]=='image'){
                if ($file["image"]["size"] < (1000 * 1000 * 5)) {
                    $size = getimagesize($file["image"]['tmp_name']);
                    $filename = time() . "-" . $file['image']['name'];
                    $imagePath = base_path() . '/public/uploads/linked-call-images/';
                    if (!is_dir($imagePath)) {
                        File::makeDirectory($imagePath, $mode = 0777, true, true);
                    }
                    move_uploaded_file($file['image']['tmp_name'], $imagePath . $filename);

                    $ticket = $request->ticket_id;
                    $ticketData = getTicketDataByNumber($ticket);
                    if(empty($ticketData)){
                        return response()->json(['success' => false, 'data' => [], 'message' => 'Invalid Ticket Id']);
                    }
                    $lastCall = CallRequest::where(['ticket_id' => $ticketData->id])->orderBy('id', 'DESC')->first();
                    $callId = 0;
                    if(!empty($lastCall)){
                        $callId = $lastCall->id;
                    }

                    $callImage = new CallImage();
                    $callImage->call_id = $callId;
                    $callImage->ticket_id = $ticket;
                    $callImage->image_name = $filename;
                    $callImage->save();

                    $image = url('/public/uploads/linked-call-images/'.$filename);
                    return response()->json(['success' => true, 'data' => $image]);

                } else {
                    return response()->json(['success' => false, 'data' => [], 'message' => 'Image has to be smaller than 5MB']);
                }
            } else {
                return response()->json(['success' => false, 'data' => [], 'message' => 'Image has to be smaller than 5MB']);
            }
        } catch (\Exception $ex) {
            return response()->json(['success' => false, 'data' => [], 'message' => $ex->getMessage()]);
        }
    }

}
