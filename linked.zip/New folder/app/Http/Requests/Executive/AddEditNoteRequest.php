<?php

namespace App\Http\Requests\Executive;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class AddEditNoteRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'notes' => 'required|remove_spaces',
            'executive_id' => 'required_with:category_id',
        ];
    }

    public function messages() {
        return [
            'executive_id.required_with' => 'The execuitve field is required',
            'notes.remove_spaces' => 'The note does not contain spaces.',
        ];
    }

}
