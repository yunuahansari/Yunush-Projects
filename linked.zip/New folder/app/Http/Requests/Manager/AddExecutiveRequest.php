<?php

namespace App\Http\Requests\Manager;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class AddExecutiveRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {

        return[
            'username' => 'required|max:30|remove_spaces|username_unique_not_deleted',
            'password' => 'required|min:6|max:20',
            'contact_name' => 'required|max:30|remove_spaces',
//            'executive_number' => 'required|remove_spaces|id_number_unique_not_deleted',
            'category' => 'required',
//            'company' => 'required|max:30|remove_spaces',
            'phone' => 'nullable|numeric|digits_between:4,16',
//            'city' => 'required|max:100|remove_spaces',
//            'state' => 'required|max:100|remove_spaces',
            'email' => 'required|check_email_format|email_unique_not_deleted',
//            'image_file' => 'required|mimes:jpeg,png,jpg,svg|max:2048',
//            'bussiness_address' => 'required|remove_spaces|max:100',
            'supervisor_email' => 'nullable|max:50|check_email_format',
            'supervisor_phone' => 'nullable|numeric|digits_between:4,16',
            'supervisor_name' => 'nullable|remove_spaces',
        ];
    }

    public function messages() {
        return[
            'email.check_email_format' => 'The email format is not valid.',
//            'phone.phone_format' => 'The phone number is not valid.',
            'category.required' => 'The category field is required.',
            'username.remove_spaces' => 'The username does contain spaces.',
            'contact_name.remove_spaces' => 'The contact name does contain spaces.',
//            'executive_number.remove_spaces' => 'The Id number name does contain spaces.',
//            'executive_number.id_number_unique_not_deleted' => 'The executive number is already exists.',
//            'company.remove_spaces' => 'The company does contain spaces.',
//            'city.remove_spaces' => 'The city does contain spaces.',
//            'state.remove_spaces' => 'The state does contain spaces.',
//            'bussiness_address.remove_spaces' => 'The bussiness address does not contain spaces.',
            'supervisor_name.remove_spaces' => 'The supervisor name does contain spaces.',
            'supervisor_email.check_email_format' => 'The supervisor email format is not valid.',
//            'supervisor_phone.phone_format' => 'The phone number is not valid.',
            'username.username_unique_not_deleted' => 'The username is already exists.',
            'email.email_unique_not_deleted' => 'The email is already exists.',
        ];
    }

}
