<?php

namespace App\Http\Requests\Admin;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class AddManagerRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'username' => 'required|max:30|remove_spaces|username_unique_not_deleted',
            'password' => 'required|min:6|max:20',
            'first_name' => 'required|string|remove_spaces|max:50',
            'last_name' => 'required|string|remove_spaces|max:50',
            'email' => 'required|check_email_format|email_unique_not_deleted',
            'phone' => 'required|numeric|digits_between:4,16',
            'company' => 'required|remove_spaces',
//            'manager_type' => 'required',
//            'image_file' => 'required|mimes:jpeg,png,jpg,svg|max:2048',
        ];
    }

    public function messages() {
        return [
            'username.remove_spaces' => 'The username does not contain spaces.',
            'username.username_unique_not_deleted' => 'The username is already exists.',
            'first_name.remove_spaces' => 'The first name does not contain spaces.',
            'last_name.remove_spaces' => 'The last name does not contain spaces.',
            'company.remove_spaces' => 'The company does not contain spaces.',
//            'phone.phone_format' => 'The phone is not valid.',
            'email.email_unique_not_deleted' => 'The email is already exists.',
            'email.check_email_format' => 'The email format is not valid.',
        ];
    }

}
