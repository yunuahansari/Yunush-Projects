<?php

namespace App\Http\Requests\Admin;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class ForgotPasswordRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return
                    [
                    'email' => 'required|string|check_email_format|valid_email|admin_email|email_status_active',
        ];
    }

    public function messages() {
        return
                    [
                    'email.valid_email' => 'The Email is not exists.',
                    'email.required' => 'The Email is required.',
                    'email.admin_email' => 'The Email is not for this user type.',
                    'email.email_status_active' => 'The Email is not active.',
                    'email.check_email_format' => 'The email must be a valid email address.',
        ];
    }

}
