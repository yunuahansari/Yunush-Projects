<?php

namespace App\Http\Requests\Admin;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class EditMerchantRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return
                    [
                    'manager_id' => 'required',
                    'contact_name' => 'required|remove_spaces|max:30',
                    'bussiness_name' => 'required|remove_spaces|min:4|max:30',
                    'phone' => 'nullable|numeric|digits_between:4,16',
                    'email' => 'required|check_email_format|email_matched_not_deleted',
//                    'product' => 'required|remove_spaces|min:4|max:30',
                    'machine_model' => 'required|remove_spaces|max:100',
//                    'terminal_model' => 'required|remove_spaces|max:100',
//                    'bussiness_address' => 'required|remove_spaces|min:4|max:30',
//                    'city' => 'required|remove_spaces|max:100',
//                    'state' => 'required|remove_spaces|max:100',
//                    'merchant_number' => 'required|remove_spaces',
                    'executive' => 'required',
//                    'image_file' => 'nullable|mimes:jpeg,png,jpg,svg|max:2048',
//                    'hiddenFileName' => 'required',
        ];
    }

    public function messages() {
        return[
            'manager_id.required' => 'The manager field is required.',
            'contact_name.remove_spaces' => 'The contact name does not contain spaces.',
//            'terminal_model.remove_spaces' => 'The terminal model does not contain spaces.',
            'machine_model.remove_spaces' => 'The machine model does not contain spaces.',
            'bussiness_name.required' => 'The business name field is required.',
//            'bussiness_address.required' => 'The business address field is required.',
//            'bussiness_name.remove_spaces' => 'The business name does not contain spaces.',
//            'bussiness_address.remove_spaces' => 'The business address does not contain spaces.',
//            'product.remove_spaces' => 'The product does not contain spaces.',
//            'city.remove_spaces' => 'The city does not contain spaces.',
//            'state.remove_spaces' => 'The state does not contain spaces.',
            'email.check_email_format' => 'The email format is not valid',
//            'phone.phone_format' => 'The mobile number is not valid',
            'email.email_matched_not_deleted' => 'The email is already using by other user.',
//            'merchant_number.remove_spaces' => 'The merchant number does not contain spaces.',
//            'hiddenFileName.required' => 'The image field is required',
        ];
    }

}
