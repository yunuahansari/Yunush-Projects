<?php

namespace App\Http\Requests\Admin;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class EditDocumentRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return [
            'title' => 'required|remove_spaces|max:150',
            'pdf_upload' => 'nullable|mimes:pdf',
//                    'pdfUpload' => 'required',
            'pdfUpload' => 'required_if:document_type,doc',
            'manager_id' => 'required',
            'category_id' => 'required'
        ];
    }

    public function messages() {
        return
                    [
                    'title.remove_spaces' => 'The title does not contain spaces.',
                    'manager_id.required' => 'The manager field is required.',
                    'category_id.required' => 'The category field is required.',
                    'pdf_upload.mimes' => 'only pdf format is allowed.',
                    'pdfUpload.required_if' => 'The pdf field is required.'
        ];
    }

}
