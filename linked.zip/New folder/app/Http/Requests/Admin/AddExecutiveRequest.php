<?php

namespace App\Http\Requests\Admin;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class AddExecutiveRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {

        return[
            'username' => 'required|max:30|remove_spaces|username_unique_not_deleted',
            'password' => 'required|min:6|max:20',
            'contact_name' => 'required|remove_spaces|max:30',
//            'executive_number' => 'required|remove_spaces|id_number_unique_not_deleted',
            'category' => 'required',
            'manager_id' => 'required',
//            'company' => 'required|remove_spaces|max:30',
            'phone' => 'nullable|numeric|digits_between:4,16',
//            'city' => 'required|remove_spaces|max:100',
//            'state' => 'required|remove_spaces|max:100',
            'email' => 'required|check_email_format|email_unique_not_deleted',
//            'image_file' => 'required|mimes:jpeg,png,jpg,svg|max:2048',
//            'bussiness_address' => 'required|remove_spaces|max:100',
            'supervisor_email' => 'nullable|email|max:50|check_email_format',
            'supervisor_phone' => 'nullable|numeric|digits_between:4,16',
        ];
    }

    public function messages() {
        return[
            'contact_name.remove_spaces' => 'The contact name does not contain spaces.',
//            'executive_number.remove_spaces' => 'The executive number does not contain spaces.',
//            'executive_number.id_number_unique_not_deleted' => 'The executive number is already exists.',
//            'company.remove_spaces' => 'The company does not contain spaces.',
//            'city.remove_spaces' => 'The city does not contain spaces.',
//            'state.remove_spaces' => 'The state does not contain spaces.',
            'email.check_email_format' => 'The email format is not valid.',
//            'bussiness_address.remove_spaces' => 'The bussiness address does not contain spaces.',
//            'phone.phone_format' => 'The phone number is not valid.',
            'category.required' => 'The category field is required.',
            'manager_id.required' => 'The manager field is required.',
            'username.remove_spaces' => 'The username does not contain spaces.',
            'supervisor_email.check_email_format' => 'The supervisor email format is not valid.',
//            'supervisor_phone.phone_format' => 'The phone number is not valid.',
            'username.username_unique_not_deleted' => 'The username is already exists.',
            'email.email_unique_not_deleted' => 'The email is already exists.',
        ];
    }

}
