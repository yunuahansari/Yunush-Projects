<?php

namespace App\Http\Requests\Admin;

use Illuminate\Support\Facades\Response;
use Illuminate\Foundation\Http\FormRequest;

class EditExecutiveRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        return[
            'contact_name' => 'required|remove_spaces|max:30',
//            'company' => 'required|remove_spaces|max:30',
//            'executive_number' => 'required|remove_spaces|id_number_matched_not_deleted',
            'category' => 'required',
            'manager_id' => 'required',
            'phone' => 'nullable|numeric|digits_between:4,16',
            'email' => 'required|check_email_format|email_matched_not_deleted',
//            'city' => 'required|remove_spaces|max:100',
//            'state' => 'required|remove_spaces|max:100',
//            'image_file' => 'nullable|mimes:jpeg,png,jpg,svg|max:2048',
//            'hiddenFileName' => 'required',
//            'bussiness_address' => 'required|remove_spaces|max:100',
            'supervisor_email' => 'nullable|email|max:50|check_email_format',
            'supervisor_phone' => 'nullable|numeric|digits_between:4,16',
        ];
    }

    public function messages() {
        return[
            'contact_name.remove_spaces' => 'The contact name does not contain spaces.',
//            'company.remove_spaces' => 'The company does not contain spaces.',
//            'executive_number.remove_spaces' => 'The executive number does not contain spaces.',
//            'executive_number.id_number_matched_not_deleted' => 'The Id number is already using by other user.',
//            'city.remove_spaces' => 'The city does not contain spaces.',
//            'state.remove_spaces' => 'The state does not contain spaces.',
//            'bussiness_address.remove_spaces' => 'The bussiness address does not contain spaces.',
            'email.check_email_format' => 'The email format is not valid.',
//            'phone.phone_format' => 'The phone number is not valid.',
            'category.required' => 'The category field is required.',
            'manager_id.required' => 'The manager field is required.',
//            'hiddenFileName.required' => 'The image field is required',
            'supervisor_email.check_email_format' => 'The supervisor email format is not valid.',
//            'supervisor_phone.phone_format' => 'The phone number is not valid.',
            'email.email_matched_not_deleted' => 'The email is already using by other user.',
        ];
    }

}
