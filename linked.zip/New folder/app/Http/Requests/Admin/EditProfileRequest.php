<?php

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class EditProfileRequest extends FormRequest {

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize() {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules() {
        if (!empty($this->current_password) || !empty($this->password)) {
            return [
                'email' => 'required|email|max:50|check_email_format|unique:users,email,' . $this->id,
                'current_password' => 'required|current_password',
                'password' => 'required|min:6|max:20',
                'password_confirmation' => 'required|max:20|same:password'
            ];
        } else {
            return [
                'email' => 'required|email|max:50|check_email_format|unique:users,email,' . $this->id,
            ];
        }
    }

    public function messages() {
        if (!empty($this->current_password) || !empty($this->password)) {
            return [
                'email.check_email_format' => 'The email format is not valid.',
                'email.check_matched_email' => 'The email already taken by other user.',
                'current_password.current_password' => 'The current password is wrong.',
                'current_password.required' => 'The current password is required.',
                'password.required' => 'The password field is required.',
                'password_confirmation.required' => 'The confirm password field is required.',
                'password_confirmation.same' => 'The new password and confirm password does not match.',
            ];
        } else {
            return [
                'email.check_email_format' => 'The email format is not valid.',
                'email.check_matched_email' => 'The email already taken by other user.',
            ];
        }
    }

}
