<?php

return [
    'no_record_found' => "No record found.",
    'something_went_wrong' => "Opps something went wrong.",
    'status_updated' => "Status updated successfully",
    /* user contants */
    'user_deleted' => "User deleted successfully",
    'user_added' => "User added successfully",
    'user_updated' => "User updated successfully",
    'you_are_inactive' => "You are not active user.",
    'profile_updated' => "Profile updated successfully",
    'password_updated' => "Password changed successfully",
    /* executive contants */
    'executive_added' => "Executive added successfully",
    'executive_updated' => "Executive updated successfully",
    'executive_deleted' => "Executive deleted successfully",
    /* executive contants */
    'merchant_added' => "Merchant added successfully",
    'merchant_updated' => "Merchant updated successfully",
    'merchant_deleted' => "Merchant deleted successfully",
    /* document contants */
    'document_add' => "Document added successfully",
    'document_update' => "Document updated successfully",
    'document_deleted' => "Document deleted successfully",
    /* categories contants */
    'category_add' => "Category added successfully",
    'category_update' => "Category updated successfully",
    'category_deleted' => "Category deleted successfully",
    'category_status' => "Status updated successfully",
    /* manager contants */
    'manager_added' => "Manager added successfully",
    'manager_update' => "Manager updated successfully",
    /* bank contants */
    'bank_update' => "Bank updated successfully",
    'bank_deleted' => "Bank deleted successfully",
    /* auth constants */
    'login_success' => "You are successfully logged in.",
    'register_success_verify_email' => "You have successfully registered with Agging mbb, a verification link has been sent to your email.",
    'account_already_verified' => "Your account is already verified.",
    'account_verified_success' => "Your account verified successfully.",
    'forgot_mail_send' => "Please check your email for further information to reset password.",
    'mail_sent_failed' => "Mail is not sent due to server problem.",
    'password_reset_success' => "Your password reset successfully.",
    'change_password_mail_sent' => "Change Password mail sent successfully.",
    'user_detail_mail_sent' => "User detail mail sent successfully.",
    'reset_token_not_found' => "This reset token is not found.",
    /* call request constant */
    'request_updated' => "Request updated successfully.",
    /* email constant */
    'from_email' => "testing@codiant.com",
    
    // For Notification
    'auth_key'=>'/AuthKey_SJQTVZK57P.p8',
    'key_id'=>'SJQTVZK57P',
    'team_id'=>'Q84UD28472',
    // Notification key for android side
    'customer_api_access_key'=>'AIzaSyDYpwJDfuQmKji7C1siknKqVPEYqWTK0Tk',
    'executive_api_access_key'=>'AIzaSyC12HE3wbc-mTEMzYZn46QH6rpMAr0TAc8',
    
    // active notification time duration
    'active_time'=>5
];
