<?php
return [
    'paths' => [
         "/customer-profile-detail" => [
            "get" => [
                "tags" => [
                    "Executive"
                ],
                "summary" => "Customer Profile",
                "description" => "Customer Profile",
                "operationId" => "profile",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "query",
                        "name" => "customer_id",
                        "description" => "customer_id",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
         "/executive-profile" => [
            "get" => [
                "tags" => [
                    "Executive"
                ],
                "summary" => "executive Profile",
                "description" => "executive Profile",
                "operationId" => "profile",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
         "/executive-linked-history" => [
            "get" => [
                "tags" => [
                    "Executive"
                ],
                "summary" => "linked history",
                "description" => "linked history",
                "operationId" => "linked history",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "query",
                        "name" => "page",
                        "description" => "page",
                        "required" => false,
                        "type" => "string",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
         "/executive-linked-detail" => [
            "get" => [
                "tags" => [
                    "Executive"
                ],
                "summary" => "linked detail",
                "description" => "linked  detail",
                "operationId" => "linked detail",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "query",
                        "name" => "request_id",
                        "description" => "request_id",
                        "required" => false,
                        "type" => "string",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
        "/executive-list" => [
            "get" => [
                "tags" => [
                    "Executive"
                ],
                "summary" => "executive list",
                "description" => "executive list",
                "operationId" => "executive list",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                     [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "query",
                        "name" => "category_id",
                        "description" => "page",
                        "required" => false,
                        "type" => "string",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
        "/category-list" => [
            "get" => [
                "tags" => [
                    "Executive"
                ],
                "summary" => "category list",
                "description" => "category list",
                "operationId" => "category list",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                     [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
        "/finish-call" => [
            "post" => [
                "tags" => [
                    "Executive"
                ],
                "summary" => "finish call",
                "description" => "finish call",
                "operationId" => "finish call",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                     [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "notify_type will be when_online/today/selected_date and status will be pending/resolved and today_in_time/notify_date_time will be in h:m:s
 formate",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/finishcall"
                        ]
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
        "/executive-notification" => [
            "get" => [
                "tags" => [
                    "Executive"
                ],
                "summary" => "Notification List",
                "description" => "Notification List",
                "operationId" => "notification",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                     [
                        "in" => "query",
                        "name" => "page",
                        "description" => "page",
                        "required" => false,
                        "type" => "string",
                        "format" => "int64"
                    ],
                ],
                "responses" => [
                    
                ]
            ]
        ],
        "/executive-home" => [
            "get" => [
                "tags" => [
                    "Executive"
                ],
                "summary" => "executive home",
                "description" => "executive home",
                "operationId" => "executive home",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                     [
                        "in" => "query",
                        "name" => "page",
                        "description" => "page",
                        "required" => false,
                        "type" => "string",
                        "format" => "int64"
                    ],
                ],
                "responses" => [
                    
                ]
            ]
        ],
        "/link-call" => [
            "post" => [
                "tags" => [
                    "Executive"
                ],
                "summary" => "link call",
                "description" => "link call",
                "operationId" => "link call",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/linkcall"
                        ]
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
        "/bank-document" => [
            "get" => [
                "tags" => [
                    "Executive"
                ],
                "summary" => "Bank Documents",
                "description" => "Bank Documents",
                "operationId" => "doc",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "query",
                        "name" => "bank_id",
                        "description" => "bank_id",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "query",
                        "name" => "page",
                        "description" => " ",
                        "required" => false,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "query",
                        "name" => "document_name",
                        "description" => "document_name",
                        "required" => false,
                        "type" => "string",
                        "format" => "int64"
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
         "/share-image" => [
            "post" => [
                "tags" => [
                    "Executive"
                ],
                "summary" => "Share image",
                "description" => "Share Image",
                "operationId" => "doc",
                "consumes" => [
                ' multipart/form-data'
                ],
                "produces" => [
                   'multipart/form-data'
                ],
                "parameters" => [
                    [
                        "in" => "header",
                        "name" => "access-token",
                        "description" => "access-token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "formData",
                        "name" => "ticket_id",
                        "description" => "ticket Id",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "formData",
                        "name" => "image",
                        "description" => " ",
                        "required" => true,
                        "type" => "file",
                        "format" => "int64"
                    ],
                   
                ],
                "responses" => [
                    
                ]
            ]
        ]
    ],
    'definitions' => [
           'contact' => [
            'type' => "object",
            'properties' => [
                'name' => [
                    'type' => 'string'
                ],
                'business_name' => [
                    'type' => 'string'
                ],
                'phone_no' => [
                    'type' => 'string'
                ],
                'email' => [
                    'type' => 'string'
                ],
                'message' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "Contact"
            ]
        ],
           'linkcall' => [
            'type' => "object",
            'properties' => [
                'customer_id' => [
                    'type' => 'string'
                ],
                'ticket_id' => [
                    'type' => 'string'
                ]
                
            ],
            'xml' => [
                'name' => "linkcall"
            ]
        ],
           'finishcall' => [
            'type' => "object",
            'properties' => [
                'ticket_id' => [
                    'type' => 'string'
                ],
                'notify_type' => [
                    'type' => 'string'
                ],
                'request_status' => [
                    'type' => 'string'
                ],
                'category_id' => [
                    'type' => 'string'
                ],
                'executive_id' => [
                    'type' => 'string'
                ],
                'today_in_time' => [
                    'type' => 'string'
                ],
                'notify_date' => [
                    'type' => 'string'
                ],
                'notify_date_time' => [
                    'type' => 'string'
                ],
                'notes' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "finishcall"
            ]
        ],
    ]
    ];
