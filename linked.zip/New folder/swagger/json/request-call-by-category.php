<?php
return [
    'paths' => [
       
         "/request-call-category" => [
            "post" => [
                "tags" => [
                    "Request a call by category"
                ],
                "summary" => "Request a Call By Category",
                "description" => "Request a Call By Category",
                "operationId" => "request-call",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "Request a call",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/request-call"
                        ]
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ]
    ],
    'definitions' => [
        'request-call' => [
            'type' => "object",
            'properties' => [
                'category_id' => [
                    'type' => 'number'
                ],
                'note' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "Request a call"
            ]
        ],
    ]
    ];
