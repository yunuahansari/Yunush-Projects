<?php
return [
    'paths' => [
       
         "/contact-admin" => [
            "post" => [
                "tags" => [
                    "Contact Admin"
                ],
                "summary" => "Contact Admin",
                "description" => "Contact Admin",
                "operationId" => "contact",
                "consumes" => [
                   "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "Contact Admin",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/contact"
                        ]
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ]
    ],
    'definitions' => [
           'contact' => [
            'type' => "object",
            'properties' => [
                'name' => [
                    'type' => 'string'
                ],
                'business_name' => [
                    'type' => 'string'
                ],
                'phone_no' => [
                    'type' => 'string'
                ],
                'email' => [
                    'type' => 'string'
                ],
                'message' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "Contact"
            ]
        ],
    ]
    ];
