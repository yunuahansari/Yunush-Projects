<?php

return [
    'paths' => [
        
        "/signup" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "signup profile",
                "description" => "signup profile",
                "consumes" => [
                    "multipart/form-data"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "formData",
                        "name" => "role",
                        "description" => "select role",
                        "required" => true,
                        "type" => 'string',
                        "enum" => ['mentor', 'user']
                    ],
                    [
                        "in" => "formData",
                        "name" => "first_name",
                        "description" => "Enter first name",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "last_name",
                        "description" => "Enter last name",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "email",
                        "description" => "Enter email id",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "password",
                        "description" => "Enter password",
                        "required" => true,
                        "type" => 'string',
                    ],
                    [
                        "in" => "formData",
                        "name" => "confirm_password",
                        "description" => "Enter confrim password",
                        "required" => true,
                        "type" => 'string',
                    ],
                ],
                "responses" => [
                    "default" => [
                        "description" => "successful operation"
                    ]
                ]
            ]
        ],
        "/social-login" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "Login/signup with Social",
                "description" => "Login/signup with Social",
                "operationId" => "social-login",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "role should be mentor/user and type google/facebook",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/socialLogin"
                        ]
                    ]
                ],
                "responses" => [
                    
                ]
            ]
        ],
        "/login" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "Login a user",
                "description" => "Login for User",
                "operationId" => "login",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "role will be mentor/user",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/login_user"
                        ]
                    ]
                ],
                "responses" => [
                ]
            ]
        ],
        "/resend-code" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "resend code",
                "description" => "resend code",
                "operationId" => "resend code",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/resend_code"
                        ]
                    ]
                ],
                "responses" => [
                ]
            ]
        ],
        "/verify-code" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "verify code",
                "description" => "verify code",
                "operationId" => "verify-code",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/verify_code_def"
                        ]
                    ]
                ],
                "responses" => [
                ]
            ]
        ],
        "/check-verification" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "check verification",
                "description" => "check verification",
                "operationId" => "check verification",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/check_verify_def"
                        ]
                    ]
                ],
                "responses" => [
                ]
            ]
        ],
        "/forgot-password" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "forgot password",
                "description" => "forgot password",
                "operationId" => "forgot password",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/forgot_password"
                        ]
                    ]
                ],
                "responses" => [
                ]
            ]
        ],
        "/reset-password" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "reset password",
                "description" => "reset password",
                "operationId" => "reset password",
                "consumes" => [
                    "application/json"
                ],
                "produces" => [
                    "application/json"
                ],
                "parameters" => [
                    [
                        "in" => "body",
                        "name" => "body",
                        "description" => "",
                        "required" => false,
                        "schema" => [
                            '$ref' => "#/definitions/reset_password_def"
                        ]
                    ]
                ],
                "responses" => [
                ]
            ]
        ],
        
          "/logout" => [
            "post" => [
                "tags" => [
                    "account"
                ],
                "summary" => "Logout User",
                "description" => "",
                "consumes" => [
                    "application/json"
                ], "parameters" => [
                    [
                        "name" => "access-token",
                        "in" => "header",
                        "description" => "Access Token",
                        "required" => true,
                        "type" => "string",
                        "format" => "int64"
                    ],
                ],
                "responses" => [
                    "405" => [
                        "description" => "Invalid input"
                    ]
                ],
            ],
        ],
    ],
    'definitions' => [
        'login_user' => [
            'type' => "object",
            'properties' => [
                'email' => [
                    'type' => 'string'
                ],
                'password' => [
                    'type' => 'string'
                ],
                'role' => [
                    'type' => 'string'
                ],
                'device_id' => [
                    'type' => 'string'
                ],
                'device_type' => [
                    'type' => 'string'
                ],
                'certification_type' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "Login"
            ]
        ],
        'resend_code' => [
            'type' => "object",
            'properties' => [
                'email' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "resend_code"
            ]
        ],
        'check_verify_def' => [
            'type' => "object",
            'properties' => [
                'email' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "resend_code"
            ]
        ],
        'verify_code_def' => [
            'type' => "object",
            'properties' => [
                'code' => [
                    'type' => 'string'
                ],
                'email' => [
                    'type' => 'string'
                ],
                 'device_id' => [
                    'type' => 'string'
                ],
                'device_type' => [
                    'type' => 'string'
                ],
                'certification_type' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "verify_code1"
            ]
        ],
        'forgot_password' => [
            'type' => "object",
            'properties' => [
                'email' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "forgot_password"
            ]
        ],
        'reset_password_def' => [
            'type' => "object",
            'properties' => [
                'code' => [
                    'type' => 'string'
                ],
                'password' => [
                    'type' => 'string'
                ]
              
            ],
            'xml' => [
                'name' => "reset_password"
            ]
        ],
         'socialLogin' => [
            'type' => "object",
            'properties' => [
                'role' => [
                    'type' => 'string',
                    'enum' => ['mentor','user']
                ],
                'type' => [
                    'type' => 'string',
                    'enum' => ['google','facebook']
                ],
                'first_name' => [
                    'type' => 'string'
                ],
                'last_name' => [
                    'type' => 'string'
                ],
                'email' => [
                    'type' => 'string'
                ],
                'profile_image' => [
                    'type' => 'string'
                ],
                'source_id' => [
                    'type' => 'string'
                ],
                'device_id' => [
                    'type' => 'string'
                ],
                'device_type' => [
                    'type' => 'string'
                ]
            ],
            'xml' => [
                'name' => "Login"
            ]
        ]
    ]
];
